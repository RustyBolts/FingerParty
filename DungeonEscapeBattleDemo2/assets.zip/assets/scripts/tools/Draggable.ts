import { _decorator, Component, Node, UITransform, EventTouch, Vec3, Sprite, SpriteFrame, resources, director, Texture2D } from 'cc';
import { DropZone } from './DropZone';
const { ccclass, property } = _decorator;

@ccclass('Draggable')
export class Draggable extends Component {
    startParent: Node | null = null;

    zone: DropZone | null = null;

    start() {
        this.startParent = this.node.parent;
    }

    protected setPhotoImage(imageName: string): void {
        // Load and set the sprite
        const sprite = this.node.getComponent(Sprite);
        const imagePath = `maps/${imageName}/spriteFrame`;
        resources.load(imagePath, SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error('Failed to load image: ' + err);
                return;
            }
            sprite.spriteFrame = spriteFrame;
            sprite.spriteFrame.texture.setFilters(Texture2D.Filter.NONE, Texture2D.Filter.NONE);
        });
    }

    touchCancel(): void {
        this.node.parent = this.startParent;
        this.node.setPosition(Vec3.ZERO);
    }

    onEnable() {
        this.node.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }

    onDisable() {
        this.node.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }

    onTouchStart(event: EventTouch) {
        const { x, y } = this.startParent.getComponent(UITransform).convertToWorldSpaceAR(this.node.position);
        this.node.parent = director.getScene().children[0];
        this.node.setWorldPosition(new Vec3(x, y, 0));
        console.log('onTouchStart', this.node.name);
    }

    onTouchMove(event: EventTouch) {
        let delta = event.getUIDelta();
        this.node.setPosition(this.node.position.x + delta.x, this.node.position.y + delta.y);
    }

    onTouchEnd(event: EventTouch) {
        let dropZones = this.node.scene.getComponentsInChildren(DropZone).filter(zone => zone.node.active);
        let dropped = false;
        const { x, y } = this.node.getWorldPosition();
        console.log('dropZones length:', dropZones.length, `(${x}, ${y})`);

        for (let zone of dropZones) {
            // bug 進入戰鬥後，equipmentdropzone的parent 層會改變，而這邊不知道為什麼會把位置算錯，並且emit 後沒有正確被接收，導致畫面上的道具沒有繼續處理停在畫面上

            // 确定放置点是否在某个 DropZone 内
            if (Vec3.len(zone.node.getWorldPosition().clone().subtract3f(x, y, 0)) < 50) {
                dropped = true;
                this.zone = zone;

                console.log('dropped to zone:', zone.node.name);

                // 可以放置则触发 'drop' 事件
                zone.node.emit('drop', {
                    draggableItem: this,
                    dropZone: zone
                });
                break;
            }
        }

        if (!dropped) {
            this.node.parent = this.startParent;
            this.node.setPosition(Vec3.ZERO);
        }
    }

    onTouchCancel(event: EventTouch) {
        this.touchCancel();
    }
}
