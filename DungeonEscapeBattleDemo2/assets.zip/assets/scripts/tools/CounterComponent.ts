import { _decorator, Component, Node, Label, tween, UIOpacity, Vec3, randomRangeInt, Color } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('CounterComponent')
export class CounterComponent extends Component {
    @property(Label)
    counterLabel: Label = null; // 主計數器的Label

    minCount: number = 1; // 最小計數
    // maxCount: number = 999; // 最大計數

    protected currentCount: number = 0; // 目前的計數
    protected deprecatedCount: number = 0; // 優/劣勢的第二個計數，用來比對的，不會被使用

    // 設置初始計數
    start() {
        this.count = this.currentCount;
    }

    set count(value: number) {
        this.currentCount = value;
        this.updateLabel();
    }

    updateLabel() {
        this.counterLabel.string = this.currentCount.toString();
    }

    // 增加計數並執行動畫
    addCount(numberToAdd: number, name: string = '', fontSize: number = 30) {
        this.currentCount = Math.max(this.currentCount + numberToAdd, this.minCount);

        const node = new Node(); // 創建一個新的Label用於動畫
        node.parent = this.node; // 設置父節點

        const label = node.addComponent(Label); // 創建一個新的Label用於顯示數字

        if (numberToAdd > 0) {
            node.position = new Vec3(0, -80, 0); // 設置起始位置

            label.string = `+${numberToAdd}\n${name}`; // 設定Label文字
            label.fontSize = fontSize; // 設定Label字體大小
            // label.color = new Color(0, 255, 0); // 設定Label顏色

            // 動畫：數字上升並淡入
            tween(node)
                // .to(0.35, { position: new Vec3(0, 0, 0), scale: new Vec3(1.5, 1.5, 1) }, { easing: 'cubicOut' })
                .to(0.5, { position: new Vec3(0, 0, 0) }, { easing: 'cubicOut' })
                .call(() => {
                    this.updateLabel();
                    // 主Label放大並恢復原狀的動畫
                    this.counterEffect();
                })
                .removeSelf() // 移除動畫節點
                .start();
        } else {
            node.position = new Vec3(0, 0, 0); // 設置起始位置

            label.string = `${numberToAdd}\n${name}`; // 設定Label文字
            label.fontSize = fontSize; // 設定Label字體大小
            // label.color = new Color(255, 0, 0); // 設定Label顏色

            // 主Label放大並恢復原狀的動畫
            this.counterEffect();

            // 動畫：數字上升並淡入
            tween(node)
                .to(0.5, { position: new Vec3(0, -80, 0) }, { easing: 'cubicOut' })
                .call(() => {
                    this.updateLabel();
                })
                .removeSelf() // 移除動畫節點
                .start();
        }

        const uiOpacity = node.addComponent(UIOpacity);
        tween(uiOpacity)
            .to(0.7, { opacity: 120 }, { easing: 'cubicOut' })
            .to(0.1, { opacity: 0 })
            .start();

    }

    counterEffect() {
        // 計數器特效
        tween(this.counterLabel.node)
            .to(0.01, { scale: new Vec3(1.5, 1.5, 1) })
            .to(0.2, { scale: new Vec3(1, 1, 1) })
            .start();
    }
}
