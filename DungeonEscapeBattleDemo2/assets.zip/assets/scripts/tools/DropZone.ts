import { _decorator, Component, Node, Vec3 } from 'cc';
import { Draggable } from './Draggable';
import { EquipmentDropZone } from '../dungeon/inventory/EquipmentDropZone';
import { EventManager } from '../managers/EventManager';
const { ccclass, property } = _decorator;

@ccclass('DropZone')
export class DropZone extends Component {
    @property(Node)
    placeholder: Node = null;

    onEnable() {
        this.node.on('drop', this.onDrop, this);
    }

    onDisable() {
        this.node.off('drop', this.onDrop, this);
    }

    onDrop(event) {
        const draggableItem: Draggable = event.draggableItem;
        // const dropZone = event.dropZone;

        // 实现放置逻辑
        if (this.placeholder) {
            const existingItem = this.placeholder.children[0];
            if (existingItem) {
                console.log("道具已存在，交换位置");
                // 交换现有道具与拖拽道具的位置
                existingItem.parent = draggableItem.startParent;
                existingItem.setPosition(new Vec3(0, 0, 0));  // 居中对齐
                existingItem.getComponent(Draggable).startParent = existingItem.parent;
            }
            // 将拖拽道具放置到新位置
            draggableItem.node.parent = this.placeholder;
            draggableItem.node.setPosition(new Vec3(0, 0, 0));  // 居中对齐
            draggableItem.startParent = this.placeholder;

            console.log("道具已放置");
        }

    }

}
