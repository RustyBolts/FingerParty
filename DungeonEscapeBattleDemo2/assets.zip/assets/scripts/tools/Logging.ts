// import * as fs from 'fs/promises';
// import * as path from 'path';
// import { fileURLToPath } from 'url';

// const __filename = fileURLToPath(import.meta.url);
// const __dirname = path.dirname(__filename);
// // const __dirname = './';

// // 定義日誌等級枚舉
// enum LogLevel {
//     DEBUG = 'DEBUG',
//     INFO = 'INFO',
//     ERROR = 'ERROR'
// }

// export default class Logging {
//     private logFile: string;

//     constructor(filename: string = 'app.log', logDirectory: string = __dirname) {
//         // this.logFile = path.join(logDirectory, filename);
//         this.logFile = __dirname + filename;
//         this.initLogFile();
//     }

//     private async initLogFile(): Promise<void> {
//         // 確保日誌文件存在，如果不存在則創建
//         try {
//             await fs.access(this.logFile);
//         } catch (error) {
//             await fs.writeFile(this.logFile, '', { flag: 'wx' });
//         }
//     }

//     private async writeLog(message: string, level: LogLevel): Promise<void> {
//         const timestamp: string = new Date().toISOString();
//         const logMessage: string = `${timestamp} [${level}] - ${message}\n`;
//         await fs.appendFile(this.logFile, logMessage);
//     }

//     public debug(message: string): Promise<void> {
//         return this.writeLog(message, LogLevel.DEBUG);
//     }

//     public info(message: string): Promise<void> {
//         return this.writeLog(message, LogLevel.INFO);
//     }

//     public error(message: string): Promise<void> {
//         return this.writeLog(message, LogLevel.ERROR);
//     }
// }