import { _decorator, Component, Node, AudioSource, assert } from 'cc';
const { ccclass, property } = _decorator;

@ccclass("AudioController")
export class AudioController extends Component {

    @property(AudioSource)
    public _audioSource: AudioSource = null!;

    onLoad() {
        // 获取 AudioSource 组件
        const audioSource = this.node.getComponent(AudioSource)!;
        // 检查是否含有 AudioSource，如果没有，则输出错误消息
        assert(audioSource);
        // 将组件赋到全局变量 _audioSource 中
        this._audioSource = audioSource;
    }

    protected start(): void {
        const videoElement = document.querySelector('video');
        if (videoElement) {
            const promise = videoElement.play();

            if (promise !== undefined) {
                promise.then(_ => {
                    // Autoplay started!
                    this.play();
                }).catch(error => {
                    // Autoplay was prevented.
                    // Show a "Play" button so that user can start playback.
                    console.log('Autoplay prevented');
                });
            }
        }
    }

    play() {
        // 播放音乐
        this._audioSource.play();
        // this._audioSource.volume = 0.1;// todo 之後再做外部設置
    }

    pause() {
        // 暂停音乐
        this._audioSource.pause();
    }
}