import { _decorator, Component, Node, Vec3, Color, Label, tween, instantiate } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('FloatingTextComponent')
export class FloatingTextComponent extends Component {
    @property(Color)
    positiveColor: Color = new Color(0, 255, 0); // 正值颜色

    @property(Color)
    negativeColor: Color = new Color(255, 0, 0); // 负值颜色

    @property(Vec3)
    startPoint: Vec3 = new Vec3(0, 0, 0); // 起始位置

    @property(Vec3)
    endPoint: Vec3 = new Vec3(0, 100, 0); // 终点位置

    @property(Label)
    templateLabel: Label = null; // 模板 Label，用于克隆

    protected onLoad(): void {
        this.templateLabel.node.active = false; // 确保模板 Label 节点是非激活状态
    }

    showNumber(value: number, callback?: Function) {
        const labelNode = instantiate(this.templateLabel.node);
        labelNode.setParent(this.node);
        labelNode.active = true;

        const label = labelNode.getComponent(Label);
        label.string = (value > 0 ? '+' : '') + value.toString();
        label.color = value > 0 ? this.positiveColor : this.negativeColor;
        
        labelNode.setPosition(this.startPoint);

        // 执行上浮或下降动画
        tween(labelNode)
            .to(1.5, { position: this.endPoint }, { easing: 'elasticOut' })
            .call(() => {
                labelNode.destroy();
                callback?.(); // 执行回调
            })
            .start();
    }

}
