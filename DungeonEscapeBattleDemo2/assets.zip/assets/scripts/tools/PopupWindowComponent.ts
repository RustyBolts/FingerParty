import { _decorator, Component, Node, Label, Button, EventHandler, instantiate, Vec3, tween } from 'cc';
const { ccclass, property } = _decorator;

export interface ButtonOption {
    label: string;
    callback: () => void;  // 使用箭头函数类型简化回调类型定义
}

@ccclass('PopupWindowComponent')
export class PopupWindowComponent extends Component {
    @property(Node)
    dialogNode: Node = null;

    @property(Label)
    titleLabel: Label = null;

    @property(Label)
    contentLabel: Label = null;

    @property(Node)
    buttonContainer: Node = null;

    @property(Button)
    buttonPrefab: Button = null;

    private callbacks: Map<string, () => void> = new Map(); // 用于存储回调函数的映射

    openPopup(title: string, content: string, buttons: ButtonOption[]) {
        this.setupTitle(title);
        this.contentLabel.string = content;
        this.setupButtons(buttons);
        this.animateOpen();
    }

    setupTitle(title: string) {
        this.titleLabel.node.active = !!title;
        this.titleLabel.string = title || '';
    }

    setupButtons(buttons: ButtonOption[]) {
        this.buttonContainer.removeAllChildren();
        buttons.forEach((option, index) => {
            const buttonNode = instantiate(this.buttonPrefab.node);
            const button = buttonNode.getComponent(Button);
            const label = buttonNode.getComponentInChildren(Label);
            label.string = option.label;
            buttonNode.parent = this.buttonContainer;
            buttonNode.active = true;

            const key = `button_${index}`;
            this.callbacks.set(key, option.callback);

            let clickEventHandler = new EventHandler();
            clickEventHandler.target = this.node;
            clickEventHandler.component = 'PopupWindowComponent';
            clickEventHandler.handler = 'buttonClicked';
            clickEventHandler.customEventData = key;

            button.clickEvents.push(clickEventHandler);
        });
    }

    buttonClicked(event, customEventData: string) {
        const callback = this.callbacks.get(customEventData);
        if (callback) {
            callback();
        }
        this.animateClose();
    }

    animateOpen() {
        this.dialogNode.scale = new Vec3(0, 0, 0);
        tween(this.dialogNode)
            .to(0.3, { scale: new Vec3(1, 1, 1) })
            .start();
    }

    animateClose() {
        tween(this.dialogNode)
            .to(0.3, { scale: new Vec3(0, 0, 0) })
            .call(() => this.node.active = false)
            .start();
    }

    close(): void {
        this.node.active = false;
        this.callbacks.clear();
    }
}
