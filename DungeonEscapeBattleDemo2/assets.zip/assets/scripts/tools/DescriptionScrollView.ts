import { _decorator, Component, instantiate, Label, Node, RichText, ScrollView, tween, UIOpacity, UITransform, v2, v3, Vec3, resources, Sprite, SpriteFrame, Texture2D } from 'cc';
import { StoryData } from '../data/StoryData';
import { FillBlanks, ReplacedTipCard } from './FillBlanks';
import { TipClipsAnimation } from '../managers/TipClipsAnimation';
import { EventManager } from '../managers/EventManager';
import { TipCard } from '../cards/Card';
const { ccclass, property } = _decorator;

@ccclass('DescriptionScrollView')
export class DescriptionScrollView extends Component {
    @property(ScrollView)
    scrollView: ScrollView = null;

    @property(TipClipsAnimation)
    answerClipsAnimation: TipClipsAnimation = null;

    @property(Node)
    chooseButtonLayout: Node = null;

    @property(Sprite)
    bgSprite: Sprite = null!;

    private centerPosition: Vec3 = v3();
    private quarterHeight: number = 0;

    private index: number = 0;
    private needScroll: boolean = false;

    private descriptions: string[] = [];
    tipCards: TipCard[] = [];

    protected onLoad(): void {
        // 確保ScrollView組件存在
        if (!this.scrollView) {
            console.warn("ScrollView component is not assigned.");
            return;
        }

        // 獲取ScrollView的中心3/4位置
        this.quarterHeight = this.scrollView.getComponent(UITransform).height * 3 / 4;
        this.centerPosition = this.scrollView.content.getComponent(UITransform).convertToWorldSpaceAR(new Vec3(0, 0, 0));

        // 監聽ScrollView的滾動事件
        this.scrollView?.node.on('scrolling', this.onScrolling, this);
    }

    protected onDestroy(): void {
        // 移除監聽事件
        this.scrollView?.node.off('scrolling', this.onScrolling, this);
    }

    private onScrolling() {
        if (!this.needScroll)
            return;

        const children = this.scrollView.content.children;
        const viewContentTrans = this.scrollView.content.getComponent(UITransform);
        const descriptionsLength = this.descriptions.length;

        for (let i = 0; i < children.length; i++) {
            const child = children[i];
            const childPosition = viewContentTrans.convertToWorldSpaceAR(child.position);
            const distance = Vec3.distance(childPosition, this.centerPosition);
            if (distance <= this.quarterHeight && i === this.index) {
                this.index++;

                if (descriptionsLength <= this.index) {
                    console.log('DescriptionScrollView: 滾動到底部', descriptionsLength, '<=', this.index);
                    this.index = descriptionsLength;
                    this.needScroll = false;// 捲動到底就不需要再處理
                    EventManager.instance.emit('DescriptionScrollViewEnd');
                    break;
                }

                const description = this.descriptions[this.index];
                this.descriptionFadin(description, children);
                break;
            }
        }
    }

    private descriptionFadin(description: string, children: Node[]): void {
        const descriptionContent = children[this.index] || instantiate(children[0]);
        // const descriptionContent = instantiate(children[0]);
        descriptionContent.parent = this.scrollView.content;
        descriptionContent.position = Vec3.ZERO;
        descriptionContent.active = true;

        const richText = descriptionContent.getComponent(RichText);
        richText.string = this.describe(description);

        const uiOpacity = descriptionContent.getComponent(UIOpacity);
        uiOpacity.opacity = 0;
        tween(uiOpacity)
            .to(0.5, { opacity: 255 })
            .start();
    }

    private describe(description: string): string {
        const keepWords = this.tipCards.map(tip => tip.string);
        const replaced = FillBlanks.replaceMarkedWithKeywords([description], keepWords);
        const { text, tipCards } = replaced[0];
        const newTips: TipCard[] = tipCards.filter((tip) => !this.tipCards.includes(tip));
        if (newTips.length > 0) {
            this.answerClipsAnimation.spreadCards(newTips.map(x => x.string));
            this.tipCards = this.tipCards.concat(newTips);

            const picTip = newTips.find(x => !!x.pic);
            if (picTip) {
                // 只需要第一張，如果設定圖片的人太貪心，那就只顯示第一張就好
                console.log('tip.pic:', picTip.pic);
                this.setPhotoImage(picTip.pic);
            }

        }
        return text;
    }

    private setPhotoImage(imageName: string): void {
        // Load and set the sprite
        const sprite = this.bgSprite;
        const imagePath = `maps/${imageName}/spriteFrame`;
        resources.load(imagePath, SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error('Failed to load image: ' + err);
                return;
            }
            sprite.spriteFrame = spriteFrame;
            sprite.spriteFrame.texture.setFilters(Texture2D.Filter.NONE, Texture2D.Filter.NONE);
        });
    }

    get isBottom(): boolean {
        return this.index >= this.descriptions.length - 1;
    }

    hideButtonLayout(): void {
        this.chooseButtonLayout.active = false;
    }

    setData(descriptions: string[]) {
        if (!descriptions) {
            console.log('設定時未正確輸入資料!!!');
            return;
        }
        console.log('set descriptions data:', descriptions);

        this.scrollView.scrollToTop();

        const children = this.scrollView.content.children;
        children.forEach((child) => child.active = false);

        // 預設先第一筆填入資料
        this.index = 0;

        const descriptionContent = children[this.index];
        descriptionContent.active = true;

        this.descriptions = [...descriptions];

        const description = this.descriptions[this.index];
        const richText = descriptionContent.getComponent(RichText);
        richText.string = this.describe(description);

        this.chooseButtonLayout.active = false;

        this.needScroll = true;
    }

    addNewData(descriptions: string[]): void {
        if (!descriptions) {
            console.log('新增時未正確輸入資料!!!');
            return;
        }
        console.log('add new descriptions data:', descriptions);

        this.descriptions = this.descriptions.concat(descriptions);

        const description = this.descriptions[this.index];
        if (!description) {
            console.error(this.index, 'DescriptionScrollView: 描述資料不存在!!!');
            return;
        }

        const children = this.scrollView.content.children;
        this.descriptionFadin(description, children);
        this.chooseButtonLayout.active = false;

        this.needScroll = true;
    }

    deleteCard(card: TipCard): void {
        this.tipCards.splice(this.tipCards.findIndex((x) => x === card), 1);
        console.log('tipCards:', this.tipCards);
    }

    setChooseButtons(contents: { text: string, callback: Function }[]): void {
        this.chooseButtonLayout.active = true;

        const children = this.chooseButtonLayout.children;
        children.forEach((child) => {
            child.off('click');
            child.active = false;
        });

        console.log('set choose buttons:', contents);
        contents.forEach((content, index) => {
            const entity = children[index] || instantiate(children[0]);
            entity.active = true;
            entity.parent = this.chooseButtonLayout;

            const label = entity.getComponentInChildren(Label);
            label.string = content.text;

            // entity.on('click', this.onClicked, this,  content);
            entity.on('click', () => {
                label.string = '--';
                entity.off('click');
                content.callback();
            });
        });
    }

    show(active: boolean = true): void {
        this.node.active = active;

        if (!active) {
            // scrollview 重置
            this.scrollView.content.children.forEach((child) => child.active = false);
            this.scrollView.scrollToPercentVertical(0);

            this.clear();
        }
    }

    clear(): void {
        this.index = 0;
        this.descriptions.length = 0;
        this.clearTipCards();

        this.scrollView.content.children
            .forEach((x, i) => i>0 && x.destroy());
        // this.scrollView.content.getComponentsInChildren(RichText)
        //     .forEach((x) => x.string = '');

    }

    clearTipCards(): void {
        this.tipCards.length = 0;
    }

    hide(): void {
        this.node.active = false;
    }

    scrollToBottom(): void {
        this.scrollView.scrollToBottom(1);
    }

    onClicked(evt: Event, customData: any): void {
        this.show(false);
    }
}
