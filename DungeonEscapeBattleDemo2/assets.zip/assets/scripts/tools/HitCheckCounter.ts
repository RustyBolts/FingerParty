import { _decorator, Component, Label, Node } from 'cc';
import { CounterComponent } from './CounterComponent';
const { ccclass, property } = _decorator;

export type CheckType = 'Neutral' | 'Advantage' | 'Disadvantage';

@ccclass('HitCheckCounter')
export class HitCheckCounter extends CounterComponent {

    @property(Label)
    titleLabel:Label = null;

    private type: CheckType = 'Neutral'; // 目前的檢查類型

    start() {

        // //test
        // this.checkType = 'Advantage';
        // // this.checkType = 'Disadvantage';
        // this.count = randomRangeInt(1, 20);
        // this.count = randomRangeInt(1, 20);

        // this.scheduleOnce(() => {
        //     this.addCount(2, 'test');
        // }, 2);

    }

    set checkType(value: CheckType) {
        this.type = value;
    }

    set count(value: number) {
        console.log(`CounterComponent: set count to ${value}`, this.currentCount, this.deprecatedCount);
        if (this.type === 'Neutral') {
            this.currentCount = value;
            this.titleLabel.string = '命中檢定值';
        }
        else if (this.type === "Advantage") {
            if (value > this.currentCount) {
                this.deprecatedCount = this.currentCount;
                if (value !== 0) {
                    this.currentCount = value;
                }
            } else {
                if (value > this.deprecatedCount && value !== 0) {
                    this.deprecatedCount = value;
                }
            }
            this.titleLabel.string = '(優勢)\n命中檢定值';
        } else if (this.type === "Disadvantage") {
            if (value < this.currentCount) {
                this.deprecatedCount = this.currentCount;
                if (value !== 0) {
                    this.currentCount = value;
                }
            } else {
                if (this.currentCount === 0) {
                    this.currentCount = value;
                }
                else if (value !== 0) {
                    this.deprecatedCount = value;
                }
            }
            this.titleLabel.string = '(劣勢)\n命中檢定值';
        }

        this.updateLabel();
    }
    
    updateLabel() {
        if (this.type === 'Neutral') {
            this.counterLabel.string = this.currentCount.toString();
        }
        else {
            this.counterLabel.string = `${this.deprecatedCount} | ${this.currentCount}`;
        }
    }

}


