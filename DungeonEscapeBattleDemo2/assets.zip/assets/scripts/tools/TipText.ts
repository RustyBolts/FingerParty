import { _decorator, Component, RichText } from 'cc';
import { EventManager } from '../managers/EventManager';
const { ccclass, property } = _decorator;

export enum TipType {
    Normal = 'ShowTipText',
    NormalDelay = 'ShowTipTextDelay',
    Warning = 'ShowWarningText',
    Error = 'ShowErrorText',
    Hide = 'HideTipText'
}

@ccclass('TipText')
export class TipText extends Component {

    @property(RichText)
    private tipText: RichText = null!;

    protected onLoad(): void {
        this.node.active = false;

        EventManager.instance.on(TipType.Normal, this.onShowTipText, this);
        EventManager.instance.on(TipType.NormalDelay, this.onShowDelayTipText, this);
        EventManager.instance.on(TipType.Warning, this.onShowWarrningTipText, this);
        EventManager.instance.on(TipType.Error, this.onShowErrorTipText, this);
        EventManager.instance.on(TipType.Hide, this.onHideTipText, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(TipType.Normal, this.onShowTipText, this);
        EventManager.instance.off(TipType.NormalDelay, this.onShowDelayTipText, this);
        EventManager.instance.off(TipType.Warning, this.onShowWarrningTipText, this);
        EventManager.instance.off(TipType.Error, this.onShowErrorTipText, this);
        EventManager.instance.off(TipType.Hide, this.onHideTipText, this);
    }

    //#region Event

    private onShowTipText(text: string): void {
        const tip: string = text;
        this.showTipText(tip);
    }

    private onShowDelayTipText(text: string, duration: number): void {
        const tip: string = text;
        this.showTipText(tip);

        this.scheduleOnce(() => this.node.active = false, duration);
    }

    private onShowWarrningTipText(text: string): void {
        const tip: string = `<color=#ffff00>${text}</color>`;
        this.showTipText(tip);
    }

    private onShowErrorTipText(text: string): void {
        const tip: string = `<color=#ff0000>${text}</color>`;
        this.showTipText(tip);
    }

    private onHideTipText(): void {
        this.tipText.string = '';
        this.node.active = false;
    }

    //#endregion

    private showTipText(tip: string): void {
        this.node.active = true;
        this.tipText.string = tip;
    }
}