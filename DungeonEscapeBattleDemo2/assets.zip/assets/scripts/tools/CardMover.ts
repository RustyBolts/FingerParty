import { _decorator, Component, Node, UITransform, Vec3, tween } from "cc";

const { ccclass } = _decorator;

@ccclass('CardMover')
export class CardMover extends Component {
    /**
     * Moves a card node from its current parent to a new parent node.
     * @param cardNode The card node to move.
     * @param newParent The new parent node.
     * @param targetLocalPosition The local position within the new parent node.
     */
    static moveCard(cardNode: Node, newParent: Node, targetLocalPosition: Vec3, delay: number = 0.02, duration: number = 0.25): Promise<void> {
        // 原父節點
        const oriParent = cardNode.parent;
        if (oriParent === newParent) {
            // 若原父節點與新父節點相同，直接調用 animateCardMovement 函式
            return this.animateCardMovement(cardNode, targetLocalPosition, delay, duration);
        }

        // 獲取卡牌在世界座標系中的位置
        const worldPosition = oriParent.getComponent(UITransform).convertToWorldSpaceAR(cardNode.position);

        // 將卡牌從原父節點移除
        cardNode.removeFromParent();

        // 添加到新的父節點
        cardNode.parent = newParent;

        // 將世界座標轉換為新父節點的局部座標
        const localPosition = newParent.getComponent(UITransform).convertToNodeSpaceAR(worldPosition);
        cardNode.setPosition(localPosition);

        // 更新顯示卡牌實體的動畫顯示
        return this.animateCardMovement(cardNode, targetLocalPosition, delay, duration);
    }

    /**
     * Animates the movement of the card to the target position.
     * @param cardNode The card node to animate.
     * @param targetPosition The target position in local coordinates of the new parent.
     */
    private static animateCardMovement(cardNode: Node, targetPosition: Vec3, delay: number, duration: number): Promise<void> {
        // 卡牌移動至目標位置
        return new Promise(resolve => {
            // 定義延遲和回調序列
            let delayAndCall = tween()
                .delay(delay)           // 延遲時間
                .call(() => resolve()); // 在延遲後調用 resolve

            // 定義主要的移動動畫
            let moveToTarget = tween(cardNode)
                .to(duration, { position: targetPosition }, { easing: 'quadInOut' });

            // 使用 parallel 組合兩個 tween
            tween(cardNode)
                .parallel(moveToTarget, delayAndCall)
                .start();
        });
    }

    /**
     * Scatter cards around a central node within specified min and max distances.
     * @param cards Array of card nodes to animate.
     * @param centerNode The central node to scatter from.
     * @param distanceRange [Minimum distance from the center, Maximum distance from the center.]
     * @param duration The duration of the animation.
     */
    static scatterCards(cards: Node[], centerNode: Node, distanceRange: number[], duration: number): Promise<void> {
        return new Promise((resolve) => {
            cards.forEach(card => {
                const minDistance = distanceRange[0];
                const maxDistance = distanceRange[1];
                const angle = Math.random() * 2 * Math.PI; // Random angle in radians
                const distance = minDistance + Math.random() * (maxDistance - minDistance); // Random distance within range
                const direction = new Vec3(Math.cos(angle), Math.sin(angle), 0); // Calculate the direction vector on the XY plane
                const targetPosition = Vec3.scaleAndAdd(new Vec3(), centerNode.position, direction, distance); // Calculate target position

                // Animate the card moving to the target position
                tween(card)
                    .to(duration, { position: targetPosition }, { easing: 'cubicOut' })
                    // .to(duration, { position: targetPosition }, { easing: 'quadOut' })
                    .call(() => resolve())
                    .start();
            });
        });
    }
}
