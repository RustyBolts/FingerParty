import { _decorator, Component, Sprite, Texture2D } from 'cc';
const { ccclass, property } = _decorator;

/**
 * https://blog.csdn.net/qq_33022961/article/details/132288336
 * 延展保持原图像素
 */
@ccclass('pixel')
export class pixel extends Component {

    protected onLoad(): void {
        const sprite = this.node.getComponent(Sprite);
        const texture = sprite.spriteFrame?.texture;
        if (texture) {
            texture.setFilters(Texture2D.Filter.NONE, Texture2D.Filter.NONE);
        }
    }
}