import { _decorator, Component, Node, ScrollView, UITransform, v2, v3, Vec3 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('DynamicWidthScrollView')
export class DynamicWidthScrollView extends Component {
    @property(ScrollView)
    scrollView: ScrollView = null;

    @property
    maxWidth: number = 200;

    @property
    minWidth: number = 10;

    @property
    spacingX: number = 2;

    centerPosition;

    protected onLoad(): void {
        // 確保ScrollView組件存在
        if (!this.scrollView) {
            console.warn("ScrollView component is not assigned.");
            return;
        }
        this.centerPosition = this.scrollView.getComponent(UITransform).convertToWorldSpaceAR(new Vec3(0, 0, 0));

        // 監聽ScrollView的滾動事件
        this.scrollView?.node?.on('scrolling', this.onScrolling, this);
    }

    protected onDestroy(): void {
        // 移除監聽事件
        this.scrollView?.node?.off('scrolling', this.onScrolling, this);
    }

    onScrolling() {
        // const midWidth = this.maxWidth - this.minWidth;
        const children = this.scrollView.content.children; // 獲取ScrollView內容的所有子節點
        // const centerPosition = this.scrollView.getComponent(UITransform).convertToWorldSpaceAR(new Vec3(0, 0, 0));
        const viewContentTrans = this.scrollView.content.getComponent(UITransform);

        for (const child of children) {
            const childPosition = viewContentTrans.convertToWorldSpaceAR(child.position);
            const distance = Vec3.distance(childPosition, this.centerPosition);
            const width = this.calculateWidth(distance);

            // 調整寬度
            child.getComponent(UITransform).width = width;

            // 調整縮放比例
            // const scale = 1 + width / this.maxWidth;
            const scale = Math.min(1 + width / this.maxWidth, 1.3);
            child.scale = v3(scale, scale, 1);
        }
    }

    calculateWidth(distance: number): number {
        // 這裡的計算方法可以根據需求進行調整
        const maxDistance = this.scrollView.node.getComponent(UITransform).width / 2; // 假設最遠距離為ScrollView寬度的一半
        let width = this.minWidth + (this.maxWidth - this.minWidth) * (1 - distance / maxDistance);
        width = Math.max(this.minWidth, Math.min(this.maxWidth, width)); // 確保寬度在最小值和最大值之間
        return width;
    }

}
