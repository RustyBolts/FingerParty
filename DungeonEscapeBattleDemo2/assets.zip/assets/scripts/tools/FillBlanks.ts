import { TipCard } from "../cards/Card";

export interface ReplacedText {
    text: string;
    keywords: string[];
}

export interface ReplacedTipCard {
    text: string;
    tipCards: TipCard[];
}

export class FillBlanks {

    // static emptyString = '_____';
    /**
     * 處理填入空格的問題卡，顯示問答組合
     * @param question 
     * @param answers 
     * @returns 
     */
    static answerQuestion(question: string, answers: string[], color: string = '#FFFF00'): string {
        var answerList: string[] = answers.slice();

        // 使用正则表达式替换字符串中的占位符
        return question.replace(/_/g, function (match) {
            // 依次从数组中取出单词填充占位符
            // return `<color=${color}><u>${answerList.shift() || '_'}</u></c>`;
            return `<color=${color}>${answerList.shift() || '_'}</c>`;
        });

        // e.g.
        // question:'ab_cde_df', answers:['1','2']
        // return: 'ab<color=#FFFF00><u>1</u></c>cde<color=#FFFF00><u>2</u></c>df'
    }

    // 將 texts 中的[文字]取代為 _，保留空格作為"推理"的題目
    static replaceKeywordsWidthBlanks(texts: string[]): ReplacedText[] {
        const replacedList: ReplacedText[] = [];
        for (let i = 0; i < texts.length; i++) {
            const { text, keywords } = this.replaceAndStore(texts[i], /\[(.*?)\]/g, '_');
            replacedList.push({ text, keywords });
        }
        return replacedList;
    }

    static replaceMarkedWithKeywords(texts: string[], keepWords: string[]): ReplacedTipCard[] {
        const replacedTips: ReplacedTipCard[] = [];
        for (let i = 0; i < texts.length; i++) {
            const content = texts[i];
            const { text, keywords } = this.markNewKeywords(content, keepWords);

            // 將 conditionText 中的關鍵字取代為 _，保留空格作為"推理"的題目 (這邊是分兩段走，先把題目答案分出來，下一段再合起來，可以考慮再寫一個方法一次搞定)
            const markedTexts: string[] = [];
            const tipCards: TipCard[] = keywords.map((keyword: string) => {
                const tipCard: TipCard = this.keywordToTipCard(keyword);
                markedTexts.push(tipCard.string);
                return tipCard;
            });

            replacedTips.push({
                text: FillBlanks.answerQuestion(text, markedTexts),
                tipCards
            });
        }

        return replacedTips;
    }

    private static keywordToTipCard(keyword: string): TipCard {
        const splits = keyword.split(' | ');
        const word = splits.shift();
        var tipCard = new TipCard();
        tipCard.string = word;
        splits.forEach((s, i) => {
            var ary = s.split(':');
            tipCard[ary[0]] = ary[1];
        });
        return tipCard;
    }

    private static markNewKeywords(contentText: string, keepWords: string[]): ReplacedText {
        const pattern = /\[(.*?)\]/g;
        // 把帶有關鍵字的文字，跟 keepWords 比對，如果有匹配的關鍵字，就把關鍵字的文字先取代為 keepWords 中的文字，下面就不做Marked的動作
        keepWords.forEach((word) => {
            if (contentText.indexOf(word) > -1) {
                contentText = contentText.replace(pattern, (match, p1) => {
                    if (p1 === word)
                        return word;
                    return match;
                });
            }
        });

        return this.replaceAndStore(contentText, pattern, '_');
    }

    private static replaceAndStore(contentText: string, reg: RegExp, replaceWith: string): ReplacedText {
        const keywords: string[] = [];
        const replacedText = contentText.replace(reg, (match, group) => {
            keywords.push(group);
            return replaceWith;
        });
        return { text: replacedText, keywords };
    }
}