import { _decorator, Button, Component, EditBox, instantiate, Label, Node } from 'cc';
import { RoomHandler } from './connection/rooms/RoomHandler';
import { SocketBridge } from './connection/SocketBridge';
import { DungeonEscapeHandler } from './cards/DungeonEscapeHandler';
import { DungeonEscapeView } from './cards/DungeonEscapeView';
import { EventManager } from './managers/EventManager';
import { GameLogicEvent, WordPuzzleGameLogicEvent } from './managers/GameEvents';
import { FillBlanks } from './tools/FillBlanks';
import { CardMover } from './tools/CardMover';
const { ccclass, property } = _decorator;

const PLAYER_TEMP = 'YC_PLAYER_TEMP';

@ccclass('MainScene')
export class MainScene extends Component {

    @property(Node)
    roomRoot: Node = null;

    @property(Node)
    tableRoot: Node = null;

    @property(Button)
    refreshRoomButton: Button = null;

    @property(Button)
    newRoomButton: Button = null;

    @property(Button)
    leaveRoomButton: Button = null;

    @property(Button)
    readyGameButton: Button = null;

    @property(Button)
    startGameButton: Button = null;

    @property(EditBox)
    nameEditBox: EditBox = null;

    @property(DungeonEscapeView)
    gameView: DungeonEscapeView = null;

    @property(Node)
    spreadCardRoot: Node = null;

    _roomHandler = null;
    _gameHandler = null;

    _indexGameReady = 0;

    _playerLocalCacheName = '';

    start() {
        // const urlParams = new URLSearchParams(location.search);
        // const user = urlParams.get('user') || '0';
        // this._playerLocalCacheName = `${PLAYER_TEMP}_${user}`;

        // const roomInfo = urlParams.get('room').split('-');
        // const playerTemp = localStorage.getItem(this._playerLocalCacheName);
        // var nickname;

        // if (playerTemp) {
        //     const playerInfo = JSON.parse(playerTemp);
        //     nickname = playerInfo.nickname;
        // } else {
        //     let randomName = `冒險者-${Math.round(Math.random() * 1000)}`;
        //     nickname = randomName;
        // }

        // this.tableRoot.active = false;
        // this.readyGameButton.node.active = false;
        // this.startGameButton.node.active = false;
        // this.leaveRoomButton.node.active = false;

        // SocketBridge.Instance.connect(roomInfo)
        //     .then(() => {
        //         this.nameEditBox.string = nickname;

        //         this._roomHandler = new RoomHandler(user, nickname);

        //         // 事件處理
        //         this._roomHandler.eventUpdateTableList = this.onUpdateTableList.bind(this);
        //         this._roomHandler.eventUpdateRoomList = this.onUpdateRoomList.bind(this);
        //         this._roomHandler.eventGameReady = this.onGameReady.bind(this);
        //         this._roomHandler.eventGameStart = this.onGameStart.bind(this);
        //         this._roomHandler.eventGameReconnect = this.onGameReconnect.bind(this);

        //         // this._roomHandler.load();//把問答的資料先暫存在本地，怕洗掉

        //         if (!this._roomHandler.tryReconnect())
        //             this.onUpdateRoomList();
        //     });

        // 測效能
        // function run(){
        //     //耗时代码开始
        //     for (var i = 0; i < 100000000; i++) {
        //     var p = i % 2;
        //     }
        //     //耗时代码结束
        //     }
        //在 catch 中内联代码的耗时情况
        // var t = new Date();
        // try {
        //     throw new Error();
        // } catch (e) {
        //     run();
        // }
        // document.write(new Date() - t);
    }

    onRenameEndEdit() {
        const nickname = this.nameEditBox.string;
        this._roomHandler.nickname = nickname;

        localStorage.setItem(this._playerLocalCacheName, JSON.stringify({ nickname }));
    }

    onNewRoomClicked() {
        this._roomHandler.newRoom(`YC-${Math.round(Math.random() * 100000)}`);

        this.roomRoot.active = false;
        this.refreshRoomButton.node.active = false;
        this.newRoomButton.node.active = false;

        this.tableRoot.active = true;
        this.readyGameButton.node.active = false;
        this.startGameButton.node.active = true;
        this.leaveRoomButton.node.active = true;

        // 拉進房間裡面
    }

    onJoinRoom(id, key, lockKey?) {
        this.roomRoot.active = false;
        this.refreshRoomButton.node.active = false;
        this.newRoomButton.node.active = false;
        this.nameEditBox.node.active = false;

        this.tableRoot.active = true;
        this.readyGameButton.node.active = true;
        this.startGameButton.node.active = false;
        this.leaveRoomButton.node.active = true;

        this._roomHandler.joinRoom(id, key, lockKey);
    }

    onUpdateTableList(playerList) {
        this.nameEditBox.node.active = false;

        var tableChildren = this.tableRoot.children;
        tableChildren.forEach(x => x.active = false);

        Object.keys(playerList).forEach((playerID, i) => {
            var nickname = playerList[playerID];

            let tableNode = tableChildren[i];
            if (!tableNode) {
                tableNode = instantiate(tableChildren[0]);
                tableNode.parent = this.tableRoot;
            }
            tableNode.active = true;

            // 名字列出
            // tableNode.getComponentInChildren(Label).string = `${nickname}(${playerID})`;
            tableNode.getComponentInChildren(Label).string = nickname;
        });
    }

    /** 離開房間 */
    onExitRoomClicked() {
        this._roomHandler.leaveRoom();

        // 畫面移回房間清單
        this.onUpdateRoomList();
    }

    onUpdateRoomList() {
        var roomChildren = this.roomRoot.children;
        roomChildren.forEach(x => x.active = false);

        this.roomRoot.active = true;
        this.refreshRoomButton.node.active = true;
        this.newRoomButton.node.active = true;

        this.tableRoot.active = false;
        this.readyGameButton.node.active = false;
        this.startGameButton.node.active = false;
        this.leaveRoomButton.node.active = false;

        this.nameEditBox.node.active = true;

        this._indexGameReady = 0;

        // this.gameView.close();

        // 取得房間清單
        this._roomHandler.loadRoomsAsync()
            .then((rooms) => {
                if (!rooms) {
                    return;
                }

                // 佈置房間清單的進入按鈕
                Object.keys(rooms).forEach((roomID, i) => {
                    let room = rooms[roomID];
                    let roomNode = roomChildren[i];
                    if (!roomNode) {
                        roomNode = instantiate(roomChildren[0]);
                        roomNode.parent = this.roomRoot;
                    }
                    roomNode.active = true;

                    // id 列出
                    roomNode.getComponentInChildren(Label).string = roomID;

                    // key 送出時驗證
                    roomNode.getComponent(Button).node.off('click');
                    roomNode.getComponent(Button).node.once('click', () => this.onJoinRoom(roomID, room), this);
                });
            });
    }

    onGameReady(readyPlayerList, playerList) {
        console.log('onGameReady:', readyPlayerList, playerList);
        var tableChildren = this.tableRoot.children;

        Object.keys(playerList).forEach((playerID, i) => {
            const nickname = playerList[playerID];
            const readyStatus = readyPlayerList[playerID];
            const tableNode = tableChildren[i];

            // 名字列出 "Ready"
            // tableNode.getComponentInChildren(Label).string = `${nickname}(${playerID}) ${['','[READY]','[HONST]'][readyStatus]}`;
            tableNode.getComponentInChildren(Label).string = `${nickname} ${['', '[READY]', '[HONST]'][readyStatus]}`;
            /**
             * index.esm2017.js:648 Uncaught TypeError: Cannot read properties of undefined (reading 'getComponentInChildren')
                at MainScene.ts:215:23
                at Array.forEach (<anonymous>)
                at MainScene.onGameReady (MainScene.ts:208:33)
                at RoomHandler.notify_game_ready (RoomHandler.ts:449:9)
                at NotifyKeyMap.onReceive (bridge.ts:171:30)
                at bridge.ts:49:73
                at Array.forEach (<anonymous>)
                at bridge._onReceive (bridge.ts:49:34)
                at callback (bridge.ts:105:41)
                at bridge.ts:109:21
             */
        });
    }

    onGameStart(roomID, playerID, nickname) {
        console.log('開始遊戲', this._roomHandler.isHonster);

        this.roomRoot.active = false;
        this.refreshRoomButton.node.active = false;
        this.newRoomButton.node.active = false;

        this.tableRoot.active = false;
        this.readyGameButton.node.active = false;
        this.startGameButton.node.active = false;

        const isReconnect = false;
        this._gameHandler = new DungeonEscapeHandler(this.gameView, this._roomHandler.isHonster, roomID, playerID, nickname, isReconnect, this._roomHandler.players);
        this.leaveRoomButton.node.active = this._roomHandler.isHonster;// client都不能自行離開
        // if (this._roomHandler.isHonster) {
        //     this.gameView.init(roomID, playerID, nickname, isReconnect, this._roomHandler.players);
        // } else {
        //     this.gameView.init(roomID, playerID, nickname, isReconnect);
        //     this.leaveRoomButton.node.active = false;// 玩家都不能自行離開
        // }

        // this.gameView.eventMainSceneGameEnd = () => {
        //     this.leaveRoomButton.node.active = true;
        // };
    }

    onGameReconnect(roomID, playerID, nickname, players?) {
        console.log('遊戲重連!!');

        const isReconnect = true;
        const isHonster = players && Object.keys(players).length > 0;

        this._gameHandler = new DungeonEscapeHandler(this.gameView, isHonster, roomID, playerID, nickname, isReconnect, this._roomHandler.players);

        // if (isHonster)
        //     this.gameView.init(roomID, playerID, nickname, isReconnect, this._roomHandler.players);
        // else
        //     this.gameView.init(roomID, playerID, nickname, isReconnect);

        this.roomRoot.active = false;
        this.refreshRoomButton.node.active = false;
        this.newRoomButton.node.active = false;

        this.nameEditBox.node.active = false;

        this.leaveRoomButton.node.active = isHonster;// 玩家都不能自行離開

        // this.gameView.eventMainSceneGameEnd = () => {
        //     this.leaveRoomButton.node.active = true;
        // };
    }

    onRefreshRoomClicked() {
        this.onUpdateRoomList();
    }

    onGameReadyClicked() {
        this._indexGameReady = (this._indexGameReady + 1) % 2;
        this._roomHandler.gameReady(this._indexGameReady);
    }

    onGameStartClicked() {
        this._roomHandler.tryGameStart();
    }
}


