// // import Logging from "../tools/Logging";
// import FirebaseBridge from "./FirebaseBridge";

// // const logger = new Logging();

// export class SocketBridge {
//     private static _instance: SocketBridge;

//     private _bridge = new FirebaseBridge();
//     private _connectID = '';
//     private _broadcastList: string[] = [];

//     private constructor() {
//         //...
//     }

//     public static get Instance() {
//         return this._instance || (this._instance = new this());
//     }

//     // public connect(roomInfo) {
//     //     return this._bridge.signInWithGoogleEmail(`xxfox${roomInfo[0]}@gmail.com`, roomInfo[1]);
//     // }
//     public async connect(roomInfo) {
//         try {
//             const userID = await this._bridge.signInWithGoogleEmail(`xxfox${roomInfo[0]}@gmail.com`, roomInfo[1]);
//             // await logger.info(`用戶 ${userID} 已連接`);
//             return userID;
//         } catch (error) {
//             // await logger.error(`連接失敗: ${error.message}`);
//             throw error;
//         }
//     }

//     addDispatcher(connectID, scope, keymap) {
//         this._bridge.addDispatcher(connectID, scope, keymap);
//     }

//     removeDispatcher(connectID, scope) {
//         this._bridge.removeDispatcher(connectID, scope);
//     }

//     loadAsync(foldName, labelName?) {
//         return this._bridge.loadAsync(foldName, labelName);
//     }

//     /**
//      * 建立 Honster 連線: Client 將請求送給 Honster 時的監聽
//      * @param connectID 
//      */
//     addHonsterConnection(connectID) {
//         this._connectID = connectID;

//         // 監聽 請求事件
//         this._bridge.addConnection(connectID, 'Applicate');
//     }

//     /**
//      * 建立 Client 連線: Honster 處理完事件後，廣播給 Clients 的監聽
//      * @param connectID 
//      * @param clientID 
//      */
//     addClientConnection(connectID, clientID) {
//         // 目前一次只做一個 Honster 處理，暫時不做一次好幾個 Honster 處理
//         this._connectID = connectID;

//         // 監聽 廣播事件
//         this._bridge.addConnection(connectID, 'Broadcast', clientID);// 每個 client 監聽自己的clientID 就好
//     }

//     honsterDisconnect() {
//         this._bridge.delConnection(this._connectID, 'Applicate');
//         this._bridge.uploadInfo(this._connectID, '', '', 'Applicate');
//         this._connectID = '';
//     }

//     clientDisconnect(clientID?) {
//         if (clientID) {
//             this._bridge.delConnection(this._connectID, 'Broadcast', clientID);
//             this._bridge.uploadInfo(this._connectID, '', '', 'Broadcast', clientID);
//         }
//         else {
//             this._broadcastList.forEach(id => {
//                 this._bridge.delConnection(this._connectID, 'Broadcast', id);
//                 this._bridge.uploadInfo(this._connectID, '', '', 'Broadcast', id);
//             });
//         }

//         this.delBroadcastList(clientID);
//     }

//     addToBroadcastList(id: string) {
//         this._broadcastList.push(id);
//         console.log('新增', id, this._broadcastList);
//     }

//     delBroadcastList(id?) {
//         if (id) {
//             if (this._broadcastList.indexOf(id) > -1) {
//                 this._broadcastList.splice(this._broadcastList.findIndex(x => x === id), 1);
//                 console.log('刪除', id, this._broadcastList);
//             }
//         } else {
//             console.log('刪除', this._broadcastList, this._broadcastList);
//             this._broadcastList.length = 0;
//         }
//     }

//     /**
//      * Client -> Honster 的事件請求
//      * @param key 
//      * @param value 
//      */
//     applicate(key, value) {
//         this._bridge.uploadInfo(this._connectID, key, value, 'Applicate');
//     }

//     /**
//      * Honster -> Client 的事件發送
//      * @param key 
//      * @param value 
//      * @param clientID 不帶指定 client id 時，對全部有紀錄的client 廣播
//      */
//     broadcast(key, value, clientID?) {
//         if (!this._connectID) {
//             return console.log('Honster 已斷線');
//         }

//         if (clientID) {
//             console.log(key, '廣播對象:', clientID);
//             this._bridge.uploadInfo(this._connectID, key, value, 'Broadcast', clientID);
//         } else {
//             console.log(key, '廣播對象:', this._broadcastList);
//             this._broadcastList.forEach((id) => this._bridge.uploadInfo(this._connectID, key, value, 'Broadcast', id));
//         }
//     }

//     addDataLabel(labelName, data?) {
//         this._bridge.addDataLabel(labelName, data);
//     }
//     delDataLabel(labelName) {
//         this._bridge.delDataLabel(labelName);
//     }
// }