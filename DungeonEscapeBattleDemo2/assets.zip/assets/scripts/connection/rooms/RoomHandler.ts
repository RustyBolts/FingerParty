// import { SocketBridge } from "../SocketBridge";
// import { RandomString } from "../../tools/RandomString";

// const ROOM_TEMP = 'DE_ROOM_TEMP';

// interface RoomInfo {
//     id: string;
//     key: string;
//     lockKey: string;
// }

// export class RoomHandler {
//     private roomInfo: RoomInfo;
//     private eventHandlers: { [key: string]: Function } = {};

//     _roomLocalCacheName = '';
//     _needReconnect = false;

//     isHonster = false;
//     players = {};
//     _readyPlayers = {};

//     _roomList = [];
//     _roomID = '';
//     _roomKey = '';
//     _roomLockKey = '';

//     _joinRoomInterval;
//     _isRoomJoining = false;

//     _playerID = '';
//     _nickname = '';

//     eventUpdateTableList: Function = null;
//     eventUpdateRoomList: Function = null;
//     eventGameReady: Function = null;
//     eventGameStart: Function = null;
//     eventGameReconnect: Function = null;

//     constructor(user, nickname) {
//         this._roomLocalCacheName = `${ROOM_TEMP}_${user}`;

//         this.roomInfo = { id: '', key: '', lockKey: '' };

//         // 替自己建一個在房間裡使用的id，這個id 用來辨識身份以監聽對應的廣播事件
//         this._playerID = RandomString.generate();

//         this._nickname = nickname;
//     }

//     set nickname(value) {
//         this._nickname = value;
//     }

//     private getEventHandlers(): { [key: string]: Function } {
//         return {
//             'join_room': this.notify_join_room.bind(this),
//             'take_seat': this.notify_take_seat.bind(this),
//             'leave_room': this.notify_leave_room.bind(this),
//             'kicked_out': this.notify_kicked_out.bind(this),
//             'game_ready': this.notify_game_ready.bind(this),
//             'game_start': this.notify_game_start.bind(this),
//         };
//     }

//     private handleRoomTimeout(roomID: string): void {
//         // 時間到如果無回應就結束房間的連線
//         this._isRoomJoining = true;
//         this._joinRoomInterval && clearTimeout(this._joinRoomInterval);
//         this._joinRoomInterval = setTimeout(() => {
//             if (this._isRoomJoining) {
//                 console.log('沒有對應的 Honster 回應');

//                 // 沒有 Honster 要自己清掉資料庫的 Broadcast 欄位
//                 SocketBridge.Instance.clientDisconnect(this._playerID);
//                 console.log('只能把自己的 Broadcast 欄位移除');

//                 // 也要把房間從清單移除掉
//                 SocketBridge.Instance.delDataLabel(`ROOMS/${roomID}`);
//                 console.log(`代替斷線的 Honster 把${roomID}從房間清單移除`);

//                 SocketBridge.Instance.removeDispatcher(this._roomID, this);

//                 this._clearRoomInfo();

//                 this.eventUpdateRoomList?.call(this);
//             }
//         }, 1000);
//     }

//     _applicate(key, value = '') {
//         if (!this.isHonster) {
//             SocketBridge.Instance.applicate(key, value);
//         } else {
//             this[`notify_${key}`](this._roomID, key, value);
//         }
//     }

//     /**
//      * 廣播時對指定 Client 發送
//      * @param key 
//      * @param value 
//      * @param clientID 不帶指定 client id 時，對全部有紀錄的client 廣播
//      */
//     _broadcast(key, value = '', clientID?) {
//         // 廣播不會發給 Honster
//         if (this.isHonster) {
//             console.log(key, value, 'clientID?:', clientID);
//             if (clientID === this._playerID) {
//                 return console.log('不會發給自己');
//             }
//             SocketBridge.Instance.broadcast(key, value, clientID);
//         }
//     }

//     loadRoomsAsync() {
//         return SocketBridge.Instance.loadAsync('ROOMS')
//             .then((rooms: any) => this._roomList = rooms);
//     }

//     newRoom(roomID, lockKey = '0') {
//         // 新建房間基本資訊，並推進資料庫
//         const roomKey = RandomString.generate();
//         this._roomID = roomID;
//         this._roomKey = roomKey;

//         SocketBridge.Instance.addDataLabel(`ROOMS/${roomID}`, roomKey);

//         // 建立時，可以設定密碼，或無密碼(實際上預設為0)
//         this._roomLockKey = lockKey;

//         // 成為 Honster
//         this.isHonster = true;

//         // honster 自己發給自己 joinRoom
//         this.joinRoom(this._roomID, this._roomKey, this._roomLockKey);
//     }

//     async joinRoom(roomID: string, roomKey: string, roomLockKey = '0'): Promise<void> {
//         try {
//             console.log('Joining room:', roomID);

//             const roomInfo: RoomInfo = { id: roomID, key: roomKey, lockKey: roomLockKey };
//             await SocketBridge.Instance.addDispatcher(roomID, this, this.getEventHandlers());

//             if (this.isHonster) {
//                 // Honster 建立連線
//                 await SocketBridge.Instance.addHonsterConnection(roomID);
//             } else {
//                 // Client 建立連線
//                 await SocketBridge.Instance.addClientConnection(roomID, this._playerID);
//                 this.handleRoomTimeout(roomID);
//             }

//             this.roomInfo = roomInfo;

//             this._applicate('join_room', `${this._playerID} ${roomKey} ${roomLockKey}`);
//             console.log('Player [', this._playerID, '] send joinRoom: id/roomkey:[', roomKey, '] & roomLockKey:[', roomLockKey, ']');

//         } catch (error) {
//             console.error('Failed to join room:', error);
//             throw error;
//         }
//     }

//     async tryReconnect() {
//         const roomTemp = localStorage.getItem(this._roomLocalCacheName);
//         if (roomTemp) {
//             this._needReconnect = true;

//             const room = JSON.parse(roomTemp);
//             console.log('斷線重連:', room);

//             this.isHonster = room.isHonster;

//             if (room.playerID) {
//                 console.log('重連後修改自己的playerID:', this._playerID, '->', room.playerID);

//                 this._playerID = room.playerID;
//             }

//             this._roomID = room.roomID;
//             this._roomKey = room.roomKey;
//             this._roomLockKey = room.roomLockKey;

//             this.players = room.players;

//             await this.joinRoom(this._roomID, this._roomKey);

//             return true;
//         }

//         return false;
//     }

//     leaveRoom() {
//         console.log('leave room this._isHonster:', this.isHonster);
//         // Honster 離開房間，同樣也會把房間關閉掉
//         if (this.isHonster) {
//             console.log('發出 kicked_out!!! 然後斷線');
//             // 廣播通知所有 Client 離開房間
//             this._broadcast('kicked_out');

//             /** 處理斷線 */

//             // 中斷監聽
//             SocketBridge.Instance.honsterDisconnect();
//             SocketBridge.Instance.delBroadcastList();//清掉全部的廣播對象

//             // 從房間清單移除
//             SocketBridge.Instance.delDataLabel(`ROOMS/${this._roomID}`);

//         } else {
//             // 通知 Honster 此 PlayerID 離開房間。可以不用等回應，丟出去就可以離開了
//             SocketBridge.Instance.applicate('leave_room', this._playerID);

//             // 中斷監聽
//             SocketBridge.Instance.clientDisconnect(this._playerID);
//         }

//         SocketBridge.Instance.removeDispatcher(this._roomID, this);

//         this.eventUpdateRoomList?.call(this);

//         this._clearRoomInfo();
//     }

//     _clearRoomInfo() {
//         // 移除本地暫存
//         localStorage.removeItem(this._roomLocalCacheName);

//         // 移除房間基本資訊
//         this._roomID = '';
//         this._roomKey = '';

//         // 移除密碼，或無密碼(實際上預設為0)
//         this._roomLockKey = '0';

//         // 恢復一般身份
//         this.isHonster = false;

//         this.players = {};
//         this._readyPlayers = {};
//     }

//     // c->h join_room [PlayerID] [RoomKey] [0|RoomLockKey]
//     // h->c join_room [PlayerID] [success0] [msg]
//     // h->c join_room [PlayerID] [success1]
//     private notify_join_room(roomID: string, key: string, value: string): void {
//         var playerID;

//         if (this.isHonster) {
//             const honsterData = value.split(' ');

//             playerID = honsterData[0];

//             // 處理送來的房間資訊
//             const roomKey = honsterData[1];
//             const roomLockKey = honsterData[2];

//             console.log('this._roomKey:', this._roomKey, '---room key:', roomKey);

//             if (this._roomKey != roomKey) {
//                 let msg = '不符合的 room key';
//                 console.log(msg);

//                 value = `${playerID} 0 ${msg}`;
//                 this._broadcast(key, value, playerID);
//             }
//             else if (this._roomLockKey != roomLockKey) {
//                 let msg = `輸入錯誤的密碼: ${roomLockKey}`;
//                 console.log(msg);

//                 value = `${playerID} 0 ${msg}`;
//                 this._broadcast(key, value, playerID);
//             }
//             else {
//                 // 將這個 ClientID 加入廣播清單 (Honster 不廣播給自己，不要佔用一條連線)
//                 if (this._playerID != playerID)
//                     SocketBridge.Instance.addToBroadcastList(playerID);

//                 // 傳遞給請求加入房間的玩家，成功加入房間
//                 value = `${playerID} 1`;
//                 this._broadcast(key, value, playerID);
//             }
//         }

//         const clientData = value.split(' ');

//         playerID = clientData[0];
//         if (playerID != this._playerID) {
//             console.log('playerID 不同', playerID, this._playerID);
//             return;
//         }

//         const success = clientData[1] === '1';

//         if (this._needReconnect) {
//             if (success) {
//                 this.eventGameReconnect?.(roomID, playerID, this._nickname, this.players);

//                 this._joinRoomInterval && clearTimeout(this._joinRoomInterval);

//                 console.log('重連成功');
//             } else {
//                 console.log('重連失敗: 已失去房間連結');
//             }

//             this._needReconnect = false;

//             return;
//         }

//         if (success) {
//             this._roomID = roomID;

//             this._isRoomJoining = false;

//             console.log(this._nickname, '成功加入房間!!');
//             this._applicate('take_seat', `${playerID} ${this._nickname}`);
//         } else {
//             var msg = clientData[2];
//             console.log(key, 'error:', msg);//todo 做個彈出警告之類的
//             // SocketBridge.Instance.clientDisconnect(playerID);

//             // // 移除房間事件的註冊
//             // SocketBridge.Instance.removeDispatcher(roomID, this);

//             this.leaveRoom();
//         }

//     }

//     // c->h: [PlayerID] [Nickname]
//     // h->c: [Players]
//     notify_take_seat(roomID, key, value) {
//         var playerID, nickname;

//         if (this.isHonster) {
//             const honsterData = value.split(' ');

//             playerID = honsterData[0];
//             nickname = honsterData[1];
//             console.log(nickname, playerID, '進行入桌');

//             // 入桌並將玩家資訊暫存起來
//             this.players[playerID] = nickname;

//             value = `${playerID} ${JSON.stringify(this.players)}`;
//             this._broadcast(key, value);
//         }

//         const clientData = value.split(' ');
//         playerID = clientData[0];
//         const playerInfo = JSON.parse(clientData[1]);

//         this.eventUpdateTableList?.call(this, playerInfo);

//         if (this._playerID === playerID) {
//             this.gameReady(0);
//         }
//     }

//     // c->h: [PlayerID]
//     // h->c: [Players] [LeaveNickname]
//     notify_leave_room(roomID, key, value) {
//         var playerID = value, nickname;

//         if (this.isHonster) {
//             nickname = this.players[playerID];

//             // 刪掉離桌的玩家資訊
//             delete this.players[playerID];
//             // todo 本地暫存 {[newPlayerID]:nickname}
//             delete this._readyPlayers[playerID];

//             // 中斷監聽、移掉連線欄位
//             SocketBridge.Instance.delBroadcastList(playerID);
//             SocketBridge.Instance.clientDisconnect(playerID);
//             console.log('離開房間斷線:', playerID);

//             value = `${JSON.stringify(this.players)} ${nickname}`;
//             this._broadcast(key, value);
//         }

//         const clientData = value.split(' ');
//         const players = JSON.parse(clientData[0]);
//         const leaveNickname = clientData[1];

//         console.log('players:', players);
//         this.eventUpdateTableList?.call(this, players);
//         console.log(leaveNickname, '離開房間了');
//     }

//     notify_kicked_out(roomID, key, value) {
//         if (this.isHonster) {
//             SocketBridge.Instance.clientDisconnect();
//         } else {
//             /** 房主將所有人踢掉，接收到的都要處理回房間清單的流程 */

//             // 移除 Client 連線
//             // SocketBridge.Instance.clientDisconnect(this._playerID);
//             // console.log('移掉自己的client 連線:', this._playerID);

//             // 移除房間事件的註冊
//             SocketBridge.Instance.removeDispatcher(roomID, this);

//             // 恢復房間清單
//             this.eventUpdateRoomList?.call(this);

//             // 清掉資訊
//             this._clearRoomInfo();
//         }
//         console.log('有收到 kicked out哦!!');
//     }

//     // c->h: [PlayerID] [Ready1|0]
//     // h->c: [ReadyPlayerIDs] [Players]
//     notify_game_ready(roomID, key, value) {
//         console.log('收到 notify_game_ready');
//         var playerID;

//         if (this.isHonster) {
//             const hostnerData = value.split(' ');
//             playerID = hostnerData[0];

//             const indexReady = hostnerData[1];// = 0|1

//             this._readyPlayers[playerID] = indexReady;
//             console.log('ready player:', this._readyPlayers);

//             value = `${JSON.stringify(this._readyPlayers)} ${JSON.stringify(this.players)}`;
//             this._broadcast(key, value);
//         }

//         const clientData = value.split(' ');
//         const readyPlayers = JSON.parse(clientData[0]);
//         const players = JSON.parse(clientData[1]);
//         this.eventGameReady?.(readyPlayers, players);
//     }

//     // h->c: [PlayerIDs]
//     notify_game_start(roomID, key, value) {
//         console.log('收到 notify_game_start', this.isHonster);

//         if (this.isHonster) {
//             this._broadcast(key);

//             // SocketBridge.Instance.honsterDisconnect();

//             // 從房間清單移除 (除非斷線重連，不然不會再讓人進來)
//             SocketBridge.Instance.delDataLabel(`ROOMS/${this._roomID}`);
//         } else {
//             // SocketBridge.Instance.clientDisconnect(this._playerID);
//         }

//         this.eventGameStart(roomID, this._playerID, this._nickname);

//         const localData = {
//             roomID: this._roomID,
//             roomKey: this._roomKey,
//             roomLockKey: this._roomLockKey,
//             playerID: this._playerID,
//             isHonster: this.isHonster,
//             players: this.players
//         };
//         localStorage.setItem(this._roomLocalCacheName, JSON.stringify(localData));
//         console.log('\n\n存檔', localData, '\n\n');
//     }

//     gameReady(indexReady) {
//         if (this.isHonster)
//             indexReady = '2';

//         this._applicate('game_ready', `${this._playerID} ${indexReady}`);
//     }

//     tryGameStart() {
//         const readyList = Object.keys(this._readyPlayers);

//         // 除了房主外是否都已經READY
//         const allReady = readyList.length && readyList.every((playerID) => parseInt(this._readyPlayers[playerID], 10) > 0);
//         console.log('準備清單:', this._readyPlayers);
//         if (allReady) {
//             this._applicate('game_start');
//         } else {
//             console.log('尚有人未準備好');
//         }
//     }
// }