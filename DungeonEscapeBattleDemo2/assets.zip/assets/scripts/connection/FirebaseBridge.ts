// import { initializeApp } from 'firebase/app';
// import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
// import { getDatabase, ref, child, onValue, get, set, update, push, off } from 'firebase/database';
// // import Logging from "../tools/Logging";

// const PROJECT = 'DungeonEscape';
// const notifyKeyMaps: { [connectID: string]: NotifyKeyMap[] } = {};
// var database: ReturnType<typeof getDatabase>;
// // const logger = new Logging();

// /**
//  * 步驟 1: 確定錯誤類型
// 首先，你需要了解在與 SocketBridge 交互時可能會遇到哪些錯誤。常見的錯誤類型包括：

// 連線錯誤：無法建立連線或連線遭到拒絕。
// 讀寫錯誤：在數據傳輸過程中發生錯誤。
// 超時錯誤：操作超出了指定的時間限制。
// 解析錯誤：接收到的數據格式不正確或無法解析。
//  */

// /**
//  * 步驟 2: 捕捉與處理錯誤
// 使用適當的異常處理機制（例如 try...except）來捕捉並處理這些錯誤。以下是使用 Python 的 socket 模組作為 SocketBridge 例子的錯誤處理方法：
//  */

// /**
//  * 步驟 3: 錯誤記錄
// 為了更好地追踪和分析錯誤，應該將錯誤信息記錄到日誌中。可以使用 Python 的 await logger 模組來完成這項工作：
//  */

// /**
//  * 步驟 4: 錯誤重試機制
// 對於某些操作，如連線失敗，你可能想要實施自動重試機制。可以設定一個重試次數限制，並在每次重試之間增加等待時間。
//  */

// /**
//  * 連線工具
//  */
// export default class FirebaseBridge {
//     constructor() {
//         const app = initializeApp({
//             apiKey: "AIzaSyAc5PRwmE14gBH5az8TSoqs9aBrQ8YWa4o",
//             authDomain: "fir-test-756e1.firebaseapp.com",
//             databaseURL: "https://fir-test-756e1.firebaseio.com",
//             projectId: "fir-test-756e1",
//             storageBucket: "fir-test-756e1.appspot.com",
//             messagingSenderId: "182531440628"
//         });
//         database = getDatabase(app);
//     }

//     // google 帳號登入
//     async signInWithGoogleEmail(email: string, password: string): Promise<string> {
//         try {
//             const userCredential = await signInWithEmailAndPassword(getAuth(), email, password);
//             return userCredential.user.uid;
//         } catch (error: any) {
//             // await logger.error(`登入失敗: ${error.message}`);
//             throw new Error(`登入失敗: ${error.message}`);
//         }
//     }

//     _onReceive(connectID: string, data: any) {
//         let key = data, value = '';
//         let spaceIndex = data.indexOf(' ');
//         if (spaceIndex > 0) {
//             key = data.slice(0, spaceIndex);
//             value = data.slice(spaceIndex + 1);
//         }
//         // await logger.info(`${connectID}: Received data with key ${key}`);

//         notifyKeyMaps[connectID]?.forEach((notifyKeymap) => notifyKeymap.onReceive(connectID, key, value));
//     };

//     addDispatcher(connectID: string, scope: any, keyMap: { [key: string]: Function }) {
//         if (connectID === '') {
//             // await logger.error('connectID 不能為空白');
//             throw new Error('connectID 不能為空白');
//         }

//         const keyMaps = notifyKeyMaps[connectID] || [];
//         let hadAdd = keyMaps.some((notifyKeymap) => {
//             // 此連線已有註冊過，再新增註冊事件進去
//             if (notifyKeymap.scope === scope) {
//                 // 找到在同一個類註冊的，新增或覆蓋 key與 callback 進去
//                 Object.keys(keyMap).forEach((key) => notifyKeymap.callbackMap[key] = keyMap[key]);
//                 return true;
//             }
//         });
//         // 在未加入對應key 就補進去
//         if (!hadAdd) keyMaps.push(new NotifyKeyMap(scope, keyMap));
//         notifyKeyMaps[connectID] = keyMaps;

//         // await logger.debug(`Added dispatcher for ${connectID}`);
//     };

//     removeDispatcher(connectID, scope) {
//         const keymaps = notifyKeyMaps[connectID];
//         if (keymaps) {
//             const index = keymaps.findIndex((notifyKeymap) => notifyKeymap.scope === scope);
//             if (index !== -1) keymaps.splice(index, 1);
//             if (keymaps.length === 0) delete notifyKeyMaps[connectID];

//             // await logger.debug(`Removed dispatcher for ${connectID}`);
//         }
//     };

//     // ====

//     addConnection(connectID: string, type: string, clientID: string = '') {
//         const refPath = `${PROJECT}/C/${connectID}/${type}/${clientID}`;
//         const callback = (data) => this._onReceive(connectID, data);
//         onValue(ref(database, refPath), (snapshot) => {
//             const data = snapshot.val();
//             console.log('[NOTIFY]', type, clientID, ':', data);
//             data && callback(data);
//         });

//         console.log('加入監聽:', refPath);
//     }

//     delConnection(connectID: string, type: string, clientID: string = '') {
//         const refPath = `${PROJECT}/C/${connectID}/${type}/${clientID}`;
//         off(ref(database, refPath));

//         console.log('移除監聽:', refPath);
//     }

//     uploadInfo(connectID: string, key: string, value: string, type: string, clientID: string = '') {
//         const refPath = `${PROJECT}/C/${connectID}/${type}/${clientID}`;
//         const data = value ? `${key} ${value}` : key;
//         set(ref(database, refPath), data);

//         // console.log(clientID, type, 'upload info:', key, data);
//     }

//     loadAsync(foldName: string, labelName?: string) {
//         const refPath = `${PROJECT}/D/${foldName}/`;
//         return new Promise((resolve) => {
//             // console.log('refPath:', refPath, idOrFoldName);
//             (labelName
//                 ? get(child(ref(database, refPath), labelName))
//                 : get(ref(database, refPath))
//             ).then((snapshot) => {
//                 const data = snapshot.val();
//                 // data && resolve(data);
//                 resolve(data);
//                 console.log(foldName, labelName, '::::', data);
//             });
//         });
//     }

//     addDataLabel(labelName: string, data: any = -1) {
//         const refPath = `${PROJECT}/D`;

//         if (!labelName) {
//             labelName = push(ref(database, refPath)).key || '';
//         } else {
//             console.log(`${labelName}刷新資料:${JSON.stringify(data)}`);
//         }

//         set(ref(database, `${refPath}/${labelName}/`), data);

//         return labelName;
//     }

//     delDataLabel(labelName: string) {
//         const refPath = `${PROJECT}/D`;
//         set(ref(database, `${refPath}/${labelName}/`), null);
//     }
// }

// class NotifyKeyMap {
//     public scope: any;
//     public callbackMap: { [key: string]: Function };

//     constructor(scope: any, keyMap: { [key: string]: Function }) {
//         this.scope = scope;
//         this.callbackMap = keyMap;
//     }

//     // onReceive(connectID: string, key: string, value: string): Promise<void> {
//     onReceive(connectID: string, key: string, value: string) {
//         const callback = this.callbackMap[key];
//         if (callback) {
//             try {
//                 callback.call(this.scope, connectID, key, value);
//             } catch (error: any) {
//                 // await logger.error(`執行回調時錯誤: ${error.message}`);
//                 console.error(`執行回調時錯誤: ${error.message}`);
//             }
//         }
//     }
// }