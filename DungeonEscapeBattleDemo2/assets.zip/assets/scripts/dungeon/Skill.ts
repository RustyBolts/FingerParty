export abstract class Skill {
    name: string;
    level: SkillProficiency;
    description: string;

    constructor(name: string, description:string, level: SkillProficiency = SkillProficiency.Novice) {
        this.name = name;
        this.description = description;
        this.level = level;
    }

    // todo: 抽象方法，升級技能熟練度
    // abstract upgradeSkillProficiency(): boolean;


    // 抽象方法，以應用技能效果
    // abstract applySkillEffects(character: CombatCharacter, targets: CombatEntity[]): void;
}

export enum SkillProficiency {
    Novice,     // 習得
    Proficient, // 熟練
    Expert      // 精通
}
