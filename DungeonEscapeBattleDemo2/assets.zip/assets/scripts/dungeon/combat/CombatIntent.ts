import { Modifier } from "../../cards/Card";
import { CombatActionType } from "./CombatEntity";
import { CombatWeapon } from "./CombatWeapon";

export class CombatIntent {
    private modifiers: Modifier[];
    private targetRestriction: string | null;
    private reactionModifiers: Modifier[] = [];// 消耗反應的效果動作
    // private cost // todo 處理消耗的行動需求

    constructor() {
        this.modifiers = [];
        this.reactionModifiers = [];
        this.targetRestriction = null;
    }

    clearIntents(): void {
        this.modifiers.length = 0;
        this.reactionModifiers.length = 0;
        this.targetRestriction = null;
    }

    // 添加意圖並檢查目標類型是否一致
    addIntent(modifier: Modifier, target: string): boolean {
        console.log(`Adding intent with target type ${target}.`);
        if (this.targetRestriction === null) {
            this.targetRestriction = target;  // 設置第一個意圖的目標類型為限制
            this.modifiers.push(modifier);
            return true;
        } else if (this.targetRestriction === target) {
            this.modifiers.push(modifier);
            return true;
        } else {
            console.log(`Failed to add intent: target type ${target} does not match current restriction ${this.targetRestriction}.`);
            return false;
        }
    }

    setReactionIntent(modifiers: Modifier[]): void {
        console.log('設定反應的意圖');
        this.reactionModifiers = modifiers;
    }

    getReactionIntent(): Modifier[] {
        return this.reactionModifiers;
    }

    getCurrentTargetRestriction(): string | null {
        return this.targetRestriction;
    }

    getModifiers(): Modifier[] {
        return this.modifiers;
    }

    executeIntents(combatWeapons: CombatWeapon[]): void {

    }
}
