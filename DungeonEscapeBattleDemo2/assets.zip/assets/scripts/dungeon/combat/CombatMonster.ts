import { Damage } from "../item/Weapon";
import { CombatActionType, CombatEntity } from "./CombatEntity";
import { CombatIntent } from "./CombatIntent";
import { CombatWeapon } from "./CombatWeapon";
import { Modifier, ModifierCondition } from "../../cards/Card";
import { TeamMember } from "../../ui/combat/TeamMember";
import { CompositeAbilities } from "../Ability";

export class CombatMonster extends CombatEntity {

    // 命中加值 (怪物的命中加值不受武器的影響，統一制定會比較好處理)
    hitBonus = 0;

    constructor(name: string, compositeAbilities: CompositeAbilities, armorClass: number, hitBonus: number, defaultDamage?: Damage) {
        super(name, compositeAbilities, armorClass, defaultDamage);
        this.hitBonus = hitBonus;
    }

    hit(): { roll: number, isFull: boolean } {
        return this.rollHit(0);
    }
    advantageHit(): { roll: number, isFull: boolean }[] {
        const hits = [this.rollHit(0), this.rollHit(0)];
        this.attackHitRoll = hits.sort((a, b) => b.roll - a.roll)[0];
        return hits;
    }
    disadvantageHit(): { roll: number, isFull: boolean }[] {
        const hits = [this.rollHit(0), this.rollHit(0)];
        this.attackHitRoll = hits.sort((a, b) => a.roll - b.roll)[0];
        return hits;
    }

    // 攻擊時檢定命中，回傳檢定結果
    attack(target: CombatEntity): boolean {
        let hitSuccess = false;
        this.bonusHitRolls.length = 0;
        this.extraHitRolls.length = 0;
        this.totalDamageRolls.length = 0;

        // 主手武器
        var combatWeapon: CombatWeapon = this.combatWeapons[0];
        var hitRoll = this.rollHit(0);
        this.attackHitRoll = hitRoll;
        console.log('combatWeapon:', this.combatWeapons);
        combatWeapon.resultHitBonus();

        this.bonusHitRolls = combatWeapon.hitBonus.slice();
        this.extraHitRolls = combatWeapon.hitExtraBonus.slice();

        combatWeapon.resultHitBonus();
        if (combatWeapon.hitCheck(hitRoll.roll, target.ac)) {

            // 主武器攻擊傷害
            const attackDamage = combatWeapon.damage;
            var damageValue = this.rollDamage(attackDamage);//主要傷害 (但不是用dice2，如果卡牌中有雙手武器的條件時需要改用dice2)

            if (hitRoll.isFull) {
                console.log('滿骰傷害值');
                damageValue += this.rollDamage(attackDamage);
            }
            this.totalDamageRolls = [damageValue];
            console.log('主手武器基本傷害:', damageValue);

            this.totalDamageRolls = this.totalDamageRolls.concat(combatWeapon.damageExtraBonus, combatWeapon.damageBonus);

            // target.receiveAttack(damageValue + combatWeapon.totalDamageBonus);
            target.receiveAttack(this.totalDamageRolls.reduce((sum, damage) => sum + damage, 0));

            hitSuccess = true;
        }

        combatWeapon.resetCombatBonus();

        // // 副手武器 todo 一次完成動作，命中+傷害演出一次就好，主手才是重點
        // combatWeapon = this.combatWeapons[1];
        // hitRoll = this.rollHit(0);

        // if (combatWeapon.hitCheck(hitRoll.roll, target.armorClass)) {
        //     }
        // }

        // 雙手武器 todo 一次完成動作，命中+傷害演出一次就好，主手才是重點

        // if (this.combatIntent.totalHitRoll >= target.armorClass) {
        //     // 主武器攻擊傷害
        //     const attackDamage = combatWeapon?.damage || this.defaultDamage;
        //     console.log(`Weapon damage: ${JSON.stringify(attackDamage)}`);
        //     this.totalDamageRolls.push(this.rollDamage(attackDamage));
        //     if (hitRoll.isFull) {
        //         console.log('滿骰傷害值');
        //         this.totalDamageRolls.push(this.rollDamage(attackDamage));
        //     }// todo 命中是其他函式執行的，看怎麼統一在一起

        //     let damageValue = this.totalDamageRolls.reduce((sum, damage) => sum + damage, 0);
        //     target.receiveAttack(damageValue);
        //     console.log(`${this.name} hits and deals ${damageValue} damage.`);
        //     return true;
        // }

        if (!hitSuccess) {
            target.receiveAttack(0);
            console.log(`${this.name} misses.`);
        }
        return hitSuccess;
    }

    // 反擊
    counterattack(target: CombatEntity): boolean {
        const damageValue = this.counterattackDamageValue + this.dodgeCounterattackDamageValue;
        console.log('反擊', target.name, damageValue);
        // target.receiveCounterattack(damageValue);// 因為要判斷是不是用正確的方法反擊，所以還是要先暫存，等演完動畫再計算傷害
        target.receiveAttack(damageValue);

        return damageValue > 0;
    }

    // 處理玩家角色意圖，從卡牌中分析出主手攻擊與副手攻擊中，能夠獲得的效果
    intent(member: TeamMember): CombatIntent {
        const modifiers = this.combatIntent.getModifiers();
        console.log('modifiers:', modifiers);
        // Loop through each intent and determine applicable actions.
        modifiers.forEach((modifier: Modifier) => {
            const applicableWeapon = this.getApplicableWeapon(modifier);
            if (applicableWeapon) {
                // console.log(`Executing intent: ${modifier.name} - ${modifier.description}`);
                // 將意圖效果轉化為武器效果的數據
                const bonus = this.rollDice(modifier.bonus);
                this.applyModifier(applicableWeapon, modifier.attribute, bonus);
                // return;
            }

            // todo 有個bug是沒武器時會沒有這個臨時ac，要查一下
            if (modifier.conditions.includes('Defense')) {
                this.temporaryArmor += parseInt(modifier.bonus, 10);
                member.acLabel.string = `AC(+${this.temporaryArmor}): ${this.ac}`;

                this.intentContents.push(`增加臨時AC: ${this.temporaryArmor}`);
            }

            if (modifier.conditions.includes('Hitpoints')) {
                this.tempHP += parseInt(modifier.bonus, 10);

                this.intentContents.push(`增加臨時HP: ${this.tempHP}`);
            }

            if (modifier.conditions.includes('Advantage')) {
                this.isAdvantage = true;

                this.intentContents.push(`下一回合有優勢`);
            }

        });


        //Test
        // this.combatWeapons[0].showAttackParams();
        // this.combatWeapons[1].showAttackParams();

        return this.combatIntent;
    }
    getApplicableWeapon(modifier: Modifier): CombatWeapon | null {
        const conditions = modifier.conditions;

        // todo 加一個卡牌是武器熟練條件

        // todo 檢查行動值是否可以進行這個意圖效果
        // this.actionPoints

        // 副手武器
        if (this.actionPoints['Bonus'] > 0 && conditions.includes('OffHand') && this.checkWeaponConditions(conditions, this.combatWeapons[1]))
            return this.combatWeapons[1];

        // 主手武器，沒有特別指定的都加在主手武器上
        if (this.actionPoints['Action'] > 0 && this.checkWeaponConditions(conditions, this.combatWeapons[0]))
            return this.combatWeapons[0];

        // 盾牌武器
        if (this.combatArmor.shielded) {
            console.log('是盾牌武器喔!!!!!!');
        }

        // todo 需要在選卡牌時提示條件符不符合

        console.log('沒有武器適用條件');

        return null;
    }
    checkWeaponConditions(conditions: ModifierCondition[], combatWeapon: CombatWeapon): boolean {
        const { range, damage, properties, weaponProficiency } = combatWeapon;
        var fullyQualified = conditions.every((condition: ModifierCondition) => {
            console.log(`Checking weapon condition: ${condition} - damageType: ${damage.type}(${(damage.type == condition)}) - ${range}(${(range == condition)}) - ${properties} (${properties.every(prop => prop == condition)})`);
            if (damage.type == condition)
                return true;
            if (range == condition)
                return true;
            if (properties.every(prop => prop == condition))
                return true;
            if (weaponProficiency[condition] > 0)
                return true;
            return false;
        });
        console.log(`Result: ${fullyQualified}`);
        return fullyQualified;
    }
    applyModifier(weapon: CombatWeapon, type: CombatActionType, bonus: number) {
        console.log(`Applying ${type} bonus of ${bonus} to ${weapon.name}`);
        switch (type) {
            case 'HitBonus':
                weapon.hitBonusAdd(bonus);
                this.intentContents.push(`增加命中: ${bonus}`);
                break;
            case 'HitExtra':
                weapon.hitExtraAdd(bonus);
                this.intentContents.push(`增加額外命中: ${bonus}`);
                break;
            case 'DamageBonus':
                weapon.damageAdd(bonus);
                this.intentContents.push(`增加傷害: ${bonus}`);
                break;
            case 'DamageExtra':
                weapon.extraDamageAdd(bonus);
                this.intentContents.push(`增加額外傷害: ${bonus}`);
                break;
        }
    }

    reaction(): boolean {
        var isReactionSuccess = false;
        // 反應動作: 預先把執行結果完成
        const reactionModifiers: Modifier[] = this.combatIntent.getReactionIntent();
        console.log('reactionModifiers length:', reactionModifiers.length);
        reactionModifiers.forEach((modifier: Modifier) => {
            const conditions = modifier.conditions;
            // 反擊效果
            if (conditions.includes('UnderDamage')) {
                // 受傷時反擊
                this.counterattackDamageValue = this.rollDice(modifier.bonus);
                console.log(`反擊效果: 反擊傷害值: ${this.counterattackDamageValue}`);

                this.intentContents.push(`復仇反擊效果: 反擊傷害值: ${this.counterattackDamageValue}`);

                isReactionSuccess = true;

            } else if (conditions.includes('Dodge')) {
                // 閃避時反擊
                this.dodgeCounterattackDamageValue = this.rollDice(modifier.bonus);
                console.log(`閃避後反擊效果: 反擊傷害值: ${this.dodgeCounterattackDamageValue}`);

                this.intentContents.push(`閃避後反擊效果: 反擊傷害值: ${this.dodgeCounterattackDamageValue}`);

                isReactionSuccess = true;
            }
            // 防禦效果
            else if (conditions.includes('Defense')) {
                // this.temporaryArmor -= parseInt(modifier.bonus, 10);
                // member.acLabel.string = `AC: ${this.ac} (+${this.temporaryArmor})`;
                isReactionSuccess = true;
            }
        });

        return isReactionSuccess;
    }
}