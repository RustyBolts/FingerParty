import { Effect, EffectManager } from "../../managers/EffectManager";
import { EventBus, NotifyEvent } from "../../managers/EventSystem";
import { Skill, SkillProficiency } from "../Skill";
import { CombatCharacter } from "./CombatCharacter";
import { CombatEntity } from "./CombatEntity";

export abstract class CombatSkill extends Skill {
    eventBus: EventBus;

    constructor(name: string, description: string, level: SkillProficiency, eventBus: EventBus) {
        super(name, description, level);

        // 訂閱事件
        this.eventBus = eventBus;
    }

    abstract getAffix(): { name: string, description: string, effect: Effect }[];

    // 抽象方法，以應用技能效果
    abstract applySkillEffects(character: CombatCharacter, targets: CombatEntity[], level: number): void;

    activateSkillEffect(entity: CombatEntity, effect: Effect) {
        this.eventBus.publish(new NotifyEvent("effectSkillApplied", { target: entity, effect }));
    }

    activateAffixEffect(entity: CombatEntity, effect: Effect) {
        this.eventBus.publish(new NotifyEvent("affixEffectApplied", { target: entity, effect }));
    }

    /**
     * 技能:
     *   傷害輸出 - 命中檢定 + 傷害
     *   自身效果 - 對自己產生正面效果，如 回氣(僅限對自身恢復少許生命值)、動作如潮(僅限對自身增加1動作點)
     *   對象效果 - 對其他角色產生正面效果，如 守護(指定對象受到自身的保護，由自身來承受敵人的攻擊)
     *   增/減益 - 對自己產生正面效果/對敵人產生負面效果
     *            例如: 增加我方命中檢定加值、增加我方攻擊力、減少敵方攻擊力
     */

    // 揮砍精通？如果讓技能可以再切分更多的卡牌，讓技能流派更多的話是否會讓遊戲更有趣？

    // 流程
    // a. 武器傷害輸出 - 骰命中檢定值、骰傷害值、發技能卡片、選取卡片、選取敵方目標(此時看的到已選卡牌的命中計算)、執行演出
    // b. 自身效果 - 選取自身效果卡片、執行效果、發出通知(此時看的到已選卡片的效果)
    // c. 對象效果 - 選取對象效果卡片、選取我方目標、執行效果、發出通知(此時看的到已選卡片的效果)


    /**
     * 技能參數
     * {
     *   serialId: "skill1",
     *   level: 1,
     *   name: "傷害輸出",
     *   description: "對目標造成傷害，命中檢定值與傷害值由技能卡片決定。",
     *   cost: {
     *     type: "Action" | "BonusAction" | "Movement" | "Reaction" | "Intent",
     *     fee: 1,
     *   },
     *   effects: [
     *     {
     *      attribute: "HitBonus",
     *      bonus: "+1",
     *      duration: 1,
     *      condition: ["Melee"],
     *     },
     *     {
     *      attribute: "HitBonus",
     *      bonus: "1d4",
     *      duration: 1,
     *      condition: ["Melee", "Unarmed"],
     *     },
     *   ],
     *   target: "self" | "ally" | "enemy" | "allAllies" | "allEnemies",
     * }// 後面不適合
     *   cooldown: 1,
     *   animation: "attack" | "spell" | "item" | "other",
     *   type: "damage" | "heal" | "buff" | "debuff",
     *   range: "melee" | "ranged" | "area",
     * }
     */
}