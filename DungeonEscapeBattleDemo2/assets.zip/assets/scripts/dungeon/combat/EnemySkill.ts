import { randomRangeInt } from "cc";
import { Effect } from "../../managers/EffectManager";
import { Damage } from "../item/Weapon";
import { CombatEntity } from "./CombatEntity";
import { CombatSkill } from "./CombatSkill";

export class EnemySkill extends CombatSkill {

    getAffix(): { name: string, description: string, effect: Effect }[] {
        // const affixEffect: string[] = ['flexible', 'alertness', 'precision', 'inspiration', 'energize', 'rage', 'eye'];
        // 從技能中有的詞綴項目拉出來
        return [
            {
                name: '射擊:配合呼吸',
                description: '「冷靜，配合呼吸再放弓…」',
                effect: { affix: 'inspiration', value: 1, duration: 2 }
            },
            {
                name: '射擊:穩定姿態',
                description: '「讓手指保持穩定…」',
                effect: { affix: 'inspiration', value: randomRangeInt(2, 3), duration: 2 }
            },
            {
                name: '射擊:瞄定再發',
                description: '「先瞄準，再發射…」',
                effect: { affix: 'precision', value: 1, duration: 2 }
            },
            {
                name: '射擊:預測準星',
                description: '「我看見了…能命中！」',
                effect: { affix: 'precision', value: randomRangeInt(2, 3), duration: 2 }
            }
        ];
    }

    applySkillEffects(character: CombatEntity, targets: CombatEntity[], level: number): void {
        if (level > this.level) {
            console.log('等級不足');
            return;
        }

        switch (level) {
            case 1:
                console.log('弱點射擊');
                // var effect: Effect = { affix: 'inspiration', attribute: "DamageBonus", value: 1, duration: 1 };
                // var effect: Effect = { affix: 'inspiration', value: 1, duration: 1 };
                var effect: Effect = { affix: 'inspiration', value: randomRangeInt(3, 6), duration: 2 };
                this.activateSkillEffect(character, effect);
                break;
            case 2:
                console.log('精準射擊');
                // var effect: Effect = { affix: 'precision', attribute: "hitBonus", value: 1, duration: 1 };
                // var effect: Effect = { affix: 'precision', value: 1, duration: 1 };
                var effect: Effect = { affix: 'precision', value: randomRangeInt(1, 6), duration: 2 };
                this.activateSkillEffect(character, effect);
                break;
            case 3:
                // 分裂箭
                console.log('分裂箭');
                // targets.slice(0, 2).forEach(target => { // 假設只攻擊兩個目標
                //     character.attack(target);
                // });
                // character.extraTargetCount += 1;
                break;
            case 4:
                // 突襲射擊
                console.log('突襲射擊');
                let damage: Damage = { dice: '1d4', type: 'Piercing' };// 偷襲傷害
                // character.additionalDamages.push(damage);
                // this.activateEffect(character, { type: 'damage', detail: { damage: damage, modifier: 0 }, duration: 1 }); // 精準射擊示例
                break;
            case 5:
                targets.forEach(target => {
                    console.log('光眩射擊');
                    if (Math.random() < 0.25) { // 假設有 25% 機會目盲
                        console.log(`${target.name} is blid.`);
                        // this.activateEffect(target, { type: 'attribute', detail: { attribute: "blind", value: 1 }, duration: 3 });
                        // this.activateSkillEffect(target, { affix: 'eye', attribute: "blind", value: 1, duration: 3 });
                        this.activateSkillEffect(target, { affix: 'eye', value: 1, duration: 3 });
                    }
                });
                break;
            case 6:
                // 末日之雨
                console.log('末日之雨');
                targets.forEach(target => {
                    // character.attack(target);
                });
                break;
        }

    }

    getSkill1() {
        return [
            // {
            //     serialId: "skill1",
            //     level: 1,
            //     name: "復仇",
            //     description: "承受攻擊時進行反擊6點。",
            //     cost: {
            //         type: "Intent",
            //         fee: 1,
            //     },
            //     modifiers: [{
            //         attribute: "DamageBonus",
            //         bonus: "+6",
            //         duration: 1,
            //         conditions: ["Melee"],
            //     }],
            //     target: "self",
            //     range: "Melee",
            //     type: "damage",
            //     animation: "attack",
            // }, {
            //     serialId: "skill1",
            //     level: 1,
            //     name: "閃避反擊",
            //     description: "閃避攻擊後進行反擊4點。",
            //     cost: {
            //         type: "Reaction",
            //         fee: 1,
            //     },
            //     modifiers: [{
            //         attribute: "DamageBonus",
            //         bonus: "+4",
            //         duration: 1,
            //         conditions: ["Melee", 'Dodge'],
            //     }],
            //     target: "self",
            //     range: "Melee",
            //     type: "damage",
            //     animation: "attack",
            // },
            // {
            //     serialId: "skill1",
            //     level: 1,
            //     name: "卸力",
            //     description: "在承受傷害時減緩衝擊，以臨時生命6點作為可承受的傷害。",
            //     cost: {
            //         type: "Intent",
            //         fee: 1,
            //     },
            //     modifiers: [{
            //         attribute: "Defense",
            //         bonus: "+6",
            //         duration: 1,
            //         conditions: ['Hitpoints'],
            //     }],
            //     target: "self",
            //     range: "Melee",
            //     type: "damage",
            //     animation: "attack",
            // },
            {
                //     serialId: "skill1",
                //     level: 1,
                //     name: "預判",
                //     description: "察覺敵人動向，提前行動。下一輪攻擊有優勢",
                //     cost: {
                //         type: "Intent",
                //         fee: 1,
                //     },
                //     modifiers: [{
                //         attribute: "Attack",
                //         bonus: "+6",
                //         duration: 1,
                //         conditions: ['Advantage'],
                //     }],
                //     target: "self",
                //     range: "Melee",
                //     type: "damage",
                //     animation: "attack",
                // }, {
                serialId: "skill1",
                level: 1,
                name: "攻擊",
                description: "攻擊6點。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "DamageBonus",
                    bonus: "+6",
                    duration: 1,
                    conditions: ["Melee"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "精準",
                description: "命中提升4點。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+4",
                    duration: 1,
                    conditions: ["Melee"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "防禦",
                description: "專注防禦，+4臨時護甲值。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "Defense",
                    bonus: "+4",
                    duration: 1,
                    conditions: ["Defense"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }
        ];
    }
}
