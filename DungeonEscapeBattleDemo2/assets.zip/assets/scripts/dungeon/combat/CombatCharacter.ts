import { Modifier, ModifierCondition } from "../../cards/Card";
import { Effect } from "../../managers/EffectManager";
import { TeamMember } from "../../ui/combat/TeamMember";
import { BaseAbilities, Attribute, CompositeAbilities } from "../Ability";
import { Damage, WeaponStyle } from "../item/Weapon";
import { CombatActionType, CombatEntity } from "./CombatEntity";
import { CombatIntent } from "./CombatIntent";
import { CombatWeapon } from "./CombatWeapon";

export class CombatCharacter extends CombatEntity {
    proficiencyBonus: BaseAbilities;

    constructor(name: string, compositeAbilities: CompositeAbilities, proficiencyAbilities: BaseAbilities, weaponProficiencies: WeaponStyle[], defaultDamage?: Damage) {
        super(name, compositeAbilities, proficiencyAbilities.dexterity, defaultDamage);

        this.proficiencyBonus = proficiencyAbilities;
        this.weaponProficiencies = weaponProficiencies;// 熟練的武器類型
    }

    hit(): { roll: number, isFull: boolean } {
        // 命中檢定
        this.attackHitRoll = this.rollHit(0);
        return this.attackHitRoll;
    }
    advantageHit(): { roll: number, isFull: boolean }[] {
        const hits = [this.rollHit(0), this.rollHit(0)];
        this.attackHitRoll = hits.sort((a, b) => b.roll - a.roll)[0];
        return hits;
    }
    disadvantageHit(): { roll: number, isFull: boolean }[] {
        const hits = [this.rollHit(0), this.rollHit(0)];
        this.attackHitRoll = hits.sort((a, b) => a.roll - b.roll)[0];
        return hits;
    }

    // todo 處理分次的攻擊，如果卡牌混合了 主武器、副手武器、雙手武器，那麼攻擊的命中檢定是需要分開骰的。主手有熟練，副手要看角色是否有雙持客天賦決定是否加入熟練

    // 攻擊時檢定命中，回傳檢定結果
    attack(target: CombatEntity, weaponIndex: number): boolean {
        let hitSuccess = false;
        this.bonusHitRolls.length = 0;
        this.extraHitRolls.length = 0;
        this.totalDamageRolls.length = 0;

        console.log('combatWeapons:', this.combatWeapons);

        // 主手武器
        var combatWeapon: CombatWeapon = this.combatWeapons[weaponIndex];
        var hitRoll = this.attackHitRoll;

        // 武器熟練加值 (這邊先加上去，讓戰鬥看起來比較容易命中)
        // if (combatWeapon.weaponProficiency === this.)
        // this.weaponProficiencyBonus = combatWeapon.hitProficiencyBonus = this.proficiencyBonus[combatWeapon.weaponProficiency];
        // 改成，武器的熟練加值，會按照指定的熟練屬性
        // var useWeaponAbility = null;
        // if (combatWeapon.weaponProficiency) {
        //     useWeaponAbility = Attribute.Strength;//todo 這邊可以再設計成吃卡牌給的，有加熟練後命中會很高
        //     this.weaponProficiencyBonus = combatWeapon.weaponProficiency[useWeaponAbility];
        // }
        this.weaponProficiencyBonus = combatWeapon.weaponProficiency;

        this.bonusHitRolls = combatWeapon.hitBonus.slice();
        this.extraHitRolls = combatWeapon.hitExtraBonus.slice();

        combatWeapon.resultHitBonus();
        if (combatWeapon.hitCheck(hitRoll.roll, target.ac)) {

            // 主武器攻擊傷害
            const attackDamage = combatWeapon.damage;
            var damageValue = this.rollDamage(attackDamage);//主要傷害 (但不是用dice2，如果卡牌中有雙手武器的條件時需要改用dice2)

            if (hitRoll.isFull) {
                console.log('滿骰傷害值');
                damageValue += this.rollDamage(attackDamage);
            }
            this.totalDamageRolls = [damageValue];
            console.log('主手武器基本傷害:', damageValue);

            this.totalDamageRolls = this.totalDamageRolls.concat(combatWeapon.damageExtraBonus, combatWeapon.damageBonus);

            // target.receiveAttack(damageValue + combatWeapon.totalDamageBonus);
            target.receiveAttack(this.totalDamageRolls.reduce((sum, damage) => sum + damage, 0));

            // 暈眩效果: 給指定對象
            target.affixEffects.stun = combatWeapon.stunEffect;
            if (target.affixEffects.stun > 0)
                target.intentContents.push('(暈眩)');

            hitSuccess = true;
        }
        combatWeapon.resetCombatBonus();

        // // 副手武器 todo 一次完成動作，命中+傷害演出一次就好，主手才是重點
        // combatWeapon = this.combatWeapons[1];
        // hitRoll = this.rollHit(0);

        // if (combatWeapon.hitCheck(hitRoll.roll, target.ac)) {
        //     // todo 副手武器的命中跟傷害，需要另外再存兩個參數，讓Visualize 演第二下的附贈攻擊
        // }

        // // 雙手武器 todo 一次完成動作，命中+傷害演出一次就好，主手才是重點

        // 未命中
        if (!hitSuccess) {
            target.receiveAttack(0);
        }

        return hitSuccess;
    }

    // 反擊
    counterattack(target: CombatEntity): boolean {
        const damageValue = this.counterattackDamageValue + this.dodgeCounterattackDamageValue;
        console.log('反擊', target.name, damageValue);
        // target.receiveCounterattack(damageValue);// 因為要判斷是不是用正確的方法反擊，所以還是要先暫存，等演完動畫再計算傷害
        target.receiveAttack(damageValue);

        return damageValue > 0;
    }

    // 處理玩家角色意圖，從卡牌中分析出主手攻擊與副手攻擊中，能夠獲得的效果
    intent(member: TeamMember): CombatIntent {
        const modifiers = this.combatIntent.getModifiers();
        console.log('modifiers:', modifiers);
        // Loop through each intent and determine applicable actions.
        modifiers.forEach((modifier: Modifier) => {
            const applicableWeapon = this.getApplicableWeapon(modifier);
            if (applicableWeapon) {
                // console.log(`Executing intent: ${modifier.name} - ${modifier.description}`);
                // 將意圖效果轉化為武器效果的數據
                const bonus = this.rollDice(modifier.bonus);
                this.applyModifier(applicableWeapon, modifier.attribute, bonus);
                // return;
            }

            const conditions = modifier.conditions;
            const { isCasterArmor, isLightArmor } = this.combatArmor;
            // todo 有個bug是沒武器時會沒有這個臨時ac，要查一下
            if (conditions.includes('Defense')) {
                if (conditions.includes('LightArmor') && !isLightArmor) {
                    console.log('穿重甲時無法使身法靈活');
                    return;
                }
                this.temporaryArmor += parseInt(modifier.bonus, 10);
                member.acLabel.string = `AC(+${this.temporaryArmor}): ${this.ac}`;
            }

            if (conditions.includes('Hitpoints')) {
                this.tempHP += parseInt(modifier.bonus, 10);
            }

            // 優勢時可以做的動作，例如偷襲
            if (modifier.conditions.includes('Advantage')) {
                this.isAdvantage = true;
            }

            // todo 檢查是否有武器熟練
            // if (applicableWeapon.weaponProficiency>0)

        });


        //Test
        this.combatWeapons[0].showAttackParams();
        this.combatWeapons[1].showAttackParams();

        return this.combatIntent;
    }
    getApplicableWeapon(modifier: Modifier): CombatWeapon | null {
        const conditions = modifier.conditions;

        // todo 加一個卡牌是武器熟練條件

        // 副手武器(消費附贈動作)
        if (this.actionPoints['Bonus'] > 0 && conditions.includes('OffHand') && this.checkWeaponConditions(conditions, this.combatWeapons[1]))
            return this.combatWeapons[1];

        // 主手武器，沒有特別指定的都加在主手武器上
        if (this.actionPoints['Action'] > 0 && this.checkWeaponConditions(conditions, this.combatWeapons[0]))
            return this.combatWeapons[0];

        // 盾牌武器
        if (this.combatArmor.shielded) {
            console.log('是盾牌武器喔!!!!!!');
        }

        // todo 需要在選卡牌時提示條件符不符合

        console.log('沒有武器適用條件');

        return null;
    }
    checkWeaponConditions(conditions: ModifierCondition[], combatWeapon: CombatWeapon): boolean {
        const { range, damage, properties, weaponProficiency } = combatWeapon;
        const { isCasterArmor, isLightArmor } = this.combatArmor;
        var fullyQualified = conditions.every((condition: ModifierCondition) => {
            // console.log(`Checking weapon condition: ${condition} - damageType: ${damage.type}(${(damage.type == condition)}) - ${range}(${(range == condition)}) - ${properties} (${properties.every(prop => prop == condition)})`);
            if (damage.type == condition)
                return true;
            if (range == condition)
                return true;
            if (properties.some(prop => prop == condition))
                return true;
            if (weaponProficiency[condition] > 0)
                return true;
            // 需要配合裝甲類別的條件
            if (isLightArmor && condition == 'LightArmor')
                return true;
            if (isCasterArmor && condition == 'CasterArmor')
                return true;
            return false;
        });
        console.log(`--- ${conditions} Result: ${fullyQualified}`);
        return fullyQualified;
    }
    applyModifier(weapon: CombatWeapon, type: CombatActionType, bonus: number) {
        console.log(`Applying ${type} bonus of ${bonus} to ${weapon.name}`);
        switch (type) {
            case 'HitBonus':
                weapon.hitBonusAdd(bonus);
                break;
            case 'HitExtra':
                weapon.hitExtraAdd(bonus);
                break;
            case 'DamageBonus':
                weapon.damageAdd(bonus);
                break;
            case 'DamageExtra':
                weapon.extraDamageAdd(bonus);
                break;
            case 'Stun':
                // 武器上附加暈眩效果
                weapon.stunEffectAdd(bonus);
                break;
        }
    }

    reaction(): boolean {
        var isReactionSuccess = false;
        // 反應動作: 預先把執行結果完成
        const reactionModifiers: Modifier[] = this.combatIntent.getReactionIntent();
        console.log('reactionModifiers length:', reactionModifiers.length);
        const { isCasterArmor, isLightArmor } = this.combatArmor;
        reactionModifiers.forEach((modifier: Modifier) => {
            const conditions = modifier.conditions;
            // 反擊效果
            if (conditions.includes('UnderDamage')) {
                // 受傷時反擊
                this.counterattackDamageValue = this.rollDice(modifier.bonus);
                console.log(`反擊效果: 反擊傷害值: ${this.counterattackDamageValue}`);

                isReactionSuccess = true;

            } else if (conditions.includes('Dodge')) {
                if (conditions.includes('LightArmor') && !isLightArmor) {
                    console.log('穿重甲時無法閃避反擊');
                    return;
                }
                // 閃避時反擊
                this.dodgeCounterattackDamageValue = this.rollDice(modifier.bonus);
                console.log(`閃避後反擊效果: 反擊傷害值: ${this.dodgeCounterattackDamageValue}`);

                isReactionSuccess = true;
            }
            // 防禦效果
            else if (conditions.includes('Defense')) {
                if (conditions.includes('LightArmor') && !isLightArmor) {
                    console.log('穿重甲時無法使身法靈活');
                    return;
                }
                isReactionSuccess = true;
            }
        });

        return isReactionSuccess;
    }
}