import { Armor } from "../item/Armor";

export class CombatArmor {

    name: string;
    dexterity: number;
    shielded: boolean = false;// 是否裝備盾牌

    armorClass: number;//護甲值
    armorDefault: Armor = null;

    isLightArmor: boolean = false;// 是否為輕裝上陣
    isCasterArmor: boolean = false;// 是否為法術裝備

    constructor(name: string, dexterity: number, armor: Armor) {
        this.name = name || '無裝甲';
        this.dexterity = dexterity;
        this.armorDefault = armor;
        this.armorClass = armor.calculateArmorClass(this.dexterity);

        console.log('this.dexterity:', this.dexterity);
        console.log('this.armorClass:', this.armorClass);
    }

    dress(armor: Armor): void {
        this.armorClass = 0;
        if (armor) {
            // 護甲值
            this.armorClass = armor.calculateArmorClass(this.dexterity);
            this.isCasterArmor = armor.armorType === 'Light';
            if (this.isCasterArmor || armor.armorType === 'Medium') {
                this.isLightArmor = true;
            } else {
                this.isCasterArmor = false;
                this.isLightArmor = false;
            }
        } else {
            this.name = '無裝甲';
            this.armorClass = this.armorDefault.calculateArmorClass(this.dexterity);
            this.isLightArmor = true;
        }
        console.log('this.dexterity:', this.dexterity);
        console.log('this.armorClass:', this.armorClass);
        console.log('this.isLightArmor:', this.isLightArmor);
        console.log('this.isCasterArmor:', this.isCasterArmor);
    }

    shield(active: boolean): void {
        this.shielded = active;
    }
}