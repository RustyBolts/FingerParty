import { CombatCard } from '../../cards/Card';
import { Effect } from '../../managers/EffectManager';
import { EventBus } from '../../managers/EventSystem';
import { Skill, SkillProficiency } from '../Skill';
import { CombatEntity } from './CombatEntity';
import { CombatSkill } from './CombatSkill';

export class MeleeSkill extends CombatSkill {

    constructor(level: number, description: string, eventBus: EventBus) {
        super('近戰', description, level, eventBus);
    }

    getAffix(): { name: string, description: string, effect: Effect }[] {
        return [{
            name: '射擊:配合呼吸',
            description: '「冷靜，配合呼吸再放弓…」',
            effect: { affix: 'inspiration', value: 1, duration: 2 }
        }];
    }

    applySkillEffects(character: CombatEntity, targets: CombatEntity[], level: number): void {

    }

    getSkill(level: SkillProficiency) {

        switch (level) {
            case SkillProficiency.Novice:
                return this.getSkill1();
            case SkillProficiency.Proficient:
                return this.getSkill2();
            case SkillProficiency.Expert:
                return this.getSkill3();
            default:
                return this.getSkill1();
        }
    }

    getSkill1(): CombatCard[] {
        return [
            this.punch,
            this.punch,
            this.punch,
            this.bludgeoning,
            this.bludgeoning,
            this.slashing,
            this.slashing,
            this.piercing,
            this.piercing,
            this.parry,
            this.parry,
            this.parry,
            this.block,
            this.block,
            this.block,
        ]
    }

    getSkill2(): CombatCard[] {
        return [
            this.punch,
            this.bludgeoning,
            this.slashing,
            this.piercing,
            this.parry,
            this.block,
            this.dodge,
            this.dodgeCounterattack,
            this.prejudgment,
            this.relieveForce,
            this.revenge,
            this.raid,
            this.crafty,
        ]
    }

    getSkill3(): CombatCard[] {
        return [
            this.punch,
            this.bludgeoning,
            this.slashing,
            this.piercing,
            this.parry,
            this.block,
            this.dodge,
        ]
    }

    private get punch(): CombatCard {
        return {
            name: '拳擊',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '使用拳擊動作助攻，+2命中。徒手時傷害+1。',
            modifiers: [{
                attribute: 'HitBonus',
                bonus: '+2',
                description: '',
                conditions: ['Melee'],
            },
            {
                attribute: 'DamageBonus',
                bonus: '+1',
                description: '',
                conditions: ['Melee', 'Unarmed'],
            }],
            target: 'enemy',
        }
    }

    private get bludgeoning(): CombatCard {
        return {
            name: '猛擊',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '使用敲擊動作助攻，-2命中，+2傷害。武器有鈍器屬性時造成暈眩效果。',
            modifiers: [{
                attribute: 'HitBonus',
                bonus: '-2',
                description: '提高命中，以猛烈的攻擊動作使主攻擊的命中機會提升。',
                conditions: ['Melee'],
            },
            {
                attribute: 'DamageBonus',
                bonus: '+2',
                description: '',
                conditions: ['Melee'],
            },
            {
                attribute: 'Stun',
                bonus: '+1',
                description: '武器有鈍器的特性時目標受暈眩效果。',
                conditions: ['Melee', 'Bludgeoning'],
            }],
            target: 'enemy',
        }
    }

    private get slashing(): CombatCard {
        return {
            name: '斬擊',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '使用揮砍動作助攻，+1命中。武器有揮砍屬性時+1點傷害。',
            modifiers: [{
                attribute: 'HitBonus',
                bonus: '+1',
                description: '',
                conditions: ['Melee'],
            },
            {
                attribute: 'DamageBonus',
                bonus: '+1',
                description: '',
                conditions: ['Melee', 'Slashing'],
            }],
            target: 'enemy',
        }
    }

    private get piercing(): CombatCard {
        return {
            name: '突刺',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '使用穿刺動作助攻，+1命中。若武器有穿刺屬性時+1點傷害。',
            modifiers: [{
                attribute: 'HitBonus',
                bonus: '+1',
                description: '',
                conditions: ['Melee'],
            },
            {
                attribute: 'DamageBonus',
                bonus: '+1',
                description: '',
                conditions: ['Melee', 'Piercing'],
            }],
            target: 'enemy',
        }
    }

    private get parry(): CombatCard {
        return {
            name: '反手格擋',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '攻守合一，+1命中、+1臨時護甲值。',
            modifiers: [{
                attribute: 'HitBonus',
                bonus: '+1',
                description: '',
                conditions: ['Melee'],
            }, {
                attribute: 'Defense',
                bonus: '+1',
                description: '',
                conditions: ['Defense'],
            }],
            target: 'enemy',
        }
    }

    private get block(): CombatCard {
        return {
            name: '專注防禦',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '-4命中為代價提高防禦，+4臨時護甲值。',
            modifiers: [{
                attribute: 'HitBonus',
                bonus: '-4',
                description: '',
                conditions: ['Melee'],
            }, {
                attribute: 'Defense',
                bonus: '+4',
                description: '',
                conditions: ['Defense'],
            }],
            target: 'enemy',
        }
    }

    private get dodge(): CombatCard {
        return {
            name: '靈活步伐',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            description: '攻擊時讓腳步靈動，+1命中，+2臨時護甲值。但你穿著重甲時無法靈活行動而失敗。',
            modifiers: [
                {
                    attribute: 'HitBonus',
                    bonus: '+1',
                    description: '',
                    conditions: ["Melee"],
                },
                {
                    attribute: 'Defense',
                    bonus: '+2',
                    description: '',
                    conditions: ["Defense", 'LightArmor'],
                }],
            target: 'enemy',
        }
    }

    private get dodgeCounterattack(): CombatCard {
        return {
            name: '閃避反擊',
            description: "閃避攻擊後進行反擊4點。但在穿著重甲時無法靈活地反擊。",
            cost: {
                type: "Reaction",
                fee: 1,
            },
            modifiers: [{
                attribute: "DamageBonus",
                bonus: "+4",
                description: '',
                conditions: ["Melee", 'Dodge', 'LightArmor'],
            }],
            target: 'enemy',
        }
    }

    private get prejudgment(): CombatCard {
        return {
            name: '預判',
            description: '察覺敵人動向，提前行動。下一輪攻擊有優勢',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            modifiers: [{
                attribute: 'Attack',
                bonus: '+6',
                description: '',
                conditions: ['Advantage'],
            }],
            target: 'enemy',
        }
    }

    private get relieveForce(): CombatCard {
        return {
            name: '卸力',
            description: '在承受傷害時減緩衝擊，以臨時生命6點作為可承受的傷害。',
            cost: {
                type: 'Intent',
                fee: 1,
            },
            modifiers: [{
                attribute: 'Defense',
                bonus: '+6',
                description: '',
                conditions: ['Hitpoints'],
            }],
            target: 'enemy',
        }
    }

    private get revenge(): CombatCard {
        return {
            name: '復仇',
            description: '承受攻擊時進行反擊6點。',
            cost: {
                type: 'Reaction',
                fee: 1,
            },
            modifiers: [{
                attribute: 'DamageBonus',
                bonus: '+6',
                description: '',
                conditions: ['Melee', 'UnderDamage'],
            }],
            target: 'enemy',
        }
    }

    private get raid(): CombatCard {
        return {
            name: "突襲",
            description: "靈活的攻擊攻擊技能直逼敵人要害，造成額外傷害2d4。使用靈活武器時傷害+2",
            cost: {
                type: "Intent",
                fee: 1,
            },
            modifiers: [
                {
                    attribute: "DamageExtra",
                    bonus: "2d4",
                    description: '',
                    conditions: ["Melee"],
                }, {
                    attribute: "DamageBonus",
                    bonus: "+2",
                    description: '',
                    conditions: ["Melee", 'Finesse'],
                }],
            target: "enemy",
        }
    }

    private get crafty(): CombatCard {
        return {
            name: "狡詐",
            description: "使用假動作誘導敵人，額外造成1d4命中。",
            cost: {
                type: "Intent",
                fee: 1,
            },
            modifiers: [{
                attribute: "HitExtra",
                bonus: "1d4",
                description: '',
                conditions: ["Melee"],
            }],
            target: "enemy",
        }
    }
    // //誤導

}