import { Attribute } from "../Ability";
import { Damage, Weapon, WeaponProperty, WeaponRange } from "../item/Weapon";

export class CombatWeapon {
    name: string;
    weaponProficiency: number = 0;

    damage: Damage;// 武器主要傷害
    properties: WeaponProperty[]; // 武器的屬性

    // isRangeDamage: boolean;
    // difficultClass?: number; // 只在 isRangeDamage 為 true 時使用
    range: WeaponRange; // 武器的射程

    // 武器的命中與傷害熟練，要在 裝備/卸下 後立刻處理加值
    // hitProficiencyBonus: number = 0; // 命中加值
    // damageProficiencyBonus: number = 0; // 傷害加值

    hitBonus: number[] = []; // 命中加值
    hitExtraBonus: number[] = []; // 額外命中加值
    totalHitRaise: number = 0; // 總命中提升

    damageBonus: number[] = []; // 傷害加值
    damageExtraBonus: number[] = []; // 額外傷害加值
    // totalDamageBonus: number = 0; // 總傷害加值

    stunEffect: number = 0;

    private inBattle: boolean = false;

    constructor(weapon: Weapon, weaponProficiency: number = 0) {
        const { name, damage, properties, range } = weapon;
        this.name = name;
        this.weaponProficiency = weaponProficiency;

        this.damage = damage;
        this.properties = properties;

        this.range = range;

        this.resetCombatBonus();
    }

    // 重置加值
    resetCombatBonus(): void {
        this.hitBonus.length = 0;
        this.hitExtraBonus.length = 0;
        this.damageBonus.length = 0;
        this.damageExtraBonus.length = 0;

        this.stunEffect = 0;

        this.totalHitRaise = 0;
        // this.totalDamageBonus = 0;

        this.inBattle = false;
    }

    // 累積命中數值
    hitBonusAdd(value: number): void {
        this.hitBonus.push(value);
        this.inBattle = true;
    }

    // 累積額外命中數值
    hitExtraAdd(value: number): void {
        this.hitExtraBonus.push(value);
        this.inBattle = true;
    }

    // 累積傷害數值
    damageAdd(value: number): void {
        this.damageBonus.push(value);
        this.inBattle = true;
    }

    // 累積額外傷害數值
    extraDamageAdd(value: number): void {
        this.damageExtraBonus.push(value);
        this.inBattle = true;
    }

    stunEffectAdd(value: number): void {
        this.stunEffect += value;
        this.inBattle = true;
    }

    // 計算所有命中提升
    resultHitBonus(): number {
        this.totalHitRaise = this.hitBonus.reduce((acc, cur) => acc + cur, 0)
            + this.hitExtraBonus.reduce((acc, cur) => acc + cur, 0);

        this.hitBonus.length = 0;
        this.hitExtraBonus.length = 0;

        return this.totalHitRaise;
    }
    // resultDamageBonus(): void {
    //     this.totalDamageBonus = this.damageBonus.reduce((acc, cur) => acc + cur, 0)
    //         + this.damageExtraBonus.reduce((acc, cur) => acc + cur, 0);
    // }

    // 命中檢定
    hitCheck(roll: number, ac: number, ability?: Attribute): boolean {
        // const weaponProficiency = ability ? this.weaponProficiency[ability] ?? 0 : 0;
        console.log(`命中檢定: ${ac} vs ${roll} + ${this.weaponProficiency} + ${this.totalHitRaise}`)
        return ac <= roll + this.weaponProficiency + this.totalHitRaise;
    }

    // 測試用
    showAttackParams() {
        console.log(`武器名稱: ${this.name}`);
        console.log(`武器屬性: ${this.properties.join(", ")}`);
        console.log(`武器傷害: ${JSON.stringify(this.damage)}`);
        console.log(`武器射程: ${this.range.toString()}`);
        console.log(`命中加值: ${this.totalHitRaise}`);
        // console.log(`傷害加值: ${this.totalDamageBonus}`);

        console.log('hitExtra:', this.hitExtraBonus);
        console.log('hitBonus:', this.hitBonus);
        console.log('damageBonus:', this.damageBonus);
        console.log('damageExtra:', this.damageExtraBonus);
    }
}