import { randomRangeInt } from "cc";
import { Effect } from "../../managers/EffectManager";
import { Damage } from "../item/Weapon";
import { CombatEntity } from "./CombatEntity";
import { CombatSkill } from "./CombatSkill";
import { EventBus } from "../../managers/EventSystem";

export class ArcherySkill extends CombatSkill {

    constructor(level: number, description: string, eventBus: EventBus) {
        super('弓道', description, level, eventBus);
    }

    getAffix(): { name: string, description: string, effect: Effect }[] {
        // const affixEffect: string[] = ['flexible', 'alertness', 'precision', 'inspiration', 'energize', 'rage', 'eye'];
        // 從技能中有的詞綴項目拉出來
        return [
            {
                name: '射擊:配合呼吸',
                description: '「冷靜，配合呼吸再放弓…」',
                effect: { affix: 'inspiration', value: 1, duration: 2 }
            },
            {
                name: '射擊:穩定姿態',
                description: '「讓手指保持穩定…」',
                effect: { affix: 'inspiration', value: randomRangeInt(2, 3), duration: 2 }
            },
            {
                name: '射擊:瞄定再發',
                description: '「先瞄準，再發射…」',
                effect: { affix: 'precision', value: 1, duration: 2 }
            },
            {
                name: '射擊:預測準星',
                description: '「我看見了…能命中！」',
                effect: { affix: 'precision', value: randomRangeInt(2, 3), duration: 2 }
            }
        ];
    }

    getSkill() {
        return [
            {
                name: 'xx1',
                description: '「射擊技能1」',
                skillType: 'DamageExtra',
                hits: '',
                damage: '1d4',
            }, {
                name: 'xx2',
                description: '「射擊技能2」',
                skillType: 'HitExtra',
                hits: '1d4',
                damage: '',
            }, {
                name: 'xx3',
                description: '「射擊技能3」',
                skillType: 'HitBonus',
                hits: '+1',
                damage: '',
            }, {
                name: 'xx4',
                description: '「射擊技能4」',
                skillType: 'DamageBonus',
                hits: '',
                damage: '+1',
            },
        ]
    }

    applySkillEffects(character: CombatEntity, targets: CombatEntity[], level: number): void {
        if (level > this.level) {
            console.log('等級不足');
            return;
        }

        switch (level) {
            case 1:
                console.log('弱點射擊');
                // var effect: Effect = { affix: 'inspiration', attribute: "DamageBonus", value: 1, duration: 1 };
                // var effect: Effect = { affix: 'inspiration', value: 1, duration: 1 };
                var effect: Effect = { affix: 'inspiration', value: randomRangeInt(3, 6), duration: 2 };
                this.activateSkillEffect(character, effect);
                break;
            case 2:
                console.log('精準射擊');
                // var effect: Effect = { affix: 'precision', attribute: "hitBonus", value: 1, duration: 1 };
                // var effect: Effect = { affix: 'precision', value: 1, duration: 1 };
                var effect: Effect = { affix: 'precision', value: randomRangeInt(1, 6), duration: 2 };
                this.activateSkillEffect(character, effect);
                break;
            case 3:
                // 分裂箭
                console.log('分裂箭');
                // targets.slice(0, 2).forEach(target => { // 假設只攻擊兩個目標
                //     character.attack(target);
                // });
                // character.extraTargetCount += 1;
                break;
            case 4:
                // 突襲射擊
                console.log('突襲射擊');
                let damage: Damage = { dice: '1d4', type: 'Piercing' };// 偷襲傷害
                // character.additionalDamages.push(damage);
                // this.activateEffect(character, { type: 'damage', detail: { damage: damage, modifier: 0 }, duration: 1 }); // 精準射擊示例
                break;
            case 5:
                targets.forEach(target => {
                    console.log('光眩射擊');
                    if (Math.random() < 0.25) { // 假設有 25% 機會目盲
                        console.log(`${target.name} is blid.`);
                        // this.activateEffect(target, { type: 'attribute', detail: { attribute: "blind", value: 1 }, duration: 3 });
                        // this.activateSkillEffect(target, { affix: 'eye', attribute: "blind", value: 1, duration: 3 });
                        this.activateSkillEffect(target, { affix: 'eye', value: 1, duration: 3 });
                    }
                });
                break;
            case 6:
                // 末日之雨
                console.log('末日之雨');
                targets.forEach(target => {
                    // character.attack(target);
                });
                break;
        }

    }

    getSkill1() {
        return [
            {
                serialId: "skill1",
                level: 1,
                name: "復仇",
                description: "承受攻擊時進行反擊6點。",
                cost: {
                    type: "Reaction",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "DamageBonus",
                    bonus: "+6",
                    duration: 1,
                    conditions: ["Melee", 'UnderDamage'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "閃避反擊",
                description: "閃避攻擊後進行反擊4點。",
                cost: {
                    type: "Reaction",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "DamageBonus",
                    bonus: "+4",
                    duration: 1,
                    conditions: ["Melee", 'Dodge'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "卸力",
                description: "在承受傷害時減緩衝擊，以臨時生命6點作為可承受的傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "Defense",
                    bonus: "+6",
                    duration: 1,
                    conditions: ['Hitpoints'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "預判",
                description: "察覺敵人動向，提前行動。下一輪攻擊有優勢",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "Attack",
                    bonus: "+6",
                    duration: 1,
                    conditions: ['Advantage'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
        ];
    }

    getSkill2() {
        return [ // 鬥毆技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "拳擊",
                description: "使用拳擊動作助攻，+1命中。徒手時傷害+1。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee", "Unarmed"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },// 敲擊技巧技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "猛擊",
                description: "使用敲擊動作助攻，+1命中。武器有鈍器屬性時+4點傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "Stun",
                    bonus: "+1",
                    description: '武器有鈍器的特性時目標受暈眩效果。',
                    conditions: ["Melee", "Bludgeoning"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },// 揮砍技巧技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "斬擊",
                description: "使用揮砍動作助攻，+1命中。武器有揮砍屬性時+1點傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee", "Slashing"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },// 穿刺技巧技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "突刺",
                description: "使用穿刺動作助攻，+1命中。若武器有穿刺屬性時+1點傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+1",
                    duration: 1,
                    conditions: ["Melee", "Piercing"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "反手格擋",
                description: "攻守合一，+1命中、+1臨時護甲值。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "HitBonus",
                        bonus: "+1",
                        duration: 1,
                        conditions: ["Melee"],
                    }, {
                        attribute: "Defense",
                        bonus: "+1",
                        duration: 1,
                        conditions: ["Defense"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "專注防禦",
                description: "專心防禦，+2臨時護甲值。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "Defense",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Defense"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }
            , {
                serialId: "skill1",
                level: 1,
                name: "靈活步伐",
                description: "攻擊時讓腳步靈動，+1命中，+2臨時護甲值。但你穿著重甲時無法靈活行動而失敗。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "HitBonus",
                        bonus: "+1",
                        duration: 1,
                        conditions: ["Melee", 'LightArmor'],
                    },
                    {
                        attribute: "Defense",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Defense", 'LightArmor'],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }]
    }

    getSkill3() {
        return [ // 鬥毆技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "拳擊+1",
                description: "使用拳擊動作助攻，+3命中。徒手時傷害+2。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+3",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+2",
                    duration: 1,
                    conditions: ["Melee", "Unarmed"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },// 敲擊技巧技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "猛擊+1",
                description: "使用敲擊動作助攻，+2命中。武器有鈍器屬性時+6點傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+2",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+6",
                    duration: 1,
                    conditions: ["Melee", "Bludgeoning"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },// 揮砍技巧技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "斬擊+1",
                description: "使用揮砍動作助攻，+2命中。武器有揮砍屬性時+4點傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+4",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+2",
                    duration: 1,
                    conditions: ["Melee", "Slashing"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },// 穿刺技巧技能參數
            {
                serialId: "skill1",
                level: 1,
                name: "突刺+1",
                description: "使用穿刺動作助攻，+2命中。若武器有穿刺屬性時+4點傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitBonus",
                    bonus: "+2",
                    duration: 1,
                    conditions: ["Melee"],
                },
                {
                    attribute: "DamageBonus",
                    bonus: "+4",
                    duration: 1,
                    conditions: ["Melee", "Piercing"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "反手格擋+1",
                description: "攻守合一，+2命中、+2臨時護甲值。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "HitBonus",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Melee"],
                    }, {
                        attribute: "Defense",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Defense"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "力量熟練",
                description: "若有武器熟練時+2點力量傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "DamageBonus",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Melee", "strength"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "專注防禦+1",
                description: "專心防禦，+4臨時護甲值。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "Defense",
                        bonus: "+4",
                        duration: 1,
                        conditions: ["Defense"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "狡詐技巧",
                description: "使用假動作誘導敵人，額外造成1d4命中。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "HitExtra",
                    bonus: "1d4",
                    duration: 1,
                    conditions: ["Melee"],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }
            , {
                serialId: "skill1",
                level: 1,
                name: "靈活步伐+1",
                description: "攻擊時讓腳步靈動，+2命中，+3臨時護甲值。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "HitBonus",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Melee"],
                    },
                    {
                        attribute: "Defense",
                        bonus: "+3",
                        duration: 1,
                        conditions: ["Defense"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "突襲",
                description: "趁人不備打擊敵人要害，額外傷害2d4。使用靈活武器時傷害+2",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "DamageExtra",
                        bonus: "2d4",
                        duration: 1,
                        conditions: ["Melee"],
                    }, {
                        attribute: "DamageBonus",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Melee", 'Finesse'],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "打擊弱點",
                description: "專心打擊敵人要害，額外傷害1d4。武器有穿刺屬性時傷害+2",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [
                    {
                        attribute: "DamageExtra",
                        bonus: "1d4",
                        duration: 1,
                        conditions: ["Melee"],
                    }, {
                        attribute: "DamageBonus",
                        bonus: "+2",
                        duration: 1,
                        conditions: ["Piercing"],
                    }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "復仇",
                description: "承受攻擊時進行反擊6點。",
                cost: {
                    type: "Reaction",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "DamageBonus",
                    bonus: "+6",
                    duration: 1,
                    conditions: ["Melee", 'UnderDamage'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            }, {
                serialId: "skill1",
                level: 1,
                name: "閃避反擊",
                description: "閃避攻擊後進行反擊4點。但在穿著重甲時無法靈活地反擊。",
                cost: {
                    type: "Reaction",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "DamageBonus",
                    bonus: "+4",
                    duration: 1,
                    conditions: ["Melee", 'Dodge', 'LightArmor'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
            {
                serialId: "skill1",
                level: 1,
                name: "卸力",
                description: "在承受傷害時減緩衝擊，以臨時生命6點作為可承受的傷害。",
                cost: {
                    type: "Intent",
                    fee: 1,
                },
                modifiers: [{
                    attribute: "Defense",
                    bonus: "+6",
                    duration: 1,
                    conditions: ['Hitpoints'],
                }],
                target: "self",
                range: "Melee",
                type: "damage",
                animation: "attack",
            },
        ];
    }
}
