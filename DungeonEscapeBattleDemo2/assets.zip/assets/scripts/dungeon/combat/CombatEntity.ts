import { randomRangeInt } from "cc";
import { EffectAttribute } from "../../managers/EffectManager";
import { EventManager } from "../../managers/EventManager";
import { TeamMember } from "../../ui/combat/TeamMember";
import { Attribute, CompositeAbilities } from "../Ability";
import { Armor } from "../item/Armor";
import { Shield } from "../item/Shield";
import { Damage, Weapon, WeaponRange, WeaponStyle } from "../item/Weapon";
import { CombatArmor } from "./CombatArmor";
import { CombatIntent } from "./CombatIntent";
import { CombatWeapon } from "./CombatWeapon";


export type CombatActionType = 'HitBonus' | 'HitExtra' | 'DamageBonus' | 'DamageExtra' | 'Attack' | 'Defense' | 'Effect' | 'Stun';// "damage" | "heal" | "buff" | "debuff"

export abstract class CombatEntity {
    name: string;

    hitPoints: number;//生命值
    sanityPoints: number;//理智值
    moralePoints: number;//士氣值
    isDead: boolean = false;// 是否已死亡

    actionPoints: { [key: string]: number };// 行動值: 動作、反應、移動、附贈動作等等
    // combatActions: { [key: string]: CombatAction };//todo 在 CombatOptions 時先選擇要做的行動，然後執行對應的後續流程，如 主要攻擊 會先骰命中，接下來才是進行卡牌增益效果

    combatWeapons: CombatWeapon[] = [];
    combatArmor: CombatArmor = null;

    affixEffects: { [key: string]: number };// 附加效果

    // 預設傷害
    // defaultDamage: Damage;// 預設傷害，如果沒有裝備武器，則使用此傷害
    naturalWeapon: { name: string, damage: Damage, range: WeaponRange }; // 天生武器

    // 命中骰    
    attackHitRoll: { isFull: boolean, roll: number };// 擲攻擊骰的結果，用來判斷是否命中 (先骰命中後，玩家再決定要選哪些卡牌效果)
    hitCriticalPoint: number = 20; // 滿骰命中判定點數，調整命中檢定的爆骰點數判定

    // 武器熟練、卡牌命中效果
    weaponProficiencyBonus: number = 0;
    weaponProficiencies: WeaponStyle[] = [];// 武器熟練度，用來判斷是否有卡牌效果
    bonusHitRolls: number[] = [];// 命中加值，存為陣列，每個元素代表一個攻擊
    extraHitRolls: number[] = [];// 連續攻擊的命中加值，存為陣列，每個元素代表一個攻擊

    totalDamageRolls: number[] = [];// 總傷害骰子結果，存為陣列，每個元素代表一個攻擊

    underAttackDamageValue: number = 0;// 受到攻擊時的傷害值

    // todo 優劣勢紀錄
    // Advantage // 優勢
    // Disadvantage // 劣勢
    // Neutral // 中性
    isAdvantage: boolean = false;

    // todo
    // extraTargetCount 是可在一次攻擊時進行多個目標的攻擊，可以的話設計上要把計算後的傷害分攤在目標身上
    // extraAttackTimes 在設計時是直接一輪發一次牌，但如果把技能作為發牌按鈕的話，可以把它的功能讓出來，外面應該是操作技能重置
    // 加值 跟 丟骰子 的動畫效果不同，加值直接顯示名稱與加上去的數值，丟骰子有自己的圖片(目前是用卡片補間的動畫來替代)

    // 上面那些處理命中、傷害應該可以整合在 CombatIntent
    combatIntent: CombatIntent;

    dodgeCounterattackDamageValue: number = 0; // 閃避反擊傷害
    counterattackDamageValue: number = 0; // 反擊傷害

    intentContents: string[] = [];

    // 臨時護甲
    temporaryArmor: number = 0;
    get ac(): number {
        const shieldArmor = this.combatArmor.shielded ? 2 : 0;
        console.log('shieldArmor:', shieldArmor);
        return this.combatArmor.armorClass + shieldArmor + this.temporaryArmor;
    }

    tempHP: number = 0;
    // constructor(name: string, compositeAbilities: CompositeAbilities, armorClass: number, defaultDamage?: Damage) {
    constructor(name: string, compositeAbilities: CompositeAbilities, dexterity: number, defaultDamage?: Damage) {
        this.name = name;

        this.hitPoints = compositeAbilities.constitution;
        this.sanityPoints = compositeAbilities.spirit;
        this.moralePoints = compositeAbilities.willpower;

        // todo 可升級提高輕中甲的防禦等級
        this.combatArmor = new CombatArmor('', dexterity, new Armor('', '', '0 gold', 1, 0, 0, 'None', 'Light'));

        // this.defaultDamage = defaultDamage || { dice: '1d4', type: 'Unarmed' }; // 預設傷害為徒手攻擊，不同類型會有不同的天生攻擊傷害
        if (defaultDamage) {
            // todo 可以設計為直接傳combatweapon，名稱什麼的可以在外面處理好
            this.naturalWeapon = { name: '天生武器', damage: defaultDamage, range: 'Melee' };//todo 有引用問題，之後想一下怎麼處理
        } else {
            this.naturalWeapon = { name: '拳擊', damage: { dice: '1d4', type: 'Unarmed' }, range: 'Melee' };//todo 有引用問題，之後想一下怎麼處理
        }
        this.unequipWeapon();//test

        this.combatIntent = new CombatIntent();

        this.resetBonuses();
    }

    // 實體進行攻擊
    abstract hit(): { roll: number, isFull: boolean };
    abstract advantageHit(): { roll: number, isFull: boolean }[];
    abstract disadvantageHit(): { roll: number, isFull: boolean }[];
    // abstract attack(target: CombatEntity, weapon?: CombatWeapon): void;
    abstract attack(target: CombatEntity, weaponIndex: number): void;
    abstract intent(member: TeamMember): CombatIntent;
    abstract reaction(): boolean;
    abstract counterattack(target: CombatEntity): boolean;
    //
    applyEffect(attribute: EffectAttribute, value: number) {
        if (this.affixEffects[attribute] !== undefined) {
            this.affixEffects[attribute] += value;
            console.log(`${this.name}'s ${attribute} changed by ${value}. Now: ${this.affixEffects[attribute]}`);
        }
    }

    // 實體受到攻擊，先暫存
    receiveAttack(damageValue: number): void {
        this.underAttackDamageValue = damageValue;
        console.log(`${this.name} received ${damageValue} damage and now has ${this.hitPoints} hit points.`);
    }

    // 結算傷害
    resultDamage(): number {
        let damageValue = this.underAttackDamageValue;
        this.underAttackDamageValue = 0;

        if (damageValue === 0) {
            return 0; // 未受到攻擊
        }

        this.hitPoints -= damageValue - this.tempHP;
        console.log('傷害執行完成 HP:', this.hitPoints, '(-', damageValue, ')');

        this.isDead = this.hitPoints <= 0;
        if (this.isDead) {
            console.log(`${this.name} is dead.`);
        }

        return damageValue;
    }

    // receiveCounterattack(damageValue: number): number {
    //     if (damageValue === 0) {
    //         // todo 未命中時觸發反應
    //         return 0; // 未受到攻擊
    //     }

    //     // todo 命中時觸發反應

    //     this.hitPoints -= damageValue;
    //     console.log('反擊傷害執行完成 HP:', this.hitPoints, '(-', damageValue, ')');

    //     this.isDead = this.hitPoints <= 0;
    //     if (this.isDead) {
    //         console.log(`${this.name} is dead.`);
    //     }

    //     return damageValue;
    // }

    // 擲骰
    private roll(sides: number, base: number = 0) {
        return randomRangeInt(1, sides) + base;
    }

    // 進行命中檢定
    protected rollHit(hitBonus: number): { roll: number, isFull: boolean } {
        let hitRoll: number;
        // 目盲
        if (this.affixEffects.blind) {
            // 劣勢命中檢定
            hitRoll = this.rollHitWithDisadvantage();
        } else {
            hitRoll = this.roll(20);
        }
        console.log(`${this.name} hit ${hitRoll} + ${hitBonus}`);
        return { roll: hitRoll + hitBonus, isFull: hitRoll >= this.hitCriticalPoint };
    }

    // 進行優勢命中檢定
    protected rollHitWithAdvantage(): number {
        return Math.max(this.roll(20), this.roll(20));
    }

    // 進行劣勢命中檢定
    protected rollHitWithDisadvantage(): number {
        return Math.min(this.roll(20), this.roll(20));
    }

    // 進行傷害值擲骰
    protected rollDamage(damage: Damage): number {
        return this.rollDice(damage.dice);
    }

    // 輸入骰子( nDm+k 格式為額外擲骰, ex: 1d6+2 ; +n 格式為固定加值, ex: +2 )
    protected rollDice(diceFormula: string): number {
        console.log(`${this.name} rolled ${diceFormula}`);

        if (diceFormula.indexOf('-') === 0) {
            // 針對 -n 的處理，直接返回加值
            return parseInt(diceFormula, 10);
        }

        const parts = diceFormula.split('+');
        if (parts[0] === '') {
            // 針對 +n 的處理，直接返回加值
            return parseInt(parts[1], 10);
        }

        var dice;
        if (parts.length === 2) {
            dice = parts[0].split('d');
        } else {
            dice = diceFormula.split('d');
        }

        const numberOfDice = parseInt(dice[0], 10);
        const sides = parseInt(dice[1], 10);
        let total = 0;

        for (let i = 0; i < numberOfDice; i++) {
            total += randomRangeInt(1, sides);
        }

        if (parts.length > 1) {
            total += parseInt(parts[1], 10);
        }

        return total;
    }

    // 重置額外效益
    resetBonuses() {
        // this.extraHitDices.length = 0;
        // this.extraDamageDices.length = 0;
        // this.extraAttackTimes = 0;
        // this.extraTargetCount = 0;

        // this.comboHitRolls.length = 0;

        this.affixEffects = {
            hitBonus: 0,//命中加成
            damageBonus: 0,//傷害加成
            // criticalHit: 0,//爆擊率
            // criticalDamage: 0,//爆傷加成
            // disarm: 0,//解除武器
            // escape: 0,//逃跑
            poison: 0,//中毒
            bleeding: 0,//流血
            frenzy: 0,//狂怒
            stun: 0,//眩暈
            blind: 0,//致盲
            paralyze: 0,//麻痹
            confusion: 0,//混亂
        };

        this.actionPoints = {
            'Move': 1,//移動
            'Reaction': 1,//反應
            // 'Concentration': 1,//專注
            'Action': 1,//行動
            'Bonus': 1,//附贈動作
        };

    }

    // todo CombatMonster 應該不需要武器裝備，攻擊都是怪物意圖來設計
    // 武器上手
    equipWeapon(index: number, weapon: Weapon, proficiencyBonus: number): void {
        const combatWeapon: CombatWeapon = new CombatWeapon(weapon, proficiencyBonus);
        this.combatWeapons[index] = combatWeapon;
    }

    // 解除武器
    unequipWeapon(index?: number): void {
        const weapon = new Weapon(this.naturalWeapon.name, '0 gold', 0, WeaponStyle.Unarmed, '', this.naturalWeapon.damage, [], this.naturalWeapon.range);
        if (index === undefined) {
            this.combatWeapons = [
                new CombatWeapon(weapon),
                new CombatWeapon(weapon)
            ];
            console.log(`${this.name} has unequipped all weapons.`);
            return;
        }

        if (index < this.combatWeapons.length) {
            console.log(`${this.name} has unequipped ${this.combatWeapons[index].name}.`);
            this.combatWeapons[index] = new CombatWeapon(weapon);
        } else {
            console.log("Invalid weapon index.");
        }
    }

    // todo CombatMonster 應該不需要 Armor 跟 Shield，這兩個東西直接用設定的就好
    equipArmor(armor: Armor): void {
        this.combatArmor.dress(armor);
    }

    unequipArmor(): void {
        this.combatArmor.dress(null);
    }

    equipShield(shield: Shield): void {
        this.combatArmor.shield(true);
    }

    unequipShield(): void {
        this.combatArmor.shield(false);
    }
}


// // 更換武器
// changeWeapon(index: number): void {
//     if (index < this.weapons.length) {
//         this.mainHandDamage = this.weapons[index].damage;
//         console.log(`${this.name} has switched to ${this.weapons[index].name}.`);
//     } else {
//         console.log("Invalid weapon index.");
//     }
// }

// // 雙持武器
// dualWieldWeapons(): void {
//     if (this.weapons.length > 1) {
//         this.mainHandDamage = this.weapons[0].damage;
//         this.offHandDamage = this.weapons[1].damage;
//     }
// }

// // 雙手持握武器
// twoHandedWeapons(): void {
//     // 檢查是否副手為徒手狀態
//     const twoHandedWeapon = this.weapons.find((weapon) => weapon.properties.some((type) => type === 'Versatile'));
//     if (this.offHandDamage === this.punchDamage && twoHandedWeapon) {
//         this.mainHandDamage = twoHandedWeapon.damage;
//     } else {
//         console.log("Off-hand weapon must be a punch weapon.");
//     }
// }