import { _decorator, Button, Component, instantiate, Node, RichText, size } from "cc";
import { Direction, DungeonMaze, Room } from "./Dungeon";
import { MazeDisplay } from "./MazeDisplay";
import { DescriptionScrollView } from "../tools/DescriptionScrollView";
import { NetworkGraph } from "./NetworkGraph";
import { EventManager } from "../managers/EventManager";
import { WordPuzzleGameLogicEvent } from "../managers/GameEvents";
import { CharacterInfo } from "../ui/character/CharacterInfo";
import { FillBlanks } from "../tools/FillBlanks";

const { ccclass, property } = _decorator;

@ccclass('Rogue')
export default class Rogue extends Component {

    @property(NetworkGraph)
    networkGraph: NetworkGraph = null!;

    @property(DescriptionScrollView)
    descriptionScrollView: DescriptionScrollView = null!;

    @property(MazeDisplay)
    mazeDisplay: MazeDisplay = null;

    @property(CharacterInfo)
    characterInfo: CharacterInfo = null!;

    dungeon: DungeonMaze = null;

    currX: number = 0;
    currY: number = 0;

    data;

    protected onLoad(): void {
        this.networkGraph.node.active = false;
        this.descriptionScrollView.node.active = false;
        this.mazeDisplay.node.active = false;
    }
    // protected start(): void {
    //     this.createDungeon(5, 5, 2, 0);
    // }

    // 地城探索
    setDungeonData(data: any): void {
        this.data = data;
        const { roomType, icon, name, descriptions, connectIn, locations } = data;

        this.networkGraph.node.active = true;
        this.networkGraph.createInitialNode(icon, name, this.enterDungeon.bind(this));

        this.descriptionScrollView.node.active = true;
        this.descriptionScrollView.setData(descriptions);
    }

    enterDungeon(dungeonName: string): void {
        console.log(dungeonName);
        const locations = this.data.locations;
        const { roomType, icon, name, size, position, rooms } = locations[0];// todo 暫時先取第一個locations來用

        // this.networkGraph.removeAllNodes();
        // this.networkGraph.createInitialNode(icon, name);

        this.descriptionScrollView.clear();

        // todo 地圖由玩家點擊開啟關閉，這邊先暫時直接秀
        this.mazeDisplay.node.active = true;

        // 建立迷宮
        const exitRoom = this.createDungeon(size[0], size[1], position[0], position[1]);
        const currentRoom = this.getCurrentRoom();

        // todo 隨機生成，排除第一跟最後一間
        this.dungeon.rooms.forEach((thesRooms: Room[]) => {
            const data = rooms[1];// todo 暫時先取第二個room來用，要做除了1跟最後一個之外的隨機生成
            thesRooms.forEach((room: Room) => {
                room.setInfo(data);
            });
        });

        const startRoomData = rooms[0];
        currentRoom.setInfo(startRoomData);

        const exitRoomData = rooms[rooms.length - 1];
        exitRoom.setInfo(exitRoomData);

        this.setDungeonRoom(currentRoom);
    }

    setDungeonRoom(currentRoom: Room): void {
        console.log(currentRoom);

        if (currentRoom.descriptions.length > 0) {
            this.descriptionScrollView.node.active = true;
            this.descriptionScrollView.setData(currentRoom.descriptions);
        }

        const notifyStartWordPuzzleGame = () => EventManager.instance.emit(WordPuzzleGameLogicEvent.WordPuzzleGameStart, currentRoom);
        this.networkGraph.removeAllNodes();
        this.networkGraph.createInitialNode(currentRoom.icon, currentRoom.name, notifyStartWordPuzzleGame);

        currentRoom.connections.forEach(connection => {
            // console.log(connection);
            let offsetX, offsetY, callback;
            switch (connection) {
                case Direction.North:
                    offsetX = 0;
                    offsetY = 200;
                    callback = () => {
                        this.onNorthDoorClick();
                    };
                    break;
                case Direction.East:
                    offsetX = 200;
                    offsetY = 0;
                    callback = () => {
                        this.onEastDoorClick();
                    };
                    break;
                case Direction.South:
                    offsetX = 0;
                    offsetY = -200;
                    callback = () => {
                        this.onSouthDoorClick();
                    };
                    break;
                case Direction.West:
                    offsetX = -200;
                    offsetY = 0;
                    callback = () => {
                        this.onWestDoorClick();
                    };
                    break;
            }
            this.networkGraph.addNode(currentRoom.icon, offsetX, offsetY, 'creation1', '門', callback);
        });
    }

    createDungeon(width: number, height: number, startX: number, startY: number): Room | null {
        if (width < 0 || height < 0 || width <= startX || height <= startY || startX < 0 || startY < 0) {
            console.error('Invalid dungeon size or start position');
            return;
        }

        this.dungeon = new DungeonMaze(width, height);
        this.dungeon.generateMaze(startX, startY);
        // console.log(dungeon.rooms);

        // 從起始房間開始，用廣度優先搜尋，尋找出口房間
        const exitRoom = this.dungeon.findExit(startX, startY);
        console.log('exit:', exitRoom);

        this.mazeDisplay.showDungeon(this.dungeon, startX, startY, exitRoom);

        this.currX = startX;
        this.currY = startY;

        return exitRoom;
    }

    // 移動至房間
    moveToRoom(roomX: number, roomY: number): void {
        if (roomX < 0 || roomY < 0 || roomX >= this.dungeon.width || roomY >= this.dungeon.height) {
            console.error('Invalid room position');
            return;
        }

        // const room = this.dungeon.rooms[roomX][roomY];
        const room = this.dungeon.rooms[roomY][roomX];
        if (!room) {
            console.error('Invalid room');
            return;
        }

        // // 檢查是否有鎖
        // if (room.hasLock) {
        //     console.log('This room has a lock');
        //     return;
        // }

        // // 檢查是否有陷阱
        // if (room.hasTrap) {
        //     console.log('This room has a trap');
        //     return;
        // }

        // // 檢查是否有怪物
        // if (room.hasMonster) {
        //     console.log('This room has a monster');
        //     return;
        // }

        // 進入移動至下一房間
        this.currX = roomX;
        this.currY = roomY;
        this.mazeDisplay.movePlayer(this.dungeon, roomX, roomY);

        this.setDungeonRoom(room);
    }

    getCurrentRoom(): Room {
        return this.dungeon.rooms[this.currY][this.currX];
    }

    // 門的功能: 感知檢定、進入移動至下一房間、是否有鎖、是否有陷阱、是否有怪物
    onSouthDoorClick(): void {
        const room = this.getCurrentRoom();
        if (room && room.connections.includes(Direction.South)) {
            this.moveToRoom(this.currX, this.currY - 1);
        }
    }

    onEastDoorClick(): void {
        const room = this.getCurrentRoom();
        if (room && room.connections.includes(Direction.East)) {
            this.moveToRoom(this.currX + 1, this.currY);
        }
    }

    onNorthDoorClick(): void {
        const room = this.getCurrentRoom();
        if (room && room.connections.includes(Direction.North)) {
            this.moveToRoom(this.currX, this.currY + 1);
        }
    }

    onWestDoorClick(): void {
        const room = this.getCurrentRoom();
        if (room && room.connections.includes(Direction.West)) {
            this.moveToRoom(this.currX - 1, this.currY);
        }
    }
}