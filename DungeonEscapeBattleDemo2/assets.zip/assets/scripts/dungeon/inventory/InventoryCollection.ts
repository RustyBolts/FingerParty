import { _decorator, Component } from 'cc';
import { Inventory } from '../inventory/Inventory';
import { TipCard } from '../../cards/Card';
import { Weapon, WeaponStyle } from '../item/Weapon';
import { EventManager } from '../../managers/EventManager';
import { UIEvent } from '../../managers/UIManager';
import { Armor } from '../item/Armor';

const { ccclass, property } = _decorator;

@ccclass('InventoryCollection')
export class InventoryCollection extends Component {

    @property(Inventory)
    inventory: Inventory = null!;

    collect(tip: TipCard) {
        EventManager.instance.emit(UIEvent.InventoryShowUI, true);

        // const armorStuddedLeather = new Armor("鑲釘皮甲", "studded leather", "45 gold", 13, 12, 0, 'None', 'Light');

        // const armorRawhide = new Armor("生皮甲", "rawhide", "10 gold", 12, 12, 0, 'None', 'Medium');
        // const armorChainShirt = new Armor("鏈甲衫", "chain shirt", "50 gold", 20, 13, 0, 'None', 'Medium');
        // const armorScaleMail = new Armor("鱗甲", "scale mail", "50 gold", 45, 14, 0, 'Disadvantage', 'Medium');
        // const armorBreastplate = new Armor("護胸甲", "breastplate", "400 gold", 20, 14, 0, 'None', 'Medium');
        // const armorHalfPlate = new Armor("半身板甲", "half plate", "750 gold", 40, 15, 0, 'Disadvantage', 'Medium');

        // const armorRingMail = new Armor("環甲", "ringmail", "30 gold", 40, 14, 0, 'Disadvantage', 'Heavy');
        // const armorSplint = new Armor("條板甲", "splint", "200 gold", 60, 17, 15, 'Disadvantage', 'Heavy');
        // const armorPlate = new Armor("全身板甲", "plate", "1,500 gold", 65, 18, 15, 'Disadvantage', 'Heavy');

        // todo 整理一下
        console.log('取得物品:', tip.string);
        if (tip.coping === 'rawhide') {
            this.inventory.addItem(
                new Armor("皮甲", "leather", "10 gold", 10, 11, 0, 'None', 'Light')
            );
        } else if (tip.coping === 'chainmail') {
            this.inventory.addItem(
                new Armor("鎖子甲", "chainmail", "75 gold", 55, 16, 13, 'Disadvantage', 'Heavy')
            );
        } else if (tip.coping === 'padded') {
            this.inventory.addItem(
                new Armor("綿甲", "padded", "5 gold", 8, 11, 0, 'Disadvantage', 'Light')
            )
        } else if (tip.coping === 'dagger') {
            this.inventory.addItem(
                new Weapon('匕首', '2 gold', 1, WeaponStyle.Dagger, 'dagger', { dice: '1d4', type: 'Piercing' }, ['Finesse', 'Light', 'Thrown'], 'Melee'),//Finesse 靈巧
            );
        } else if (tip.coping === 'longswood') {
            this.inventory.addItem(
                new Weapon('長劍', '15 gold', 3, WeaponStyle.Longsword, 'long_swood', { dice: '1d8', dice2: '1d10', type: 'Slashing' }, ['Versatile'], 'Melee'),
            );
        } else if (tip.coping === 'hammer') {
            this.inventory.addItem(
                new Weapon('銅錘', '2 gold', 2, WeaponStyle.LightHammer, 'hammer', { dice: '1d4', type: 'Bludgeoning' }, ['Light', 'Thrown'], 'Melee'),//todo 可以投擲
            );
        } else if (tip.coping === 'axe') {
            this.inventory.addItem(
                new Weapon('手斧', '5 gold', 2, WeaponStyle.Handaxe, 'axe', { dice: '1d6', type: 'Slashing' }, ['Light', 'Thrown'], 'Melee'),
            );
        }
    }
}