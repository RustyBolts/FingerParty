import { EventTouch, Label, _decorator } from 'cc';
import { Draggable } from '../../tools/Draggable';
import { Item } from '../item/Item';
import { Armor } from '../item/Armor';
import { EventManager } from '../../managers/EventManager';
import { EquipmentDropZone, EquipmentDropZoneIndex } from './EquipmentDropZone';
const { ccclass, property } = _decorator;

@ccclass('ArmorDraggable')
export class ArmorDraggable extends Draggable {

    nameLabel: Label = null;
    _armor: Armor = null;
    equipmentIndex: EquipmentDropZoneIndex = EquipmentDropZoneIndex.None;

    set armor(value: Armor) {
        this._armor = value;
        console.log('Armor = ', value);

        this.nameLabel = this.node.getComponentInChildren(Label);
        this.nameLabel.string = value.name;

        this.setPhotoImage(value.iconName);
    }

    get item(): Item {
        return this._armor;
    }

    onTouchStart(event: EventTouch): void {
        super.onTouchStart(event);

        if (this.equipmentIndex !== EquipmentDropZoneIndex.None) {
            const equipment = this.zone as EquipmentDropZone;
            // EventManager.instance.emit('CharacterUnequip', { index: equipment.serialIndex });
            EventManager.instance.emit('CharacterEquipArmor', { index: equipment.serialIndex, item: null });
            this.equipmentIndex = EquipmentDropZoneIndex.None;
        }
    }
}