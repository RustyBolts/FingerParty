import { _decorator, Enum } from 'cc';
import { DropZone } from '../../tools/DropZone';
import { WeaponDraggable } from './WeaponDraggable';
import { EventManager } from '../../managers/EventManager';
import { ArmorDraggable } from './ArmorDraggable';
import { ShieldDraggable } from './ShieldDraggable';
import { Draggable } from '../../tools/Draggable';
const { ccclass, property } = _decorator;

export enum EquipmentDropZoneIndex {
    None,
    WeaponOrShield,
    Armor,
}

/**
 * CharacterInfo 裝備欄位的 DropZone
 */
Enum(EquipmentDropZoneIndex);
@ccclass('EquipmentDropZone')
export class EquipmentDropZone extends DropZone {
    @property({ type: EquipmentDropZoneIndex })
    equipmentIndex: EquipmentDropZoneIndex = EquipmentDropZoneIndex.WeaponOrShield;// 裝備欄位的索引

    @property
    serialIndex: number = 0;

    onDrop(event) {
        const draggableItem: Draggable = event.draggableItem;
        const dropZone: DropZone = event.dropZone;
        console.log('Drop on equipmentDropZone', dropZone instanceof EquipmentDropZone, this.equipmentIndex);

        // 是否為武器物件
        if (this.equipmentIndex === EquipmentDropZoneIndex.WeaponOrShield && draggableItem instanceof WeaponDraggable) {
            super.onDrop(event);

            console.log('Weapon dropped', draggableItem.item);
            draggableItem.equipmentIndex = this.equipmentIndex;
            EventManager.instance.emit('CharacterEquipWeapon', { index: this.serialIndex, item: draggableItem.item });

            return;
        }

        // 是否為護甲物件
        if (this.equipmentIndex === EquipmentDropZoneIndex.Armor && draggableItem instanceof ArmorDraggable) {
            super.onDrop(event);

            console.log('Armor dropped', draggableItem.item);
            draggableItem.equipmentIndex = this.equipmentIndex;
            EventManager.instance.emit('CharacterEquipArmor', { index: this.serialIndex, item: draggableItem.item });

            return;
        }

        // 是否為盾牌物件
        if (this.equipmentIndex === EquipmentDropZoneIndex.WeaponOrShield && draggableItem instanceof ShieldDraggable) {
            super.onDrop(event);

            console.log('Armor dropped', draggableItem.item);
            draggableItem.equipmentIndex = this.equipmentIndex;
            EventManager.instance.emit('CharacterEquipShield', { index: this.serialIndex, item: draggableItem.item });

            return;
        }

        // 不符合條件就取消返回原本的位置
        draggableItem.touchCancel();
    }
}