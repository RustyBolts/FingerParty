import { Label, _decorator, Sprite, SpriteFrame, resources, EventTouch } from 'cc';
import { Draggable } from '../../tools/Draggable';
import { Item } from '../item/Item';
import { Weapon } from '../item/Weapon';
import { EventManager } from '../../managers/EventManager';
import { EquipmentDropZone, EquipmentDropZoneIndex } from './EquipmentDropZone';
import { DropZone } from '../../tools/DropZone';
const { ccclass, property } = _decorator;

@ccclass('WeaponDraggable')
export class WeaponDraggable extends Draggable {

    // @property(Label)
    nameLabel: Label = null;

    _weapon: Weapon = null;

    equipmentIndex: EquipmentDropZoneIndex = EquipmentDropZoneIndex.None;

    set weapon(value: Weapon) {
        this._weapon = value;
        console.log('WeaponDraggable.weapon = ', value);

        this.nameLabel = this.node.getComponentInChildren(Label);
        this.nameLabel.string = value.name;

        this.setPhotoImage(value.icon);
    }

    get item(): Item {
        return this._weapon;
    }

    onTouchStart(event: EventTouch): void {
        super.onTouchStart(event);
        console.log('WeaponDraggable.onTouchStart');
        if (this.equipmentIndex !== EquipmentDropZoneIndex.None) {
            const equipment = this.zone as EquipmentDropZone;
            EventManager.instance.emit('CharacterUnequip', { index: equipment.serialIndex });
            this.equipmentIndex = EquipmentDropZoneIndex.None;
        }
    }
}