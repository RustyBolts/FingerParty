import { _decorator, Component, instantiate, Label, Node } from 'cc';
import { Item } from '../item/Item';
import { Weapon, WeaponStyle } from '../item/Weapon';
import { Armor } from '../item/Armor';
import { Shield } from '../item/Shield';
import { WeaponDraggable } from './WeaponDraggable';
import { DropZone } from '../../tools/DropZone';
import { Draggable } from '../../tools/Draggable';
import { ArmorDraggable } from './ArmorDraggable';
import { ShieldDraggable } from './ShieldDraggable';
const { ccclass, property } = _decorator;

@ccclass('Inventory')
export class Inventory extends Component {
    @property(Node)
    layout: Node = null; // 道具栏的节点

    @property(Node)
    itemPrefab: Node = null; // 道具预制体

    @property
    maxWeight: number = 100;  // 最大承重

    @property
    maxSlots: number = 10;    // 最大格数

    private items: Item[] = []; // 存储道具的数组
    private currentWeight: number = 0; // 当前总重量
    private currentSlots: number = 0;  // 当前已用格数

    protected onLoad(): void {
        this.show(true);// 測試時預設先開啟道具栏
    }

    // private sample() {
    //     const weapon: Weapon = new Weapon('長劍', '15 gold', 3, WeaponStyle.Longsword, 'long_swood', { dice: '1d8', dice2: '1d10', type: 'Slashing' }, ['Versatile'], 'Melee');
    //     this.addItem(weapon);
    // }

    show(active: boolean) {
        this.node.active = active; // 显示或隐藏道具栏
    }

    private instantiate(item: Item, parentZone: DropZone): Node | null {
        const node = instantiate(this.itemPrefab);
        node.active = true;
        // node.parent = this.layout;

        if (item instanceof Weapon) {
            console.log(`Weapon ${item.name} added to inventory.`);
            const draggable = node.addComponent(WeaponDraggable);
            draggable.weapon = item;

            parentZone.node.emit('drop', {
                draggableItem: draggable,
                dropZone: parentZone
            });
        }
        else if (item instanceof Armor) {
            console.log(`Armor ${item.name} added to inventory.`);
            const draggable = node.addComponent(ArmorDraggable);
            draggable.armor = item;

            parentZone.node.emit('drop', {
                draggableItem: draggable,
                dropZone: parentZone
            });
        }
        else if (item instanceof Shield) {
            console.log(`Shield ${item.name} added to inventory.`);
            const draggable = node.addComponent(ShieldDraggable);
            draggable.shield = item;

            parentZone.node.emit('drop', {
                draggableItem: draggable,
                dropZone: parentZone
            });
        }

        return node;
    }

    // 添加道具到道具栏
    addItem(item: Item): boolean {
        if (this.currentWeight + item.weight > this.maxWeight || this.currentSlots + item.size > this.maxSlots) {
            console.error("Cannot add item: exceeds weight or slot limit.");
            return false; // 如果超出重量或格数限制，返回 false
        }

        // 找到空闲的格子，实例化道具预制体
        const zones: DropZone[] = this.layout.getComponentsInChildren(DropZone);
        const freeSlot = zones.find(zone => zone.placeholder.children.length === 0);
        if (freeSlot) {
            this.items.push(item);
            this.currentWeight += item.weight;
            this.currentSlots += item.size;

            const node = this.instantiate(item, freeSlot); // 实例化道具预制体

            return true; // 成功添加道具
        }
        return false; // 道具欄位已满
    }

    // 从道具栏移除道具
    removeItem(itemName: string): boolean {
        const index = this.items.findIndex(item => item.name === itemName);
        if (index === -1) {
            console.error("Item not found in inventory.");
            return false; // 如果未找到道具，返回 false
        }
        const item = this.items[index];
        this.items.splice(index, 1);
        this.currentWeight -= item.weight;
        this.currentSlots -= item.size;
        console.log(`${item.name} removed from inventory.`);
        return true; // 成功移除道具
    }

    // 获取当前道具列表
    listItems(): Item[] {
        return this.items; // 返回一个道具数组的复制
    }

    onInventoryButtonClicked() {
        this.show(!this.node.active);
    }
}
