// 定義基本類型
enum RoomType {
    Battle,
    Treasure,
    Rest
}

class Player {
    constructor(
        public name: string,
        public health: number,
        public magic: number,
        public experience: number
    ) { }
}

class Monster {
    constructor(
        public id: number,
        public name: string,
        public health: number,
        public attack: number
    ) { }
}

class Item {
    constructor(
        public id: number,
        public name: string,
        public type: string
    ) { }
}

export enum Direction {
    North,
    South,
    East,
    West
}

export class Room {
    // public id: number;
    // public type: RoomType;
    // public monsters: Monster[];
    // public items: Item[];

    public instanceNode = null;

    x: number;
    y: number;
    icon: string;
    name: string;
    descriptions: string[];
    connections: Direction[];
    question: string;
    cards: string[];

    constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
        this.connections = [];
    }

    setInfo(data: any): void {
        this.icon = data.icon;
        this.name = data.name;
        this.descriptions = data.descriptions;
        this.question = data.question;
        this.cards = data.cards;
    }

    connectWith(room: Room): void {
        if (this.x < room.x) {
            this.connections.push(Direction.East);
            room.connections.push(Direction.West);
        } else if (this.x > room.x) {
            this.connections.push(Direction.West);
            room.connections.push(Direction.East);
        } else if (this.y < room.y) {
            this.connections.push(Direction.North);
            room.connections.push(Direction.South);
        } else if (this.y > room.y) {
            this.connections.push(Direction.South);
            room.connections.push(Direction.North);
        }
    }
}

export class DungeonMaze {
    rooms: Room[][];
    width: number;
    height: number;

    constructor(width: number, height: number) {
        this.width = width;
        this.height = height;
        this.rooms = Array.from({ length: height }, (_, y) =>
            Array.from({ length: width }, (_, x) => new Room(x, y))
        );
    }

    /**
     * 生成迷宮
     * @param x 起始位置 x
     * @param y 起始位置 y
     */
    generateMaze(x: number = 0, y: number = 0): void {
        let stack: Room[] = [];
        let currentRoom = this.rooms[x][y];
        let visitedRooms = new Set<Room>();
        visitedRooms.add(currentRoom);
        stack.push(currentRoom);

        while (stack.length > 0) {
            currentRoom = stack.pop()!;
            const neighbors = this.getUnvisitedNeighbors(currentRoom, visitedRooms);

            if (neighbors.length > 0) {
                stack.push(currentRoom);
                const randomNeighbor = neighbors[Math.floor(Math.random() * neighbors.length)];
                currentRoom.connectWith(randomNeighbor);
                visitedRooms.add(randomNeighbor);
                stack.push(randomNeighbor);
            }
        }
    }

    /**
     * 取得無訪問邻居
     * @param room 房間
     * @param visitedRooms 已訪問房間集合
     * @returns 
     */
    getUnvisitedNeighbors(room: Room, visitedRooms: Set<Room>): Room[] {
        let neighbors: Room[] = [];

        const { x, y } = room;

        // Ensure the room does not attempt to connect beyond the dungeon boundaries
        if (x > 0 && !visitedRooms.has(this.rooms[y][x - 1])) {
            neighbors.push(this.rooms[y][x - 1]); // West
        }
        if (x < this.width - 1 && !visitedRooms.has(this.rooms[y][x + 1])) {
            neighbors.push(this.rooms[y][x + 1]); // East
        }
        if (y > 0 && !visitedRooms.has(this.rooms[y - 1][x])) {
            neighbors.push(this.rooms[y - 1][x]); // North
        }
        if (y < this.height - 1 && !visitedRooms.has(this.rooms[y + 1][x])) {
            neighbors.push(this.rooms[y + 1][x]); // South
        }

        return neighbors;
    }

    findExit(startX: number, startY: number): Room | null {
        let queue: Room[] = [];
        let visitedRooms = new Set<Room>();
        let startRoom = this.rooms[startY][startX];
        visitedRooms.add(startRoom);
        queue.push(startRoom);

        while (queue.length > 0) {
            let currentRoom = queue.shift()!;

            // 檢查這個房間是否是除了入口之外只有一個通道的死胡同
            if (currentRoom !== startRoom && currentRoom.connections.length === 1) {
                return currentRoom; // 找到出口
            }

            // 尋找鄰居並繼續搜索
            this.getNeighbors(currentRoom).forEach(neighborRoom => {
                if (!visitedRooms.has(neighborRoom)) {
                    visitedRooms.add(neighborRoom);
                    queue.push(neighborRoom);
                }
            });
            console.log(queue.length);
        }

        return null; // 如果沒有找到死胡同，返回 null
    }

    getNeighbors(room: Room): Room[] {
        let neighbors: Room[] = [];
        const { x, y } = room;

        // 檢查並添加有效鄰居
        if (room.connections.includes(Direction.South) && y > 0) {
            neighbors.push(this.rooms[y - 1][x]);
        }
        if (room.connections.includes(Direction.North) && y < this.height - 1) {
            neighbors.push(this.rooms[y + 1][x]);
        }
        if (room.connections.includes(Direction.West) && x > 0) {
            neighbors.push(this.rooms[y][x - 1]);
        }
        if (room.connections.includes(Direction.East) && x < this.width - 1) {
            neighbors.push(this.rooms[y][x + 1]);
        }

        return neighbors;
    }
}
