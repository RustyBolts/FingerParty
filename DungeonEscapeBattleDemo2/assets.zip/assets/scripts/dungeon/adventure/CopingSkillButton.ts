import { _decorator, Component, Label } from 'cc';
import { EventManager } from '../../managers/EventManager';
import { AdventureSkill } from './AdventureSkill';
const { ccclass, property } = _decorator;

@ccclass('CopingSkillButton')
export class CopingSkillButton extends Component {

    @property(Label)
    nameLabel: Label = null;

    private _adventureName: string = '';
    private _behaviorCoping: any[] = [];

    protected onLoad(): void {
        EventManager.instance.on('CopingDramaBehavior', this.onCopingDramaBehavior, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off('CopingDramaBehavior', this.onCopingDramaBehavior, this);
    }

    private onCopingDramaBehavior(behaviorCopings: any[]): void {
        const coping: any[] = behaviorCopings[this._adventureName];
        if (coping && coping.length > 0) {
            this._behaviorCoping = coping;
            this.node.active = true;
        } else {
            this.node.active = false;
        }
    }

    setAdventureSkill(adventureSkill: AdventureSkill): void {
        this._adventureName = adventureSkill.name;
        this.nameLabel.string = adventureSkill.displayName;
    }

    onClicked(): void {
        EventManager.instance.emit('CopingSkillButtonClickEvent', {
            name: this._adventureName,
            copings: this._behaviorCoping
        });
    }
}