import { Attribute } from "../Ability";
import { Skill, SkillProficiency } from "../Skill";

export enum Adventure {
    Stunts = 'stunts',              // 特技
    Stealth = 'stealth',            // 隱匿
    Dexterity = 'dexterity',        // 巧手
    Knowledge = 'knowledge',        // 知識
    Experience = 'experience',      // 閱歷
    Nature = 'nature',              // 自然
    Religion = 'religion',          // 宗教
    Explore = 'explore',            // 探索
    Nursing = 'nursing',            // 護理
    Awareness = 'awareness',        // 覺察/感知
    Taming = 'taming',              // 馴服
    Survival = 'survival',          // 生存
    Observation = 'observation',    // 觀察
    Performance = 'performance',    // 表演
    Persuasion = 'persuasion',      // 説服
    Intimidation = 'intimidation',  // 威嚇
    //
    Shove = 'shove',// 推撞
}

export class AdventureSkill extends Skill {
    linkedAttribute: Attribute;
    displayName: string;

    constructor(name: Adventure, linkedAttribute: Attribute, displayName: string, description: string = '', proficiencyLevel: SkillProficiency = SkillProficiency.Novice) {
        super(name, description, proficiencyLevel);

        this.linkedAttribute = linkedAttribute;
        this.displayName = displayName;
    }

    upgradeSkillProficiency(): boolean {
        if (this.level === SkillProficiency.Expert) {
            return false;
        }

        this.level++;

        return true;
    }
}