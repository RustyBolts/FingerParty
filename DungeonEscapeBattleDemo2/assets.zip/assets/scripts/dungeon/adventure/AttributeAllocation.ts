import { _decorator, Component, Label } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('AttributeAllocation')
export class AttributeAllocation extends Component {
    @property(Label)
    pointsAvailableLabel: Label = null;

    totalPoints: number = 0;            // 总可配置点数
    pointsUsed: number = 0;     // 已使用点数

    onLoad() {
        this.updatePointsAvailableLabel();
    }

    allocatePoints(amount: number): boolean {
        if (this.pointsUsed + amount <= this.totalPoints) {
            this.pointsUsed += amount;
            this.updatePointsAvailableLabel();
            return true;
        }
        return false;
    }

    freePoints(amount: number): void {
        this.pointsUsed -= amount;
        this.updatePointsAvailableLabel();
    }

    updatePointsAvailableLabel() {
        this.pointsAvailableLabel.string = `Available Points: ${this.totalPoints - this.pointsUsed}`;
    }
}
