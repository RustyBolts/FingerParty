import { _decorator, Component, RichText, Vec3 } from "cc";
import { HandCards } from "../../cards/HandCards";
import { FillBlanks, ReplacedTipCard } from "../../tools/FillBlanks";
import { EventManager } from "../../managers/EventManager";
import { TipType } from "../../tools/TipText";
import { TipCard } from "../../cards/Card";

const { ccclass, property } = _decorator;

export enum CrosswordType {
    SetAnswerQuestion = 'crossword_type_set_answer_question',
}

@ccclass('DescriptionCrossword')
export default class DescriptionCrossword extends Component {

    @property(RichText)
    private questionLabel: RichText = null!;

    @property(HandCards)
    private answerHandCards: HandCards = null;

    private question: string = '';
    private conditions: string[] = [];
    private solutions: TipCard[] = [];

    protected onLoad(): void {
        EventManager.instance.on(CrosswordType.SetAnswerQuestion, this.onSetAnswerQuestion, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(CrosswordType.SetAnswerQuestion, this.onSetAnswerQuestion, this);
    }

    private onSetAnswerQuestion(answers: TipCard[], question: string, solutions: TipCard[], conditions: string[]): void {
        this.setQuestion(question, solutions, conditions);
        this.setAnswer(answers);
    }

    private onSendAnswer(secletedCards: TipCard[]): void {
        const needCondition = this.conditions.length > 0;
        const success = this.solutions.every((solution, index) => {
            const card = secletedCards[index];
            if (!card) {
                return false;
            }

            // 不需要條件，就只檢查是否有填入答案
            if (!needCondition) {
                return card.string != '';
            }

            // 需要條件，檢查是否符合條件
            return this.conditions.every((condition: string) => {
                return solution[condition] === card[condition];
            });
        });

        if (success) {
            EventManager.instance.emit(TipType.NormalDelay, '輸入成功！', 2);
            EventManager.instance.emit('DescriptionCrosswordAnswered', {
                answers: secletedCards,
                sentence: this.questionLabel.string,
            });

            this.questionLabel.string = '';
            this.answerHandCards.clear();
            this.answerHandCards.show(false);

            this.node.active = false;

        } else {
            this.questionLabel.string = this.question;
            EventManager.instance.emit(TipType.Error, '輸入的條件與填入內容不符合');
        }
    }

    private sample(): void {
        this.node.active = true;

        const content = {
            question: 'aaa[_ | type:ok],bbb[_ | type:okla],ccc[_ | type:ok]',
            // conditions: ['string', 'type'],
            conditions: ['type'],
        }

        const replaceTips: ReplacedTipCard[] = FillBlanks.replaceMarkedWithKeywords([content.question], []);
        console.log(replaceTips[0]);

        // const solutions: TipCard[] = [];
        // for (let i = 0; i < 3; i++) {
        //     const card = new TipCard();
        //     card.string = 'card' + i;
        //     card.type = 'ok';
        //     solutions.push(card);
        // }
        const solutions: TipCard[] = replaceTips[0].tipCards;
        this.setQuestion(replaceTips[0].text, solutions, content.conditions);


        const answerCards: TipCard[] = [];
        for (let i = 0; i < 3; i++) {
            const card = new TipCard();
            card.string = 'card' + i;
            card.type = 'ok';
            answerCards.push(card);
        }
        answerCards[1].type = 'okla';//模擬輸入錯誤
        this.setAnswer(answerCards);
    }

    protected start(): void {
        this.node.position = Vec3.ZERO;
        this.node.active = false;

        // this.sample();
    }

    setQuestion(question: string, solutions: TipCard[] = [], conditions: string[] = []): void {
        this.questionLabel.string = this.question = question;
        this.solutions = solutions;

        this.conditions = conditions;

        this.answerHandCards.setSendData(this.solutions.length, this.onSendAnswer.bind(this));
        this.answerHandCards.show(false);
        this.answerHandCards.lock(true);

        this.node.active = true;
    }

    setAnswer(answers: TipCard[]): void {
        this.answerHandCards.show(true);
        this.answerHandCards.list(answers, (selectingCard: TipCard, selectedCards: TipCard[]) => {
            // 顯示在畫面上，已填入的問題與答案
            this.questionLabel.string = FillBlanks.answerQuestion(this.question, selectedCards.map(tip => tip.string));
        });
        this.answerHandCards.lock(false);
    }

    closeAnswer(): void {
        this.answerHandCards.show(false);
    }
}