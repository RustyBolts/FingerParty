import { _decorator, Component, Label, Button } from 'cc';
import { AttributeAllocation } from './AttributeAllocation';
const { ccclass, property } = _decorator;

@ccclass('AttributeComponent')
export class AttributeComponent extends Component {
    @property(Label)
    attributeNameLabel: Label = null;

    @property(Label)
    attributeValueLabel: Label = null;

    @property(Button)
    increaseButton: Button = null;

    @property(Button)
    decreaseButton: Button = null;

    @property(AttributeAllocation)
    allocation: AttributeAllocation = null;

    private _attributeName: string = '';
    private _attributeValue: number = 0;

    protected onLoad(): void {
        this.increaseButton.node.on('click', this.increaseAttribute, this);
        this.decreaseButton.node.on('click', this.decreaseAttribute, this);
    }

    private increaseAttribute(): void {
        if (this.allocation.allocatePoints(1)) {
            this.Value++;
        }
    }

    private decreaseAttribute(): void {
        if (this._attributeValue > 0) {
            this.allocation.freePoints(1);
            this.Value--;
        }
    }

    get Value(): number {
        return this._attributeValue;
    }

    set Value(val: number) {
        this._attributeValue = val;
        this.attributeValueLabel.string = `${this._attributeName}: ${this._attributeValue}`;
    }

    get Name(): string {
        return this._attributeName;
    }

    set Name(name: string) {
        this._attributeName = name;
        // this.attributeNameLabel.string = name;
    }
}
