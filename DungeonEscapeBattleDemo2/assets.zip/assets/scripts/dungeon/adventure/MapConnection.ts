import { _decorator, Component, Node, Vec3, instantiate, Sprite, Label, Graphics, SpriteFrame, resources, Color, Texture2D } from 'cc';
import { DescriptionScrollView } from '../../tools/DescriptionScrollView';
import { DataModal } from '../../data/DataModal';
import { EventManager } from '../../managers/EventManager';
const { ccclass, property } = _decorator;

interface LocationData {
    name: string;
    bg: string;
    drama?: string;// 剧情，用id来表示
    connect: string[];
}

@ccclass('MapConnection')
export class MapConnection extends Component {
    @property(Node)
    background: Node = null!;

    @property(Node)
    mapRoot: Node = null;  // 地图根节点

    @property(Node)
    locationPrefab: Node = null;  // 地点的预制体

    @property(Graphics)
    graphics: Graphics = null;

    @property(DescriptionScrollView)
    descriptionScrollView: DescriptionScrollView = null;

    // protected start(): void {
    // }

    sample(): void {
        const data: LocationData = {
            name: 'long_swood-000:01',
            bg: 'shield',
            connect: ['rawhide-000:00(230,60)', 'chainmail-000:00(-90,330)', 'dagger-(-150,200)']// dagger 沒有時間軸是因為是通用的，不會有劇情
        };

        this.createCenterLocation(data);
        this.descriptionScrollView.hide();
    }

    createCenterLocation(data: LocationData) {
        const name = data.name.split('-')[0];
        const centerNode = this.createLocationNode(name);
        centerNode.setPosition(0, 0, 0);
        centerNode.parent = this.mapRoot;
        this.setClickEvent(centerNode, data.name);

        this.loadConnections(data.connect, centerNode);

        this.setBackgroundImage(data.bg);
    }
    
    private setBackgroundImage(imageName: string): void {
        // Load and set the sprite
        const sprite = this.background.getComponent(Sprite);
        const imagePath = `maps/${imageName}/spriteFrame`;
        resources.load(imagePath, SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error('Failed to load image: ' + err);
                return;
            }
            sprite.spriteFrame = spriteFrame;
            sprite.spriteFrame.texture.setFilters(Texture2D.Filter.NONE, Texture2D.Filter.NONE);
        });
    }


    createLocationNode(name: string): Node {
        const node = instantiate(this.locationPrefab);
        const sprite = node.getComponent(Sprite);
        const label = node.getComponentInChildren(Label);
        label.string = name;
        node.active = true;

        // assetManager.loadAny({ url: `textures/${data.bg}`, type: SpriteFrame }, (err, spriteFrame) => {
        const imagePath = `maps/${name}/spriteFrame`;
        resources.load(imagePath, SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error('Failed to load image: ' + err);
                return;
            }
            sprite.spriteFrame = spriteFrame;
            sprite.spriteFrame.texture.setFilters(Texture2D.Filter.NONE, Texture2D.Filter.NONE);
        });

        return node;
    }

    loadConnections(connect: string[], centerNode: Node) {
        connect.forEach(conn => {
            const name = conn.split('-')[0];
            const match = /([^\(]+)\((\-?\d+),(\-?\d+)\)/.exec(conn);
            if (match) {
                // const name = match[1];
                console.log(name, match[1], match[2], match[3]);
                const x = parseInt(match[2], 10);
                const y = parseInt(match[3], 10);

                const node = this.createLocationNode(name);
                node.setPosition(x, y, 0);
                node.parent = this.mapRoot;
                this.setClickEvent(node, conn.split('(')[0]);

                // Draw connection line
                this.drawLine(centerNode.position, node.position);
            }
        });
    }

    drawLine(startPos: Vec3, endPos: Vec3) {
        const controlPoint1 = new Vec3((startPos.x + endPos.x) / 2, startPos.y, 0);
        const controlPoint2 = new Vec3((startPos.x + endPos.x) / 2, endPos.y, 0);

        this.graphics.moveTo(startPos.x, startPos.y);
        this.graphics.bezierCurveTo(controlPoint1.x, controlPoint1.y, controlPoint2.x, controlPoint2.y, endPos.x, endPos.y);
        this.graphics.strokeColor = new Color(255, 255, 255, 255); // White color
        this.graphics.lineWidth = 9;
        this.graphics.stroke();

        this.graphics.moveTo(startPos.x, startPos.y);
        this.graphics.bezierCurveTo(controlPoint1.x, controlPoint1.y, controlPoint2.x, controlPoint2.y, endPos.x, endPos.y);
        this.graphics.strokeColor = new Color(155, 255, 155, 255); // White color
        this.graphics.lineWidth = 5;
        this.graphics.stroke();
    }

    setClickEvent(node: Node, dramaId: string): void {
        node.off('click');
        node.on('click', () => {
            EventManager.instance.emit('DramaEvent', dramaId);
        });
    }
}
