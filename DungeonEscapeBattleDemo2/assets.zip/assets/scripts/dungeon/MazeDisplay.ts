import { _decorator, Component, Node, Sprite, instantiate, resources, SpriteFrame, UITransform, Color } from 'cc';
import { DungeonMaze, Room } from './Dungeon';
const { ccclass, property } = _decorator;

@ccclass('MazeDisplay')
export class MazeDisplay extends Component {
    @property(Node)
    public mazeContainer: Node | null = null;

    @property(SpriteFrame)
    wallSpriteFrame: SpriteFrame | null = null;

    @property(SpriteFrame)
    floorSpriteFrame: SpriteFrame | null = null;

    currX: number = 0;
    currY: number = 0;

    start() {
        // var startX = 2, startY = 0;
        // var dungeon = new Dungeon(5, 5);
        // dungeon.generateMaze(startX, startY);
        // console.log(dungeon.rooms);

        // const exitRoom = dungeon.findExit(startX, startY);
        // console.log('exit:', exitRoom);

        // this.showDungeon(dungeon, startX, startY, exitRoom);
    }

    showDungeon(dungeon: DungeonMaze, currX: number, currY: number, exitRoom: Room) {
        dungeon.rooms.forEach((raw: Room[], y: number) => {
            raw.forEach((room: Room, x: number) => {
                // todo 繪製先這樣，未來再改合適的設計
                const tileSize = 62;
                const tileNode = new Node(`Tile-${x}-${y}`);
                this.mazeContainer!.addChild(tileNode);
                tileNode.setPosition(x * tileSize, y * tileSize); // 假設每個格子大小為32x32像素

                room.instanceNode = tileNode;

                const sprite = tileNode.addComponent(Sprite);
                sprite.spriteFrame = this.floorSpriteFrame!;

                const passgeSize = 24;
                room.connections.forEach((conn) => {
                    const passage = new Node(`Passage-${x}-${y}`);
                    tileNode!.addChild(passage);

                    const sprite = passage.addComponent(Sprite);
                    sprite.spriteFrame = this.wallSpriteFrame!;

                    let pos = [[0, passgeSize], [0, -passgeSize], [passgeSize, 0], [-passgeSize, 0]][conn];
                    passage!.getComponent(UITransform).setContentSize(16, 16);
                    passage.setPosition(pos[0], pos[1]); // 假設每個通道大小為5x5像素
                });
                //
            });
        });

        this.currX = currX;
        this.currY = currY;

        dungeon.rooms.forEach((raw, y) => {
            raw.forEach((room: Room, x) => {
                if (x === currX && y === currY) {
                    room.instanceNode.getComponent(Sprite).color = new Color(0, 255, 0);
                } else if (room == exitRoom) {
                    room.instanceNode.getComponent(Sprite).color = new Color(255, 0, 0);
                }
            });
        });

        this.mazeContainer!.getComponent(UITransform).setContentSize((dungeon.width - 1) * 62, (dungeon.height - 1) * 62);
    }

    movePlayer(dungeon: DungeonMaze, roomX: number, roomY: number) {
        dungeon.rooms.forEach((raw, y) => {
            raw.forEach((room: Room, x) => {
                if (x === this.currX && y === this.currY) {
                    room.instanceNode.getComponent(Sprite).color = new Color(255, 255, 255);
                }
                if (x === roomX && y === roomY) {
                    room.instanceNode.getComponent(Sprite).color = new Color(0, 255, 0);
                }

            });
        });

        this.currX = roomX;
        this.currY = roomY;
    }
}
