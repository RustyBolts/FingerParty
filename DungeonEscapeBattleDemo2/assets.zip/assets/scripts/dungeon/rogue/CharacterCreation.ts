
import { _decorator, Component, randomRangeInt } from 'cc';
import { EventManager } from '../../managers/EventManager';
import { CrosswordType } from '../adventure/DescriptionCrossword';
import { DescriptionScrollView } from '../../tools/DescriptionScrollView';
import { TipCard } from '../../cards/Card';
import { FillBlanks, ReplacedTipCard } from '../../tools/FillBlanks';
import { DataModal } from '../../data/DataModal';
import { Character } from '../Character';
import { BaseAbilities } from '../Ability';
import { ClassFeatureImplementation, rogueFeatures, warriorFeatures } from '../ClassFeatureImplementation';
// import { armorBreastplate, armorChainMail, armorPadded, armorRawhide } from '../item/Armor';
import { UIEvent } from '../../managers/UIManager';
import { CombatControllerEvent } from '../../ui/combat/CombatController';
import { Weapon, WeaponStyle } from '../item/Weapon';
import { InventoryCollection } from '../inventory/InventoryCollection';
const { ccclass, property } = _decorator;

@ccclass('CharacterCreation')
export class CharacterCreation extends Component {

    // @property(Node)
    // copingLayout: Node = null;

    // @property(Node)
    // responseButtonLayout: Node = null!;


    @property(InventoryCollection)
    inventoryCollection: InventoryCollection = null!;

    @property(DescriptionScrollView)
    descriptionScrollView: DescriptionScrollView = null!;

    // private _responseContent: string[] = [];
    private _keepWords: string[] = [];
    private _phaseId: string = '';//暫存下一次文章的linkid，可能因為等待玩家回應所以先暫存
    private _linkId: string = '';
    private _responseId: string = '';//暫存下一次文章的responseid，可能因為等待玩家回應所以先暫存
    private _copingChance: number = 0;
    private _choiceCallback: Function = null;
    private _optionData: any = null;
    characterName: string;
    characterLevel: number = 1;//等級，由dm 決定開始的數字，預設為1
    characterAbilities: BaseAbilities;
    classFeature: ClassFeatureImplementation;
    private _ethnicity = '';

    protected onEnable(): void {
        EventManager.instance.on('DescriptionScrollViewEnd', this.onDescriptionScrollViewEnd, this);
        EventManager.instance.on('DescriptionCrosswordAnswered', this.onDescriptionCrosswordAnswered, this);
    }
    
    protected onDisable(): void {
        EventManager.instance.off('DescriptionScrollViewEnd', this.onDescriptionScrollViewEnd, this);
        EventManager.instance.off('DescriptionCrosswordAnswered', this.onDescriptionCrosswordAnswered, this);
    }

    // 每次滾動到最底的時候會觸發
    private onDescriptionScrollViewEnd(event: any): void {
        console.log('this.data:', this._optionData);
        if (this._optionData.chance === 0) {
            // 沒有進行其他技能檢定，直接結束故事描述捲動
            this.closeDescriptionView();
            return;
        }

        const tipCards: TipCard[] = this.descriptionScrollView.tipCards;
        if (tipCards.length === 0) {
            // 有紀錄新內容，但未切換過去
            if (this._linkId != this._phaseId) {
                this.descriptionScrollView.setChooseButtons([{
                    text: '繼續',
                    callback: () => this.phaseID = this._linkId
                }]);
            } else {
                // 故事描述捲動完畢，結束故事描述
                this.closeDescriptionView();

                // todo 這樣變成強制把tipCard 都回收掉
                // 可以做成暫存string後，最終完成對話，依智力做關鍵字的存檔
            }
        } else {
            this.nextStep(tipCards);
        }
    }

    private onDescriptionCrosswordAnswered(event: { answers: TipCard[], sentence: string }): void {
        const { answers, sentence } = event;
        // todo 這邊的填空可能需要處理 type 的內容，樣本不足之後再調整
        console.log('answers:', answers, 'sentence:', sentence, 'this._responseId:', this._responseId);

        if (this._responseId) {
            const responseContents: string[] = this._optionData.behavior.response[this._responseId];
            this._responseId = '';

            const replaced: ReplacedTipCard[] = FillBlanks.replaceMarkedWithKeywords(responseContents, []);
            replaced.forEach((content: ReplacedTipCard, index: number) => {
                console.log('replaced content:', content);

                // 檢查是否有符合條件的 tip card
                var successs = false;
                content.tipCards.forEach((tipCard: TipCard) => {
                    // 符合除了string 以外的條件
                    if (tipCard.string === '_') {
                        successs = Object.keys(tipCard).every(key => {
                            if (key === 'string') return true;// 不用管string，這個不是推理或問答功能的填題
                            console.log('檢查條件:', key);
                            return answers.some(x => x[key] === tipCard[key]);
                            // return tipCard[key] === answers[index][key];//如果要按照順序的話。但目前應該只需要針對一個答案，最好是能固定一個答案，不然會有問題。
                        });
                    }
                    // 針對相同 string 的條件
                    else {
                        successs = tipCard.string === answers[0].string;
                    }

                    if (successs) {
                        const questionAnswer: string = FillBlanks.answerQuestion(responseContents[index], answers.map(x => x.string));
                        console.log('questionAnswer:', questionAnswer);
                        this.descriptionScrollView.addNewData([sentence, questionAnswer]);
                        // } else {
                        //     console.log('沒有符合條件的 tip card, 取消顯示:', content);
                    }
                });
            });
        } else {
            console.log('沒有後續，用問答題組回應');
            this.descriptionScrollView.addNewData([sentence]);
        }

        this._choiceCallback?.(answers);

        // const { behavior } = this._optionData;//todo 目前沒有說一定會繼續做應對
        // EventManager.instance.emit('CopingDramaBehavior', behavior);
    }

    protected start(): void {
        // this.phaseID = this._linkId = 'classFeature';
    }

    set phaseID(value: string) {
        this._phaseId = this._linkId = value;

        this._optionData = DataModal.getInstance().storyData.options[value];

        if (!this._optionData) {
            console.error(`找不到${value}的資料`);
            return;
        }
        console.log('set linkID:', value, 'data:', this._optionData);

        const { chance, response, descriptions } = this._optionData;

        // 觸發時暫存可以使用技能檢定的次數
        this._copingChance = chance;

        // chance 用完就執行 response 的劇本流程
        // this._responseContent = response;

        // 設定故事描述並顯示
        this.descriptionScrollView.setData(descriptions);
        this.descriptionScrollView.show();
    }

    closeDescriptionView(): void {
        // console.log('closeDescriptionView', this._responseContent);
        // 關閉頁面
        this.descriptionScrollView.setChooseButtons([{
            // text: this._responseContent[0],
            text: '關閉',
            callback: () => {
                // this.copingLayout.active = false;
                this.descriptionScrollView.show(false);

                const character: Character = new Character('char name', 1, this.characterAbilities, this.classFeature);;
                character.ethnicity = this._ethnicity;
                DataModal.getInstance().playerCharacter = character;
                console.log('完成角色建構');

                EventManager.instance.emit('StartStory');

                this.node.active = false;
            }
        }]);
    }

    private setDescriptionCrossword(behavior: any, tipCard: TipCard, conditions: string[]): void {
        const description: string = behavior.choice[tipCard.response];
        const question: ReplacedTipCard = FillBlanks.replaceMarkedWithKeywords([description], [])[0];
        const answer: TipCard[] = this.descriptionScrollView.tipCards;
        EventManager.instance.emit(CrosswordType.SetAnswerQuestion, answer, question.text, question.tipCards, conditions);
    }

    // 創角的選擇，以及後續的callback
    private creationChoiceByType(tipCard: TipCard): void {
        console.log('tipCard:', tipCard);
        switch (tipCard.type) {
            case 'ethnicity':
                this._responseId = tipCard.response;

                // 選種族
                this._choiceCallback = (answers: TipCard[]) => {
                    const tipCard: TipCard = answers[0];// 只能選一個答案
                    this._ethnicity = tipCard.string;

                    this._linkId = 'ability';
                };
                break;

            case 'ability':
                this._responseId = '';//沒有後續說明

                // 選能力
                this._choiceCallback = (answers: TipCard[]) => {
                    var values = [15, 14, 13, 12, 10, 8];
                    const abilityies: Partial<BaseAbilities> = {};
                    answers.forEach(({ coping }) => abilityies[coping] = values.shift());
                    this.characterAbilities = abilityies as BaseAbilities;

                    this._linkId = 'classFeature';
                };
                break;

            case 'classFeature':
                this._responseId = tipCard.response;

                // 選擇職業特色
                this._choiceCallback = (answers: TipCard[]) => {
                    const tipCard: TipCard = answers[0];// 只能選一個答案
                    console.log('選擇', tipCard.string);
                    switch (tipCard.coping) {
                        case 'warrior':
                            this.classFeature = warriorFeatures;
                            break;
                        case 'rogue':
                            this.classFeature = rogueFeatures;
                            break;
                        case 'wizard':
                            break;
                    }

                    // EventManager.instance.emit(UIEvent.BaseAbilitiesShowUI, true);需要characterInfo 才能顯示
                    // EventManager.instance.emit(CombatControllerEvent.SelectCharacter, true);//需要characterInfo 才能顯示

                    DataModal.getInstance().playerCharacter = new Character('warrior', 1, this.characterAbilities, this.classFeature);
                    EventManager.instance.emit(UIEvent.UpdateCharacterInfo);
                    // EventManager.instance.emit(UIEvent.BaseAbilityAllocation, { allocatePoints, baseAbilities });//調整屬性值設定
                };
                break;

            case 'armor':
                this._responseId = tipCard.response;
                console.log('tipCard.response:', tipCard.response);

                // 選防具
                this._choiceCallback = (answers: TipCard[]) => {
                    const tipCard: TipCard = answers[0];// 只能選一個答案
                    console.log('選擇護甲', tipCard.string);

                    // this._linkId = 'weapon';
                };
                break;

            case 'weapon':
                this._responseId = tipCard.response;
                console.log('tipCard.response:', tipCard.response);

                // 選武器
                this._choiceCallback = (answers: TipCard[]) => {
                    const tipCard: TipCard = answers[0];// 只能選一個答案
                    console.log('選擇武器', tipCard.string);
                };
                break;
        }
    }

    nextStep(tipCards: TipCard[]): void {
        const { behavior } = this._optionData;

        var queue: string[] = [];//紀錄做過的動作
        tipCards.forEach((tip) => {
            if (tip.behavior === 'choice') {
                // 創角時的選擇
                this.descriptionScrollView.deleteCard(tip);
                this.setDescriptionCrossword(behavior, tip, ['type']);
                this.creationChoiceByType(tip);
                this.descriptionScrollView.clearTipCards();
                // 問完問題，可以清掉答案卡 todo 也許可以做個什麼紀錄，來方便查清答案卡的管理
                queue.push(`choice ${tip.behavior}`);
            }
            else if (tip.action === 'collect') {
                // 創角時贈與的物品，蒐集此道具的動作
                this.descriptionScrollView.deleteCard(tip);
                this.inventoryCollection.collect(tip);
                const responseContents: string[] = behavior.response[tip.response];
                this.descriptionScrollView.addNewData(responseContents);
                queue.push(`collect: ${tip.string}`);
            }
            // 上面要處理動作，後面再處理response跟link
            else if (tip.response) {
                // 創角時對選擇後的後續說明
                this.descriptionScrollView.deleteCard(tip);
                this._responseId = tip.response;
                const responseContents: string[] = behavior.response[tip.response];
                this.descriptionScrollView.addNewData(responseContents);
                queue.push(`response ${tip.response}`);
            }
            else if (tip.link) {
                // 創角時不同類別的段落，是文章分段顯示的處理，另一方面也讓資料庫看起來不會太雜亂
                this.descriptionScrollView.deleteCard(tip);
                this.descriptionScrollView.setChooseButtons([{
                    text: tip.string,
                    callback: () => this.phaseID = tip.link
                }]);
                queue.push(`link ${tip.link}`);
            }
        });

        console.log('處理的工作:', queue);
    }
    
}