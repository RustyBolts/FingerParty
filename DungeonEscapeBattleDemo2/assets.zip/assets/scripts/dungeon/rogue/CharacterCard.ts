import { _decorator, Component, Node } from 'cc';
import { UIEvent } from '../../managers/UIManager';
import { EventManager } from '../../managers/EventManager';
import { CharacterCreation } from './CharacterCreation';
import { DataModal } from '../../data/DataModal';
import { Character } from '../Character';
const { ccclass, property } = _decorator;

@ccclass('CharacterCard')
export class CharacterCard extends Component {

    @property(Node)
    closeBtn: Node = null;

    @property(CharacterCreation)
    characterCreation: CharacterCreation = null;

    _character: Character = null;

    protected onLoad(): void {
        this._character = DataModal.getInstance().playerCharacter;
        this.closeBtn.active = !!this._character;
    }

    onClicked(): void {

        if (!this.closeBtn.active) {
            // 若沒有存檔時
            this.characterCreation.phaseID = 'ethnicity';
            this.node.active = false;
        } else {

            // 若有存檔時
            // todo 讀檔
        }
    }

    onDeleteClicked(): void {
        // 假设 popupWindow 是 PopupWindowComponent 的一个实例
        EventManager.instance.emit(UIEvent.PopupWindow, '刪除角色', '你確定要刪除這個角色嗎？', [
            { label: '確定', callback: () => console.log("退出游戏") },
            { label: '取消', callback: () => console.log("取消操作") }
        ]);
    }
}