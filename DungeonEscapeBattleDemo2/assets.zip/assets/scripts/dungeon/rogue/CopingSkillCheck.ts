import { _decorator, Component, Label, Node, instantiate, Vec3, randomRangeInt, RichText, Sprite } from 'cc';
import { CounterComponent } from '../../tools/CounterComponent';
import { EventManager } from '../../managers/EventManager';
import { CopingSkillButton } from '../adventure/CopingSkillButton';
import { AdventureSkill } from '../adventure/AdventureSkill';
import { DescriptionScrollView } from '../../tools/DescriptionScrollView';
import { FillBlanks, ReplacedText, ReplacedTipCard } from '../../tools/FillBlanks';
import { TipCard } from '../../cards/Card';
import DescriptionCrossword, { CrosswordType } from '../adventure/DescriptionCrossword';
import { DataModal } from '../../data/DataModal';
import { UIEvent } from '../../managers/UIManager';
const { ccclass, property } = _decorator;

@ccclass('CopingSkillCheck')
export class CopingSkillCheck extends Component {
    @property(CounterComponent)
    counter: CounterComponent = null!;

    @property(Node)
    copingLayout: Node = null;

    @property(CopingSkillButton)
    copingSkillButtonPrefab: CopingSkillButton = null;

    @property(DescriptionScrollView)
    descriptionScrollView: DescriptionScrollView = null!;

    @property(Label)
    titleLabel: Label = null!;

    @property(Node)
    responseButtonLayout: Node = null!;

    @property(DescriptionCrossword)
    descriptionCrossword: DescriptionCrossword = null!;

    @property(Sprite)
    bgSprite: Sprite = null!;

    private _optionsContent: string[] = [];//todo 目前的處理應該有問題的，不是只顯示一句，而是要全掃。結束可能會有多選項
    private _keepWords: string[] = [];
    private _copingChance: number = 0;
    private _responseId: string = '';//暫存下一次文章的linkid，可能因為等待玩家回應所以先暫存
    // private _choiceCallback: Function = null;
    private _hadNewContent: boolean = false;//有新內容，必須執行下一步
    private _isSkillAction: boolean = false;
    private _isWaitingForResponseClick: boolean = false;

    private _data: any;

    protected onLoad(): void {
        // EventManager.instance.on('InitAdventureSkills', this.onInitAdventureSkills, this);
    }

    protected onDestroy(): void {
        // EventManager.instance.off('InitAdventureSkills', this.onInitAdventureSkills, this);
    }

    protected onEnable(): void {
        EventManager.instance.on('DescriptionScrollViewEnd', this.onDescriptionScrollViewEnd, this);
        EventManager.instance.on('DescriptionCrosswordAnswered', this.onDescriptionCrosswordAnswered, this);
        EventManager.instance.on('PerformCopingSkillCheck', this.performCheck, this);
    }

    protected onDisable(): void {
        EventManager.instance.off('DescriptionScrollViewEnd', this.onDescriptionScrollViewEnd, this);
        EventManager.instance.off('DescriptionCrosswordAnswered', this.onDescriptionCrosswordAnswered, this);
        EventManager.instance.off('PerformCopingSkillCheck', this.performCheck, this);
    }

    private onInitAdventureSkills(adventureSkills: AdventureSkill[]): void {
        this.setCopingSkillButtons(adventureSkills);
    }

    // 每次滾動到最底的時候會觸發
    private onDescriptionScrollViewEnd(event: any): void {
        if (this._isWaitingForResponseClick) {
            this.responseButtonLayout.active = true;
            return;
        }
        console.log(this._copingChance, '次, this.data:', this._data);
        console.log('this._hadNewContent:', this._hadNewContent);

        this.nextStep();
    }

    private onDescriptionCrosswordAnswered(event: { answers: TipCard[], sentence: string }): void {
        const { answers, sentence } = event;
        // todo 這邊的填空可能需要處理 type 的內容，樣本不足之後再調整
        console.log('answers:', answers, 'sentence:', sentence);

        const responseContents: string[] = this._data.behavior.response[this._responseId];
        const replaced: ReplacedTipCard[] = FillBlanks.replaceMarkedWithKeywords(responseContents, []);

        replaced.forEach((content: ReplacedTipCard) => {
            console.log('replaced content:', content);

            // 檢查是否有符合條件的 tip card
            var successs = false;
            content.tipCards.forEach((tipCard: TipCard, index: number) => {
                // 符合除了string 以外的條件
                if (tipCard.string === '_') {
                    successs = Object.keys(tipCard).every(key => {
                        if (key === 'string') return true;// 不用管string，這個不是推理或問答功能的填題
                        console.log('檢查條件:', key);
                        return answers.some(x => x[key] === tipCard[key]);
                        // return tipCard[key] === answers[index][key];//如果要按照順序的話。但目前應該只需要針對一個答案，最好是能固定一個答案，不然會有問題。
                    });
                }
                // 針對相同 string 的條件
                else {
                    successs = tipCard.string === answers[0].string;
                }

                if (successs) {
                    var questionAnswers: string[] = [];
                    if (this._isSkillAction) {
                        this._isSkillAction = false;
                        // if (tipCard.string === '_') {
                        // 必須依符合的 string 來顯示可用描述, 把所有句子中有符合 tipCard.string(玩家輸入的那個物件名稱) 來顯示，其他就過濾掉
                        const keywrodsCard: ReplacedTipCard[] = replaced.filter((x) => x.tipCards.some((y) => y.string === tipCard.string));
                        console.log('keywrodsCard:', keywrodsCard);
                        questionAnswers = keywrodsCard.map((x) => x.text);

                        // ...... 這邊硬加 response 的處理，這樣才有辦法把內容硬塞進去，不然目前的流程是沒辦法處理新增的 response 內容
                        keywrodsCard.forEach(x => x.tipCards.forEach(y => y.response && this._data.behavior.response[y.response].forEach(z => questionAnswers.push(z))));
                    } else {
                        questionAnswers = responseContents.map((x) => FillBlanks.answerQuestion(x, answers.map(x => x.string)));
                    }
                    this.descriptionScrollView.addNewData([sentence].concat(questionAnswers));
                    this._hadNewContent = true;
                } else {
                    console.log('沒有符合條件的 tip card, 取消顯示:', content);
                }

            });
        });

        // this._choiceCallback?.(answers);
    }

    start() {
        this.counter.node.active = false;
        this.node.active = false;
    }

    setQuestData(data: any): void {
        this._data = data;
        this._keepWords.length = 0;
        this._hadNewContent = true;

        const { descriptions, options } = data;
        this.descriptionScrollView.setData(descriptions);
        this.descriptionScrollView.show();

        this._copingChance = 0;
        // this._hadNewContent = false;// 處理接任務，目前沒有拒絕的選項，直接跑預設結果

        this._optionsContent = [...options];
    }

    // 劇本描述
    setDramaData(data: any): void {
        this._data = data;
        this._keepWords.length = 0;
        // this._hadNewContent = true;

        console.log('data:', data);

        const { chance, descriptions, options } = data;
        this.descriptionScrollView.setData(descriptions);
        this.descriptionScrollView.show();

        // 觸發時暫存可以使用技能檢定的次數
        this._copingChance = chance;
        // this._hadNewContent = this._copingChance > 0;
        this._hadNewContent = true;

        // chance 用完就執行 response 的劇本流程
        this._optionsContent = [...options];
    }

    setCopingSkillButtons(adventureSkills: AdventureSkill[]): void {
        const layout = this.copingLayout;
        layout.removeAllChildren();

        const prefab = this.copingSkillButtonPrefab.node;
        adventureSkills.forEach(adventureSkill => {
            const entity = instantiate(prefab);
            entity.parent = layout;
            entity.active = true;
            entity.name = adventureSkill.name;
            entity.position = Vec3.ZERO;
            entity.getComponent(CopingSkillButton).setAdventureSkill(adventureSkill);
        });

        layout.active = false;
    }

    // 1. 預設可以顯示responseContent 的內容，不然就是預設的關閉
    // 2. 有response layout 展開時，就不需要顯示1
    // 3. 按下按鈕 (descriptionScrollView.setChooseButtons) 才顯示 responseContent.text
    showResponseContentOrFinish(): void {
        console.log('closeDescriptionView', this._hadNewContent, this._optionsContent);

        if (this.responseButtonLayout.active) {
            console.log('尚未選取應對，需要延後處理');
            // console.log(this._copingChance);
            // if (this._copingChance === 0) this._copingChance = 1;
            this._hadNewContent = true; console.log('把chance增加修改為直接改_responseContent為真值');
            return;
        }

        if (this._optionsContent.length > 0) {
            // 還有新的內容要顯示，不需要跳出預設內容
            if (!this._hadNewContent)
                return;
            this._hadNewContent = false;

            // var needEarlyReturn: boolean = false;

            const buttons: { text: string, callback: Function }[] = [];
            const replaced: ReplacedTipCard[] = FillBlanks.replaceMarkedWithKeywords(this._optionsContent, []);
            replaced.forEach((content: ReplacedTipCard) => {
                console.log('replaced content:', content);
                const { text, tipCards } = content;
                tipCards.forEach((tip: TipCard) => {
                    if (tip.behavior === 'end') {
                        // 結束對話
                        buttons.push({
                            text: tip.string,
                            callback: () => {
                                this.descriptionScrollView.show(false);
                                this.copingLayout.active = false;
                                this.responseButtonLayout.active = false;

                                // 試試，關閉就把背景關掉
                                this.bgSprite.spriteFrame = null;
                            }
                        });
                        // 禁止在end 時下 this.descriptionScrollView.addNewData([text]);
                    }
                    else if (tip.dc) {
                        this.descriptionScrollView.addNewData(replaced.map(x => x.text));//只能用已處理的，未處理會進nextStep然後無限處理
                        // this.checkRoll(this._data.behavior, tip);
                        buttons.push({
                            text: tip.string,
                            callback: () => this.checkRoll(this._data.behavior, tip)
                        });
                        // needEarlyReturn = true;
                    }
                    else if (tip.link) {
                        // link 會重置scrollview 內容，所以需要先推完資料再處理
                        // (如果是dagta.reponse 使用就不要用link，盡量用response)
                        this.descriptionScrollView.addNewData(replaced.map(x => x.text));//只能用已處理的，未處理會進nextStep然後無限處理
                        // this.setChooseOptionsForDrama(tip);
                        // needEarlyReturn = true;
                        // this.descriptionScrollView.clear();
                        buttons.push({
                            text: tip.string,
                            callback: () => this.setDramaData(DataModal.getInstance().storyData.dramas[tip.link])
                        });
                    }
                    else if (tip.response) {
                        console.log('總之走這樣就測到了！');
                        // 內部的對話連結
                        // this.descriptionScrollView.addNewData(this.data.behavior.response[tip.response]);//不能直接顯示，要做成按鈕。上面會被chance=0 擋掉，所以這邊就先處理
                        buttons.push({
                            text: tip.string,
                            callback: () => {
                                // 專門處理 scrollview 中多選項按鈕
                                // data.response 改名叫只能放一句，這樣做的話可以多選，而且選了之後內容也可以顯示正確的對應出來
                                this.descriptionScrollView.addNewData([text].concat(this._data.behavior.response[tip.response]));
                            }
                        });
                        console.log('結束對話，並新增內容');
                        // } else if (tip.link) {
                        //     // 外部的新對話，如果要做新的 coping 處理時使用
                        //     buttons.push({
                        //         text: tip.string,
                        //         callback: () => this.setDramaData(DataModal.getInstance().storyData.dramas[tip.link])
                        //     });
                        //     console.log('結束對話，並建立更新對話連結的按鈕');
                    }
                });
            });

            console.log('buttons:', buttons);
            if (buttons.length > 0) {
                // this.descriptionScrollView.addNewData(replaced.map(x => x.text));
                this.descriptionScrollView.scrollToBottom();
                this.descriptionScrollView.setChooseButtons(buttons);
                return;
            }
        }

        // if (needEarlyReturn)//特規的，給 tip.dc 用
        //     return;

        // 關閉頁面
        this.setScrollviewChooseButtons([{
            text: '關閉',
            callback: () => {
                this.descriptionScrollView.show(false);
            }
        }]);
    }

    private setScrollviewChooseButtons(buttons: { text: string, callback: Function }[]): void {
        this.descriptionScrollView.setChooseButtons(buttons);
        this.copingLayout.active = false;
        this.responseButtonLayout.active = false;
    }

    async performCheck(roll: number, bonus: number, behaviorName: string, copings: any[]): Promise<void> {
        this.counter.node.active = true;

        // roll = 19;//test
        this.counter.count = roll;
        this.counter.counterEffect();
        this.titleLabel.string = behaviorName;

        await new Promise(resolve => { this.scheduleOnce(resolve, 1) });
        this.counter.addCount(bonus, '技能熟練', 20);

        const totoal = roll + bonus;
        // coping: [1, '[逃跑 | coping:survival]吧！不斷有更多的黑死屍緩緩地爬起，思緒混亂的你心裡這麼想著。', 'describe'],
        const copingList = copings.filter((x) => x[0] <= totoal);

        // // 扣掉chance 的次數，如果次數用光了，就直接執行 response 動作
        // if (this._copingChance === 0) {
        //     this.describeFinal();

        //     return;
        // }
        this._copingChance--;

        console.log('copingList:', copingList);
        this.setCopingDescription(copingList);
    }

    setCopingDescription(copingList): void {
        const responseButtons = this.responseButtonLayout.children;
        responseButtons.forEach((button) => {
            button.off('click');
            button.active = false;
        });

        var tips: TipCard[] = [];
        var temps: { [key: string]: Node } = {};
        var index: number = 0;
        copingList.forEach((coping) => {
            const [rollCheck, content, implement, responseId] = coping;
            // 從content 中提取提示答案卡
            // todo  這邊為什麼是用 _responseContent 而不是 content???
            console.log(implement, 'content:', content);
            console.log('this._responseContent:', this._optionsContent);

            switch (implement) {
                case 'describe':// event.name；原本想做成另外的點擊，但技能的顯示會變得比較雜亂，所以現在只當作提示
                    this.descriptionScrollView.addNewData(content);
                    this._hadNewContent = true;
                    break;
                case 'response':
                    // this.responseButtonLayout.active = this.descriptionScrollView.isBottom;
                    // this.copingLayout.active = false;
                    // this.descriptionScrollView.hideButtonLayout();
                    // this.descriptionScrollView.scrollToBottom();

                    // this._isWaitingForResponseClick = true;

                    console.log('response content:', content);

                    this.setResponseOption(responseButtons[index] || instantiate(responseButtons[0]), content, () => {
                        this.descriptionScrollView.addNewData(this._data.behavior.response[responseId]);
                        // this._hadNewContent = true;

                        // this._isWaitingForResponseClick = false;
                        // this.responseButtonLayout.active = false;
                    });
                    index++;
                    break;
                case 'action to target':
                    // this.responseButtonLayout.active = this.descriptionScrollView.isBottom;
                    // this.copingLayout.active = false;
                    // this.descriptionScrollView.hideButtonLayout();
                    // this.descriptionScrollView.scrollToBottom();

                    // this._isWaitingForResponseClick = true;

                    const question: ReplacedTipCard = FillBlanks.replaceMarkedWithKeywords([content], [])[0];

                    // 這個是為了暫存之後看有沒有重複的問題 todo 看可以優化一下
                    tips.push(...question.tipCards);
                    var keyStr: string[] = [];
                    // 若為真，question.tipCards 的卡片已經被創建過了，後面就要做取代
                    const successs = Object.keys(tips).every(key => {
                        if (key === 'string') return true;// 不用管string，這個不是推理或問答功能的填題
                        console.log('檢查條件:', key);
                        const bool = question.tipCards.some(x => x[key] === tips[key]);
                        if (bool) keyStr.push(tips[key]);//所有條件都當作是key，用來判斷是否重複的問題
                        return bool;
                    });
                    console.log('是否重複:::::', successs);
                    let key = keyStr.sort().join('');
                    let entity = temps[key] || responseButtons[index] || instantiate(responseButtons[0]);
                    this.setResponseOption(entity, question.text, () => {
                        const answer = this.descriptionScrollView.tipCards;
                        EventManager.instance.emit(CrosswordType.SetAnswerQuestion, answer, question.text, question.tipCards, ['type']);
                        // 答題後，會影響結果
                        this._responseId = responseId;//用這個方法，而不是 _responseContent ，就不會影響最終結果；但可以的話改新方法，要能夠直接把新的response 當作其中一個選項放進去
                        console.log('this._responseId:', this._responseId);

                        console.log('question.tipCards:', question.tipCards);

                        // this._hadNewContent = true;// todo 檢查，為什麼其他人都有，這邊不用？
                        // this._isWaitingForResponseClick = false;
                        // this.responseButtonLayout.active = false;

                        // this._choiceCallback = ()=>{
                        //     //todo 應該不止這邊，還是要想辦法descriptionScrollview 那邊要有專門解qa 並存tipCard 的
                        //     this.nextStep();
                        // }

                    });
                    temps[key] = entity;
                    if (!successs) {
                        console.log('不重複，index 繼續增加');
                        index++;
                    }

                    this._isSkillAction = true;//  必須依符合的 tip.string 來顯示可用描述 todo 變數名稱可以再改一下
                    break;
            }
        });
    }

    private setResponseOption(entity: Node, text: string, callback: Function): void {
        entity.parent = this.responseButtonLayout;
        entity.active = true;
        entity.getComponentInChildren(RichText).string = text;
        entity.off('click');
        entity.on('click', () => {
            this._hadNewContent = true;

            this._isWaitingForResponseClick = false;
            this.responseButtonLayout.active = false;

            callback();
        });

        this._isWaitingForResponseClick = true;
        this.responseButtonLayout.active = this.descriptionScrollView.isBottom;
        this.copingLayout.active = false;
        this.descriptionScrollView.hideButtonLayout();
        this.descriptionScrollView.scrollToBottom();
    }

    private combat(behavior: any, tipCard: TipCard): void {
        this.descriptionScrollView.deleteCard(tipCard);
        this._hadNewContent = false;//暫時不顯示新內容，讓scrollview按鈕不要出來
        this._copingChance = 0;// 進戰鬥就代表另一個結果，所以不能再繼續嘗試 coping 了，要的話就是另開新對話
        this.setScrollviewChooseButtons([{
            text: '戰鬥',
            callback: () => {
                // 先佈置內容，等戰鬥結束後繼續故事描述
                if (tipCard.response) {
                    // 我想，戰鬥會影響後續的決定，而不能繼續用舊的 responseContent
                    this._optionsContent = [...behavior.response[tipCard.response]];
                    // this.descriptionScrollView.addNewData(this._responseContent);
                    this._hadNewContent = true;
                    // } else {
                }
                this.showResponseContentOrFinish();

                this.descriptionScrollView.hide();
                const enemyName = tipCard.coping;
                EventManager.instance.emit('battleStart', enemyName);
                EventManager.instance.emit(UIEvent.MapConnectionShowUI, false);
            }
        }, {
            text: '-10hp跳過戰鬥',
            callback: () => {
                EventManager.instance.emit('UnderAttackDamage', 10);

                if (tipCard.response) {
                    // 我想，戰鬥會影響後續的決定，而不能繼續用舊的 responseContent
                    this._optionsContent = [...behavior.response[tipCard.response]];

                    const descriptions: string[] = ['一場激烈的戰鬥後，你受到10點傷害。'];
                    // descriptions.push(...this._responseContent);
                    this.descriptionScrollView.addNewData(descriptions);
                    this._hadNewContent = true;
                    // ===> 因為 copingChance 強制為0 的關係，所以addNewData 讓 scrollEnd 直接跑 nextStep, 流程下會直接進 showResponseContentOrFinish
                    // } else {
                }
                // this.showResponseContentOrFinish(); 呃…多這行會有像"bispe1335"這邊的描述，讓"dogefail"跑不出"finalfight"的句子，所以先註解掉
            }
        }]);
    }

    private checkRoll(behavior: any, tipCard: TipCard): void {
        let split = tipCard.dc.split('-');
        let value = parseInt(split[0]);
        let ability = split[1];
        let successId = tipCard.success;
        let failureId = tipCard.failure;

        console.log(value, ability, successId, failureId);
        console.log(behavior.response[successId]);
        console.log(behavior.response[failureId]);

        const character = DataModal.getInstance().playerCharacter;
        const bonus = character.calculateProficienciesBonus()[ability];
        const roll = 1;//randomRangeInt(1, 20) + bonus;
        var descriptions: string[] = [];
        descriptions.push(`(骰子結果：${roll})`);
        roll >= value
            ? descriptions.push(...behavior.response[successId])
            : descriptions.push(...behavior.response[failureId]);
        this.descriptionScrollView.addNewData(descriptions);
        this.descriptionScrollView.deleteCard(tipCard);
        this._hadNewContent = true;
        console.log('checkRoll descriptions:', descriptions);
    }

    private setChooseOptionsForDrama(tipCard: TipCard): void {
        this.descriptionScrollView.clear();// 新對話，先清掉再說
        console.log('setChooseOptionsForDrama:', tipCard.link);
        // this.descriptionScrollView.setChooseButtons([{
        this.setScrollviewChooseButtons([{
            text: tipCard.string,
            callback: () => this.setDramaData(DataModal.getInstance().storyData.dramas[tipCard.link])
        }]);
        // this.descriptionScrollView.deleteCard(tipCard);//關閉時會自動清掉 new 但如果前面的流程沒有關閉就不會清
    }

    // 從蒐集來的tipCard 驅動，並且每次使用卡片就會消失
    nextStep(): void {
        const { behavior } = this._data;
        var needCoping = !!behavior?.coping && this._copingChance > 0;

        var queue: string[] = [];//紀錄做過的動作
        this.descriptionScrollView.tipCards.forEach((tip: TipCard) => {
            if (tip.behavior === 'end') {
                needCoping = false;
                // 結束對話
                // this.descriptionScrollView.setChooseButtons([{
                this.setScrollviewChooseButtons([{
                    text: tip.string,
                    callback: () => {
                        this.descriptionScrollView.show(false);
                        // 試試，關閉就把背景關掉
                        this.bgSprite.spriteFrame = null;
                    }
                }]);
                queue.push(`end ${tip.string}`);
            }
            else if (tip.action === 'combat') {
                needCoping = false;
                this.combat(behavior, tip);
                queue.push(`combat ${tip.string}`);
            }
            else if (tip.action === 'damage') {
                needCoping = false;
                this.descriptionScrollView.deleteCard(tip);
                console.log('受傷:', tip.value);//todo，最後chance 會造成不會進入這個流程，所以其他也要確認一下是不是要拉上去，或做點什麼事
                EventManager.instance.emit('UnderAttackDamage', parseInt(tip.value, 10));
                console.log('tip:', tip);

                if (tip.response) {
                    this.descriptionScrollView.addNewData(behavior.response[tip.response]);
                    this._hadNewContent = true;
                }
                queue.push(`damage ${tip.string}`);
            }
            else if (tip.dc) {
                needCoping = false;
                this.setScrollviewChooseButtons([{
                    text: tip.string,
                    callback: () => this.checkRoll(behavior, tip)
                }])
                // this.checkRoll(behavior, tip);
                queue.push(`check roll ${tip.string}`);
            }
            else if (tip.link) {
                needCoping = false;
                this.setChooseOptionsForDrama(tip);
                queue.push(`link ${tip.link}`);
            }
        });
        console.log('處理的工作:', queue);
        console.log('needEmit:', needCoping, ':::: hadNewContent:', this._hadNewContent);

        this.counter.node.active = this.copingLayout.active = needCoping;

        // 捲完後，把可用的應對(coping)傳給匹配的按鈕顯示
        needCoping && EventManager.instance.emit('CopingDramaBehavior', behavior.coping);// 如果有互動機會時跳出互動的按鈕

        // nextStep 的內容一定要先跑完才能跑 showResponseContentOrFinish
        this.showResponseContentOrFinish();// 可以跳過互動直接結束
    }

    isTipOpened: boolean = false;
    onShowTipClicked(): void {
        if (this.isTipOpened) {
            this.descriptionCrossword.closeAnswer();
        } else {
            this.descriptionCrossword.setAnswer(this.descriptionScrollView.tipCards);
        }
        this.isTipOpened = !this.isTipOpened;
    }
}