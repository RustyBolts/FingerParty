import { _decorator, Component, Node } from 'cc';
import { UIEvent } from '../../managers/UIManager';
import { EventManager } from '../../managers/EventManager';
import { CharacterCreation } from './CharacterCreation';
import { DataModal } from '../../data/DataModal';
import { Character } from '../Character';
import { MapConnection } from '../adventure/MapConnection';
const { ccclass, property } = _decorator;

@ccclass('StoryCard')
export class StoryCard extends Component {

    @property(MapConnection)
    mapConnection: MapConnection = null;

    protected onLoad(): void {
    }

    onClicked(): void {
        // this.mapConnection.sample();
        EventManager.instance.emit('QuestAccept', 'kuai_kuai_cat1');
        this.node.active = false;
    }

}