import { _decorator, Component, Node, Vec3, tween, Sprite, Label, SpriteFrame, resources, assetManager, Tween, Button } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('NetworkGraph')
export class NetworkGraph extends Component {
    @property(Node)
    positionLayer: Node = null;

    @property(Node)
    displayLayer: Node = null;

    // start() {
    //     let baseNodeName = 'creation2';
    //     this.createInitialNode(baseNodeName, 'Start');

    //     this.scheduleOnce(() => this.addNode(baseNodeName, 180, 0, 'creation1', 'Node 1'), 1);
    //     this.scheduleOnce(() => this.addNode(baseNodeName, -180, 0, 'creation', 'Node 2'), 2);
    // }

    createInitialNode(iconName: string, labelText: string, callback: Function = null) {
        let initialNode = new Node(iconName);
        initialNode.setPosition(new Vec3(0, 0, 0));
        this.positionLayer.addChild(initialNode);

        this.createDisplayNode(initialNode, iconName, labelText, callback);
    }

    addNode(relatedNodeName, offsetX, offsetY, iconName, labelText, callback: Function = null) {
        let relatedNode = this.positionLayer.getChildByName(relatedNodeName);
        if (!relatedNode) {
            console.error('Related node not found');
            return;
        }

        let newNode = new Node('NewNode');// TODO: Generate unique name
        newNode.setPosition(new Vec3(relatedNode.position.x + offsetX, relatedNode.position.y + offsetY, 0));
        this.positionLayer.addChild(newNode);

        // this.positionNodes();
        this.createDisplayNode(newNode, iconName, labelText, callback);
    }

    createDisplayNode(baseNode, iconName, labelText, callback: Function) {
        let displayNode = new Node('DisplayNode');
        this.displayLayer.addChild(displayNode);
        displayNode.setPosition(new Vec3(baseNode.position.x, baseNode.position.y, 0));

        displayNode.addComponent(Button);
        displayNode.on('click', () => {
            console.log('Touch start on ' + iconName);
            callback?.(iconName);
        });

        // Load and set the sprite
        const sprite = displayNode.addComponent(Sprite);
        const imagePath = `maps/${iconName}/spriteFrame`;
        resources.load(imagePath, SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error('Failed to load image: ' + err);
                return;
            }
            sprite.spriteFrame = spriteFrame;
        });

        // Add a label
        let labelNode = new Node('LabelNode');
        labelNode.parent = displayNode;
        labelNode.setPosition(new Vec3(0, 0, 0));
        let label = labelNode.addComponent(Label);
        label.string = labelText;
        label.fontSize = 24;  // Example font size

        // 添加縮放動畫
        tween(displayNode)
            .stop()
            .to(0.25, { scale: new Vec3(1, 1, 1) })
            .start();
    }

    positionNodes() {
        let nodes = this.positionLayer.children;

        for (let i = 0; i < nodes.length; i++) {
            for (let j = i + 1; j < nodes.length; j++) {
                let distance = nodes[i].position.subtract(nodes[j].position).length();
                if (distance < 100) { // 100 pixels as default minimum spacing
                    let pushDistance = 100 - distance;
                    let direction = nodes[j].position.subtract(nodes[i].position).normalize();
                    let newPosition = nodes[j].position.add(direction.multiplyScalar(pushDistance));
                    nodes[j].setPosition(newPosition);

                    let displayNode = this.displayLayer.getChildByName(nodes[j].name.replace('Node', 'DisplayNode'));
                    // Tween.stopAllByTarget(displayNode);
                    tween(displayNode)
                        .to(0.25, { position: newPosition })
                        .start();
                }
            }
        }
    }

    removeNode(nodeName: string) {
        let positionNode = this.positionLayer.getChildByName(nodeName);
        if (!positionNode) {
            console.error('Node not found');
            return;
        }

        let displayNode = this.displayLayer.getChildByName(nodeName.replace('Node', 'DisplayNode'));
        if (!displayNode) {
            console.error('Display node not found');
            return;
        }

        displayNode.destroy();
        positionNode.destroy();
        // this.positionNodes();
    }

    removeAllNodes() {
        this.positionLayer.children.forEach(node => node.destroy());
        this.displayLayer.children.forEach(node => node.destroy());
        // this.positionNodes();
    }
}
