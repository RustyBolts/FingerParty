import { Attribute } from './Ability';
import { Adventure } from './adventure/AdventureSkill';
import { Armor, ArmorStyle } from './item/Armor';
import { WeaponStyle } from './item/Weapon';

const LightArmors = [
    ArmorStyle.Padded,
    ArmorStyle.Leather,
    ArmorStyle.StuddedLeather
];
const MediumArmors = [
    ArmorStyle.Hide,
    ArmorStyle.ChainShirt,
    ArmorStyle.ScaleMail,
    ArmorStyle.Breastplate,
    ArmorStyle.HalfPlate
];
const HeavyArmors = [
    ArmorStyle.RingMail,
    ArmorStyle.ChainMail,
    ArmorStyle.Splint,
    ArmorStyle.Plate
];
const SimpleWeapons = [
    WeaponStyle.Club,
    WeaponStyle.Dagger,
    WeaponStyle.Greatclub,
    WeaponStyle.Handaxe,
    WeaponStyle.Javelin,
    WeaponStyle.LightHammer,
    WeaponStyle.Mace,
    WeaponStyle.Quarterstaff,
    WeaponStyle.Sickle,
    WeaponStyle.Spear,

    WeaponStyle.LightCrossbow,
    WeaponStyle.Dart,
    WeaponStyle.Shortbow,
    WeaponStyle.Sling
];
const MartialWeapons = [
    WeaponStyle.Battleaxe,
    WeaponStyle.Flail,
    WeaponStyle.Glaive,
    WeaponStyle.Greataxe,
    WeaponStyle.Greatsword,
    WeaponStyle.Halberd,
    WeaponStyle.Lance,
    WeaponStyle.Longsword,
    WeaponStyle.Maul,
    WeaponStyle.Morningstar,
    WeaponStyle.Pike,
    WeaponStyle.Rapier,
    WeaponStyle.Scimitar,
    WeaponStyle.ShortSword,
    WeaponStyle.Trident,
    WeaponStyle.WarPick,
    WeaponStyle.Warhammer,
    WeaponStyle.Whip,

    WeaponStyle.Blowgun,
    WeaponStyle.HandCrossbow,
    WeaponStyle.HeavyCrossbow,
    WeaponStyle.Longbow,
    WeaponStyle.Net
];

class ClassFeatureImplementation {
    primaryAttribute: Attribute = null;         // 主属性
    savingThrowProficiencies: Attribute[] = []; // 豁免熟練
    armorProficiencies: ArmorStyle[] = [];      // 護甲熟練
    weaponProficiencies: WeaponStyle[] = [];    // 武器熟練
    adventureProficiencies: Adventure[] = [];      // 冒险技能熟練項 (大於2項即可選擇但未完成選定)
    additionalFeatures: string[] = [];

    constructor(
        primaryAttribute: Attribute,
        savingThrowProficiencies: Attribute[],
        armorProficiencies: ArmorStyle[],
        weaponProficiencies: WeaponStyle[],
        adventureSkills: Adventure[],
        additionalFeatures: string[],
    ) {
        this.primaryAttribute = primaryAttribute;
        this.savingThrowProficiencies = savingThrowProficiencies;
        armorProficiencies.forEach((af) => {
            if (af === ArmorStyle.AllLightArmors) {
                this.armorProficiencies.concat(LightArmors);
            } else if (af === ArmorStyle.AllMediumArmors) {
                this.armorProficiencies.concat(MediumArmors);
            } else if (af === ArmorStyle.AllHeavyArmors) {
                this.armorProficiencies.concat(HeavyArmors);
            } else {
                this.armorProficiencies.push(af);
            }
        });
        weaponProficiencies.forEach((wp) => {
            if (wp === WeaponStyle.AllSimpleWeapons) {
                this.weaponProficiencies = this.weaponProficiencies.concat(SimpleWeapons);
            } else if (wp === WeaponStyle.AllMartialWeapons) {
                this.weaponProficiencies = this.weaponProficiencies.concat(MartialWeapons);
            } else {
                this.weaponProficiencies.push(wp);
            }
        });
        this.additionalFeatures = additionalFeatures;
    }
}

// 创建战士的职业特性
const warriorFeatures = new ClassFeatureImplementation(
    Attribute.Strength, // 主属性 力量
    // Attribute.Dexterity, // 或 主属性 敏捷
    [Attribute.Strength, Attribute.Resilience], // 豁免熟练项 力量 & 韌性
    [ArmorStyle.AllLightArmors, ArmorStyle.AllMediumArmors, ArmorStyle.AllHeavyArmors], // 護甲熟练项 所有护甲
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.AllMartialWeapons], // 武器熟练项 简易武器和军用武器
    [Adventure.Stunts, Adventure.Taming, Adventure.Experience, Adventure.Awareness, Adventure.Intimidation, Adventure.Survival],
    ['Combat versatility', 'Second wind'] // 额外的职业特性能力
);

// 创建遊盪者的职业特性
const rogueFeatures = new ClassFeatureImplementation(
    Attribute.Dexterity, // 主属性 敏捷
    [Attribute.Dexterity, Attribute.Intelligence], // 豁免熟练项 敏捷 & 智力
    [ArmorStyle.AllLightArmors], // 護甲熟练项 輕甲
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.HandCrossbow, WeaponStyle.Longsword, WeaponStyle.ShortSword, WeaponStyle.Rapier], // 武器熟练项 簡易武器，手弩，長劍，刺劍，短劍
    [Adventure.Stunts, Adventure.Persuasion, Adventure.Awareness, Adventure.Explore, Adventure.Performance, Adventure.Dexterity, Adventure.Stealth],
    ['Expertise', 'Sneak attack', 'Thieves\' cant'] // 额外的职业特性能力
);

// 武器： 簡易武器, 手弩, 長劍, 細劍, 短劍
// 工具： 三種你所選擇的樂器
// 技能： 選擇任意三個技能。
const bardFeatures = new ClassFeatureImplementation(
    Attribute.Charisma, // 主属性 魅力
    [Attribute.Charisma, Attribute.Dexterity], // 豁免熟练项 魅力 & 敏捷
    [ArmorStyle.AllLightArmors], // 護甲熟练项 輕甲或中甲
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.Dagger, WeaponStyle.Dart, WeaponStyle.Shortbow, WeaponStyle.ShortSword, WeaponStyle.Flail, WeaponStyle.Greataxe, WeaponStyle.Greatsword, WeaponStyle.Scimitar, WeaponStyle.Warhammer, WeaponStyle.Whip], // 武器熟练项 簡易武器，匕首，短弓，匕首，短劍，斧，大斧，大劍，短刀，長槍，巨斧，鞭笞
    [Adventure.Stunts, Adventure.Stealth, Adventure.Dexterity, Adventure.Knowledge, Adventure.Experience, Adventure.Nature, Adventure.Religion, Adventure.Explore, Adventure.Nursing, Adventure.Awareness, Adventure.Taming, Adventure.Survival, Adventure.Observation, Adventure.Performance, Adventure.Persuasion, Adventure.Intimidation],
    ['Bardic Inspiration', 'Song of Rest', 'Spellcasting'] // 额外的职业特性能力    
);

// 工具： 無
const warlockFeatures = new ClassFeatureImplementation(
    Attribute.Charisma, // 主属性 魅力
    [Attribute.Charisma, Attribute.Wisdom], // 豁免熟練 魅力 & 睿知
    [ArmorStyle.AllLightArmors], // 護甲熟練 輕甲或中甲
    [WeaponStyle.AllSimpleWeapons], // 武器熟練 簡易武器
    [Adventure.Knowledge, Adventure.Persuasion, Adventure.Experience, Adventure.Intimidation, Adventure.Explore, Adventure.Nature, Adventure.Religion],//從奧秘, 欺瞞, 歷史, 威嚇, 調查, 自然, 和 宗教 中選擇二個。
    ['Eldritch Blast', 'Pact Magic', 'Shadow Magic'] // 额外的职业特性能力    
);

// 護甲： 輕甲, 中甲, 盾牌（德魯伊不能穿戴或使用金屬製成的護甲和盾牌）
// 武器： 棍棒, 匕首, 飛鏢, 標槍, 硬頭錘, 長棍, 彎刀, 鐮刀, 投石索, 矛
// 工具： 藥草師工具組
const druidFeatures = new ClassFeatureImplementation(
    Attribute.Wisdom, // 主属性 智力
    [Attribute.Intelligence, Attribute.Wisdom], // 豁免熟練 智力 & 睿知
    [ArmorStyle.AllLightArmors, ArmorStyle.AllMediumArmors], // 護甲熟練 
    [WeaponStyle.Club],
    [Adventure.Knowledge, Adventure.Taming, Adventure.Observation, Adventure.Nursing, Adventure.Nature, Adventure.Awareness, Adventure.Religion, Adventure.Survival],//從奧秘, 動物馴養, 察言觀色, 醫藥, 自然, 感知, 宗教, 和 求生 中選擇二個。
    []
);

// 工具： 一種你所選擇的工匠工具 或 一種你所選擇的樂器
const monkFeatures = new ClassFeatureImplementation(
    Attribute.Strength, // 主属性 力量
    [Attribute.Strength, Attribute.Dexterity], // 豁免熟練 力量 & 敏捷
    [], // 護甲熟練 無
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.ShortSword], // 武器熟練 簡易武器，短劍
    [Adventure.Stunts, Adventure.Experience, Adventure.Experience, Adventure.Observation, Adventure.Religion, Adventure.Stealth],//從特技, 運動, 歷史, 察言觀色, 宗教, 和 隱匿 中選擇二個。
    ['Unarmored Defense', 'Martial Arts', 'Deflect Missiles'] // 额外的职业特性能力    
);

// 武器： 匕首, 飛鏢, 投石索, 長棍, 輕弩
// 工具： 無
const wizardFeatures = new ClassFeatureImplementation(
    Attribute.Intelligence, // 主属性 智力
    [Attribute.Intelligence, Attribute.Wisdom], // 豁免熟練 智力 & 智力
    [], // 護甲熟練 無
    [WeaponStyle.Dagger, WeaponStyle.Dart, WeaponStyle.Shortbow, WeaponStyle.ShortSword, WeaponStyle.Flail, WeaponStyle.Greataxe, WeaponStyle.Greatsword, WeaponStyle.Scimitar, WeaponStyle.Warhammer, WeaponStyle.Whip], // 武器熟練 簡易武器，匕首，短弓，匕首，短劍，斧，大斧，大劍，短刀，長槍，巨斧，鞭笞
    [Adventure.Knowledge, Adventure.Experience, Adventure.Observation, Adventure.Explore, Adventure.Nursing, Adventure.Religion],//從奧秘, 歷史, 察言觀色, 調查, 醫藥, 和 宗教 中選擇二個。
    ['Arcane Recovery', 'Arcane Tradition', 'Spell Mastery'] // 额外的职业特性能力    
);

// 護甲： 輕甲, 中甲, 盾牌
// 工具： 無
const clericFeatures = new ClassFeatureImplementation(
    Attribute.Wisdom, // 主属性 睿知
    [Attribute.Wisdom, Attribute.Charisma], // 豁免熟練 睿知 & 魅力
    [ArmorStyle.AllLightArmors, ArmorStyle.AllMediumArmors], // 護甲熟練
    [WeaponStyle.AllSimpleWeapons], // 武器熟練 簡易武器
    [Adventure.Experience, Adventure.Observation, Adventure.Nursing, Adventure.Performance, Adventure.Religion],//從歷史, 察言觀色, 醫藥, 說服, 和 宗教 中選擇二個。
    ['Divine Intervention', 'Lay on Hands', 'Sacred Weapon'] // 额外的职业特性能力    
);

// 護甲： 輕甲, 中甲, 重甲, 盾牌
// 工具： 無
const paladinFeatures = new ClassFeatureImplementation(
    Attribute.Charisma, // 主属性 魅力
    [Attribute.Charisma, Attribute.Wisdom], // 豁免熟練 魅力 & 智力
    [ArmorStyle.AllLightArmors, ArmorStyle.AllMediumArmors, ArmorStyle.AllHeavyArmors], // 護甲熟練 簡易武器, 軍用武器
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.Dagger, WeaponStyle.Dart, WeaponStyle.Shortbow, WeaponStyle.ShortSword, WeaponStyle.Flail, WeaponStyle.Greataxe, WeaponStyle.Greatsword, WeaponStyle.Scimitar, WeaponStyle.Warhammer, WeaponStyle.Whip], // 武器熟練 簡易武器，匕首，短弓，匕首，短劍，斧，大斧，大劍，短刀，長槍，巨斧，鞭笞
    [Adventure.Stunts, Adventure.Observation, Adventure.Intimidation, Adventure.Nursing, Adventure.Persuasion, Adventure.Religion],//從運動, 察言觀色, 威嚇, 醫藥, 說服, 和 宗教 中選擇二個。
    ['Divine Sense', 'Lay on Hands', 'Divine Smite'] // 额外的职业特性能力    
);

// 武器： 匕首, 飛鏢, 投石索, 長棍, 輕弩
// 工具： 無
const sorcererFeatures = new ClassFeatureImplementation(
    Attribute.Charisma, // 主属性 魅力
    [Attribute.Charisma, Attribute.Resilience], // 豁免熟練 魅力 & 韌性
    [], // 護甲熟練 無
    [WeaponStyle.Dagger, WeaponStyle.Dart, WeaponStyle.Shortbow, WeaponStyle.ShortSword, WeaponStyle.Flail, WeaponStyle.Greataxe, WeaponStyle.Greatsword, WeaponStyle.Scimitar, WeaponStyle.Warhammer, WeaponStyle.Whip], // 武器熟練 簡易武器，匕首，短弓，匕首，短劍，斧，大斧，大劍，短刀，長槍，巨斧，鞭笞
    [Adventure.Knowledge, Adventure.Persuasion, Adventure.Observation, Adventure.Intimidation, Adventure.Religion],//從奧秘, 欺瞞, 察言觀色, 威嚇, 說服, 和 宗教 中選擇二個。
    ['Sorcerous Origin', 'Sorcerous Inspiration', 'Sorcerous Defense'] // 额外的职业特性能力    
);

// 護甲： 輕甲, 中甲, 盾牌
// 工具： 無
const rangerFeatures = new ClassFeatureImplementation(
    Attribute.Dexterity, // 主属性 敏捷
    [Attribute.Dexterity, Attribute.Strength], // 豁免熟練 力量, 敏捷
    [ArmorStyle.AllLightArmors, ArmorStyle.AllMediumArmors], // 護甲熟練 
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.AllMartialWeapons], // 武器熟練 簡易武器, 軍用武器
    [Adventure.Taming, Adventure.Stunts, Adventure.Observation, Adventure.Explore, Adventure.Nature, Adventure.Dexterity, Adventure.Stealth, Adventure.Survival],//從動物馴養, 運動, 察言觀色, 調查, 自然, 感知, 隱匿, 和 求生 中選擇三個。
    ['Feral Instinct', 'Natural Explorer', 'Primal Path'] // 额外的职业特性能力    
);

// 護甲： 輕甲, 中甲, 盾牌
// 工具： 無
const barbarianFeatures = new ClassFeatureImplementation(
    Attribute.Strength, // 主属性 力量
    [Attribute.Strength, Attribute.Resilience], // 豁免熟練 力量 & 韌性
    [ArmorStyle.AllLightArmors, ArmorStyle.AllMediumArmors], // 護甲熟練 所有护甲
    [WeaponStyle.AllSimpleWeapons, WeaponStyle.AllMartialWeapons], // 武器熟練 簡易武器, 軍用武器
    [Adventure.Taming, Adventure.Stunts, Adventure.Intimidation, Adventure.Nature, Adventure.Awareness, Adventure.Survival],//從動物馴養, 運動, 威嚇, 自然, 感知, 和 求生 中選擇二個。
    ['Rage', 'Unarmored Defense', 'Reckless Attack'] // 额外的职业特性能力    
);

export {
    ClassFeatureImplementation,
    warriorFeatures,
    rogueFeatures,
    bardFeatures,
    warlockFeatures,
    druidFeatures,
    monkFeatures,
    wizardFeatures,
    clericFeatures,
    paladinFeatures,
    sorcererFeatures,
    rangerFeatures,
    barbarianFeatures
}