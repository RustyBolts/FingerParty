import { BaseAbilities, Attribute, CompositeAbilities } from "./Ability";
import { ClassFeatureImplementation } from "./ClassFeatureImplementation";
import { SkillProficiency } from "./Skill";
import { ArmorStyle } from "./item/Armor";
import { WeaponStyle } from "./item/Weapon";

export class Character {
    name: string;
    level: number;                              // 等級
    abilities: BaseAbilities;                   // 基本屬性
    // proficiencyExpertise: number;                // 專業熟練
    // classFeature: ClassFeatureImplementation;   // 職業特色
    primaryAttribute: Attribute = null;         // 主属性
    savingThrowProficiencies: Attribute[] = []; // 豁免熟練
    armorProficiencies: ArmorStyle[] = [];      // 護甲熟練
    weaponProficiencies: WeaponStyle[] = [];    // 武器熟練
    movement: number;                           // 移動速度

    ethnicity: string;                          // 種族

    skills: { [key: string]: SkillProficiency } = {};

    constructor(name: string, level: number, abilities: BaseAbilities, classFeature: ClassFeatureImplementation, movement: number = 30) {
        this.name = name;
        this.level = level;
        this.abilities = abilities;
        this.primaryAttribute = classFeature.primaryAttribute;
        this.savingThrowProficiencies = classFeature.savingThrowProficiencies;
        this.armorProficiencies = classFeature.armorProficiencies;
        this.weaponProficiencies = classFeature.weaponProficiencies;
        this.movement = movement;
    }

    // 計算等級的熟練加值
    public calculateClassProficiencyBonus(): number {
        if (this.level >= 17) return 6;
        if (this.level >= 13) return 5;
        if (this.level >= 9) return 4;
        if (this.level >= 5) return 3;
        return 2;
    }

    // 計算基本能力調整值
    public calculateAbilityScoreModifier(attribute: Attribute): number {
        return Math.floor(this.abilities[attribute] / 2) - 5;
    }

    // 計算所有能力的熟練加值
    public calculateProficienciesBonus(): BaseAbilities {
        // 能力調整值
        const abilityScoreModifier: BaseAbilities = {
            [Attribute.Strength]: this.calculateAbilityScoreModifier(Attribute.Strength),
            [Attribute.Dexterity]: this.calculateAbilityScoreModifier(Attribute.Dexterity),
            [Attribute.Intelligence]: this.calculateAbilityScoreModifier(Attribute.Intelligence),
            [Attribute.Wisdom]: this.calculateAbilityScoreModifier(Attribute.Wisdom),
            [Attribute.Charisma]: this.calculateAbilityScoreModifier(Attribute.Charisma),
            [Attribute.Resilience]: this.calculateAbilityScoreModifier(Attribute.Resilience)
        };

        // 等級熟練加值
        const classProficiencyBonus: number = this.calculateClassProficiencyBonus();

        // 熟練加值
        const proficienciesBonus: BaseAbilities = { ...abilityScoreModifier };

        // 規則為每個職業可選2個熟練加值的能力屬性，加上該熟練的最終熟練加值
        for (let ability of this.savingThrowProficiencies) {
            console.log('豁免:', ability);
            proficienciesBonus[ability] += classProficiencyBonus;
        }

        return proficienciesBonus;
    }

    // 計算各能力屬性對應的綜合屬性
    public calculateCompositeAbilities(): CompositeAbilities {
        const { strength, dexterity, intelligence, wisdom, charisma, resilience } = this.abilities;
        return {
            [Attribute.Constitution]: Math.floor((strength * 2 + dexterity + resilience) / 2) + 10, // 體魄
            [Attribute.Spirit]: Math.floor((intelligence * 2 + wisdom) / 2) + 10,                   // 精神
            [Attribute.Willpower]: Math.floor((resilience * 2 + charisma) / 2) + 10                 // 意志
        };
    }
}