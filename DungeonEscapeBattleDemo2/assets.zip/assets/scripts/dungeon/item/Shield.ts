import { Item } from "./Item";

export class Shield extends Item {
    bonusAC: number;
    iconName: string;

    constructor(name: string, iconName: string, cost: string, weight: number, bonusAC: number) {
        super(name, cost, weight, 1);
        this.iconName = iconName;
        this.bonusAC = bonusAC;
    }
}
