import { Item } from "./Item";

export type DamageType = 'Unarmed' | 'Bludgeoning' | 'Piercing' | 'Slashing';
export type WeaponProperty = 'Light' | 'Finesse' | 'Thrown' | 'Two-Handed' | 'Reach' | 'Heavy' | 'Ammunition' | 'Loading' | 'Special' | 'Versatile';
export type WeaponRange = 'Melee' | 'Reach' | 'Ranged';

export enum WeaponStyle {
    Unarmed = 'Unarmed',

    AllSimpleWeapons = 'AllSimpleWeapons',
    Club = 'Club',
    Dagger = 'Dagger',
    Greatclub = 'Greatclub',
    Handaxe = 'Handaxe',
    Javelin = 'Javelin',
    LightHammer = 'Light Hammer',
    Mace = 'Mace',
    Quarterstaff = 'Quarterstaff',
    Sickle = 'Sickle',
    Spear = 'Spear',

    LightCrossbow = 'Light Crossbow',
    Dart = 'Dart',
    Shortbow = 'Shortbow',
    Sling = 'Sling',

    AllMartialWeapons = 'AllMartialWeapons',
    Battleaxe = 'Battleaxe',
    Flail = 'Flail',
    Glaive = 'Glaive',
    Greataxe = 'Greataxe',
    Greatsword = 'Greatsword',
    Halberd = 'Halberd',
    Lance = 'Lance',
    Longsword = 'Longsword',
    Maul = 'Maul',
    Morningstar = 'Morningstar',
    Pike = 'Pike',
    Rapier = 'Rapier',
    Scimitar = 'Scimitar',
    ShortSword = 'Shortsword',
    Trident = 'Trident',
    WarPick = 'War Pick',
    Warhammer = 'Warhammer',
    Whip = 'Whip',

    Blowgun = 'Blowgun',
    HandCrossbow = 'Hand Crossbow',
    HeavyCrossbow = 'Heavy Crossbow',
    Longbow = 'Longbow',
    Net = 'Net'
}

export interface Damage {
    dice: string;  // 例如 "1d8" 或 "2d6"
    dice2?: string;  // 例如 "1d10"，雙手握持時會有不同傷害
    type: DamageType;
}

export class Weapon extends Item {
    style: WeaponStyle;
    icon: string;                   // 武器的圖示名稱
    damage: Damage;                 // 武器的傷害
    properties: WeaponProperty[];   // 武器的屬性
    range: WeaponRange;             // 武器的射程

    constructor(name: string, cost: string, weight: number, style: WeaponStyle, icon: string, damage: Damage, properties: WeaponProperty[], range: WeaponRange) {
        super(name, cost, weight, 1);

        this.style = style;
        this.icon = icon;
        this.damage = damage;
        this.properties = properties;
        this.range = range;
    }
}

// // 先定義所有武器類別的實例
// const weapons: Weapon[] = [
//     new Weapon('Club', '1 silver', { formula: '1d4', type: 'Bludgeoning' }, 2, ['Light']),
//     new Weapon('Dagger', '2 gold', { formula: '1d4', type: 'Piercing' }, 1, ['Finesse', 'Light', 'Thrown'], '20/60 ft'),
//     new Weapon('Greatclub', '2 silver', { formula: '1d8', type: 'Bludgeoning' }, 10, ['Two-Handed']),
//     new Weapon('Handaxe', '5 gold', { formula: '1d6', type: 'Slashing' }, 2, ['Light', 'Thrown'], '20/60 ft'),
//     new Weapon('Javelin', '5 silver', { formula: '1d6', type: 'Piercing' }, 2, ['Thrown'], '30/120 ft'),
//     new Weapon('Light Hammer', '2 gold', { formula: '1d4', type: 'Bludgeoning' }, 2, ['Light', 'Thrown'], '20/60 ft'),
//     new Weapon('Mace', '5 gold', { formula: '1d6', type: 'Bludgeoning' }, 4, []),
//     new Weapon('Quarterstaff', '2 silver', { formula: '1d6', type: 'Bludgeoning' }, 4, ['Versatile'], '1d8'),//這邊 可雙手 1d8 是雙手持用時的傷害
//     new Weapon('Sickle', '1 gold', { formula: '1d4', type: 'Slashing' }, 2, ['Light']),
//     new Weapon('Spear', '1 gold', { formula: '1d6', type: 'Piercing' }, 3, ['Thrown', 'Versatile'], '20/60 ft, 1d8'),//這邊 可雙手 1d8 是雙手持用時的傷害
//     new Weapon('Light Crossbow', '25 gold', { formula: '1d8', type: 'Piercing' }, 5, ['Ammunition', 'Loading', 'Two-Handed'], '80/320 ft'),
//     new Weapon('Dart', '5 copper', { formula: '1d4', type: 'Piercing' }, 0.25, ['Finesse', 'Thrown'], '20/60 ft'),
//     new Weapon('Shortbow', '25 gold', { formula: '1d6', type: 'Piercing' }, 2, ['Ammunition', 'Two-Handed'], '80/320 ft'),
//     new Weapon('Sling', '1 silver', { formula: '1d4', type: 'Bludgeoning' }, 0, ['Ammunition'], '30/120 ft'),
//     new Weapon('Battleaxe', '10 gold', { formula: '1d8', type: 'Slashing' }, 4, ['Versatile'], '1d10'),//這邊 可雙手 1d10 是雙手持用時的傷害
//     new Weapon('Flail', '10 gold', { formula: '1d8', type: 'Bludgeoning' }, 2, []),
//     new Weapon('Glaive', '20 gold', { formula: '1d10', type: 'Slashing' }, 6, ['Heavy', 'Reach', 'Two-Handed']),
//     new Weapon('Greataxe', '30 gold', { formula: '1d12', type: 'Slashing' }, 7, ['Heavy', 'Two-Handed']),
//     new Weapon('Greatsword', '50 gold', { formula: '2d6', type: 'Slashing' }, 6, ['Heavy', 'Two-Handed']),
//     new Weapon('Halberd', '20 gold', { formula: '1d10', type: 'Slashing' }, 6, ['Heavy', 'Reach', 'Two-Handed']),
//     new Weapon('Lance', '10 gold', { formula: '1d12', type: 'Piercing' }, 6, ['Reach', 'Special']),
//     new Weapon('Longsword', '15 gold', { formula: '1d8', type: 'Slashing' }, 3, ['Versatile'], '1d10'),//這邊 可雙手 1d10 是雙手持用時的傷害
//     new Weapon('Maul', '10 gold', { formula: '2d6', type: 'Bludgeoning' }, 10, ['Heavy', 'Two-Handed']),
//     new Weapon('Morningstar', '15 gold', { formula: '1d8', type: 'Piercing' }, 4, []),
//     new Weapon('Pike', '5 gold', { formula: '1d10', type: 'Piercing' }, 18, ['Heavy', 'Reach', 'Two-Handed']),
//     new Weapon('Rapier', '25 gold', { formula: '1d8', type: 'Piercing' }, 2, ['Finesse']),
//     new Weapon('Scimitar', '25 gold', { formula: '1d6', type: 'Slashing' }, 3, ['Finesse', 'Light']),
//     new Weapon('Shortsword', '10 gold', { formula: '1d6', type: 'Piercing' }, 2, ['Finesse', 'Light']),
//     new Weapon('Trident', '5 gold', { formula: '1d6', type: 'Piercing' }, 4, ['Thrown', 'Versatile'], '20/60 ft, 1d8'),//這邊 可雙手 1d8 是雙手持用時的傷害
//     new Weapon('War Pick', '5 gold', { formula: '1d8', type: 'Piercing' }, 2, []),
//     new Weapon('Warhammer', '15 gold', { formula: '1d8', type: 'Bludgeoning' }, 2, ['Versatile'], '1d10'),//這邊 可雙手 1d10 是雙手持用時的傷害
//     new Weapon('Whip', '2 gold', { formula: '1d4', type: 'Slashing' }, 3, ['Finesse', 'Reach']),
//     new Weapon('Blowgun', '10 gold', { formula: '1', type: 'Piercing' }, 1, ['Ammunition', 'Loading'], '25/100 ft'),
//     new Weapon('Hand Crossbow', '75 gold', { formula: '1d6', type: 'Piercing' }, 3, ['Ammunition', 'Light', 'Loading'], '30/120 ft'),
//     new Weapon('Heavy Crossbow', '50 gold', { formula: '1d10', type: 'Piercing' }, 18, ['Ammunition', 'Heavy', 'Loading', 'Two-Handed'], '100/400 ft'),
//     new Weapon('Longbow', '50 gold', { formula: '1d8', type: 'Piercing' }, 2, ['Ammunition', 'Heavy', 'Two-Handed'], '150/600 ft'),
//     new Weapon('Net', '1 gold', { formula: '0', type: 'None' }, 3, ['Special', 'Thrown'], '5/15 ft')
// ];


/**
 * 武器屬性 Weapon Properties
許多武器都具有與它使用時有關的特殊屬性，如武器表所示。

彈藥. 你只能在擁有該武器射擊所需要的彈藥時，才能使用具有彈藥屬性的武器進行一次遠程攻擊。每次你使用該武器攻擊，你消耗一發彈藥。從箭袋、盒子、或其他容器抽出彈藥被視為該攻擊的一部份。裝填單手武器需要一隻空手。在戰鬥結束後，你可以藉由花費一分鐘的時間搜索戰場，以拿回一半你所消耗掉的彈藥量。
如果你使用具有彈藥屬性的武器進行一次近戰攻擊，你將該武器視作臨時武器（參見本段落中後述的「臨時武器」）。投石索必須要在已裝填的情況下才能以這種方式造成傷害。

靈巧. 當你使用靈巧武器進行攻擊時，你可以選擇在該次攻擊檢定和傷害骰中使用你的力量或敏捷調整值。這兩次擲骰必須使用相同的調整值。
重型. 小型生物在使用重型武器進行攻擊時會承受劣勢。重型武器的尺寸和重量使它對小型生物而言太過龐大而無法有效使用。
輕型. 輕型武器小而易用，讓其相當適合被用於雙武器戰鬥。參見第九章的雙武器戰鬥規則。
裝填. 由於裝填此武器所需的時間，當你使用動作、附贈動作、或反應以該武器射擊時，無論你原本可以進行幾次攻擊，你都只能用其射出一發彈藥。
射程. 可以被用來進行遠程攻擊的武器，都會在彈藥或投擲屬性後用括號標示射程。射程列有兩個數字。第一個是該武器的正常射程，第二個則代表著武器的長射程。當攻擊處於正常射程之外的目標時，你在該攻擊檢定上承受劣勢。你不能攻擊處於武器長射程之外的目標。
觸及. 當你使用此武器攻擊時，此武器讓你的觸及距離增加5呎。這個屬性也影響你使用觸及武器進行藉機攻擊的觸及距離。
特殊. 具有特殊屬性的武器有著獨特的規則以處理其使用，詳情請參閱該武器的描述（參見本段落中後述的「特殊武器」）。
投擲. 如果一把武器具有投擲屬性，則你可以投擲此武器以進行一次遠程攻擊。如果該武器是一把近戰武器，則你在該攻擊檢定和傷害骰中使用與你用其進行近戰攻擊時相同的屬性調整值。舉例來說，若你投擲一把手斧，則你使用你的力量。但如果你投擲的是一把匕首，由於匕首具有靈巧屬性，因此你可以從你的力量或敏捷中擇一使用。
雙手. 此武器需要雙手使用。這個屬性只關聯於你使用此武器攻擊時，而非單純持握它的時候。
可雙手. 此武器可以被單手或雙手使用。這個屬性後方所顯示括號內的傷害數值，代表著以雙手使用此武器進行一次近戰攻擊時的傷害。
 */