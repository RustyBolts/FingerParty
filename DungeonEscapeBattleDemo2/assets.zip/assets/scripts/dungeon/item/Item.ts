export class Item {
    name: string = '';  // 道具名称
    cost: string;       // 武器的價格
    weight: number = 0; // 道具重量
    size: number = 1;   // 道具占用的格数

    constructor(name: string, cost: string, weight: number, size: number) {
        this.name = name;
        this.cost = cost;
        this.weight = weight;
        this.size = size;
    }
}
