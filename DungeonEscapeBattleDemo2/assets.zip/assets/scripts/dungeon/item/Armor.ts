import { Item } from "./Item";

type ArmorType = 'Light' | 'Medium' | 'Heavy';
type StealthDisadvantage = 'None' | 'Disadvantage';

enum ArmorStyle {
    AllLightArmors = 'AllLightArmors',
    Padded = 'Padded',
    Leather = 'Leather',
    StuddedLeather = 'Studded Leather',

    AllMediumArmors = 'AllMediumArmors',
    Hide = 'Hide',
    ChainShirt = 'Chain Shirt',
    ScaleMail = 'Scale Mail',
    Breastplate = 'Breastplate',
    HalfPlate = 'Half Plate',

    AllHeavyArmors = 'AllHeavyArmors',
    RingMail = 'Ring Mail',
    ChainMail = 'Chain Mail',
    Splint = 'Splint',
    Plate = 'Plate'
}

class Armor extends Item {
    armorClassBase: number;
    strengthRequirement: number;
    stealthDisadvantage: StealthDisadvantage;
    armorType: ArmorType;
    iconName: string;

    /**
     * 
     * @param name 名稱
     * @param iconName 圖示名稱
     * @param cost 價格
     * @param weight 重量
     * @param baseArmorClass 基礎護甲等級
     * @param strengthRequirement 最低需求力量
     * @param stealthDisadvantage 是否造成隱匿劣勢
     * @param armorType 護甲類型
     */
    constructor(name: string, iconName: string, cost: string, weight: number, baseArmorClass: number, strengthRequirement: number, stealthDisadvantage: StealthDisadvantage, armorType: ArmorType) {
        super(name, cost, weight, 1);
        this.iconName = iconName;
        this.armorClassBase = baseArmorClass;
        this.strengthRequirement = strengthRequirement;
        this.stealthDisadvantage = stealthDisadvantage;
        this.armorType = armorType;
    }

    calculateArmorClass(dexterityBonus: number): number {
        const maxDexBonus = this.getMaxDexBonus();
        const effectiveDexBonus = maxDexBonus !== null ? Math.min(dexterityBonus, maxDexBonus) : dexterityBonus;
        return this.armorClassBase + effectiveDexBonus;
    }

    private getMaxDexBonus(): number | null {
        switch (this.armorType) {
            case 'Light':
                return null;  // 无限制
            case 'Medium':
                return 2;     // 中甲最多 +2
            case 'Heavy':
                return 0;     // 重甲不加敏捷
            default:
                return null;
        }
    }
}

// 護甲类创建实例
// const padded = new Armor("Padded", "5 gold", 8, 11, 0, 'Disadvantage', 'Light');
// const leather = new Armor("Leather", "10 gold", 10, 11, 0, 'None', 'Light');
// const studdedLeather = new Armor("Studded Leather", "45 gold", 13, 12, 0, 'None', 'Light');

// const rawhide  = new Armor("Rawhide Armor", "10 gold", 12, 12, 0, 'None', 'Medium');
// const chainShirt = new Armor("Chain Shirt", "50 gold", 20, 13, 0, 'None', 'Medium');
// const scaleMail = new Armor("Scale Mail", "50 gold", 45, 14, 0, 'Disadvantage', 'Medium');
// const breastplate = new Armor("Breastplate", "400 gold", 20, 14, 0, 'None', 'Medium');
// const halfPlate = new Armor("Half Plate", "750 gold", 40, 15, 0, 'Disadvantage', 'Medium');

// const ringMail = new Armor("Ring Mail", "30 gold", 40, 14, 0, 'Disadvantage', 'Heavy');
// const chainMail = new Armor("Chain Mail", "75 gold", 55, 16, 13, 'Disadvantage', 'Heavy');
// const splint = new Armor("Splint", "200 gold", 60, 17, 15, 'Disadvantage', 'Heavy');
// const plate = new Armor("Plate", "1,500 gold", 65, 18, 15, 'Disadvantage', 'Heavy');
// const chainmail = new Armor("鎖子甲", 'chainmail', "75 gold", 55, 16, 13, 'Disadvantage', 'Heavy');

// const armorPadded = new Armor("綿甲", "padded", "5 gold", 8, 11, 0, 'Disadvantage', 'Light');
// const armorLeather = new Armor("皮甲", "leather", "10 gold", 10, 11, 0, 'None', 'Light');
// const armorStuddedLeather = new Armor("鑲釘皮甲", "studded leather", "45 gold", 13, 12, 0, 'None', 'Light');

// const armorRawhide = new Armor("生皮甲", "rawhide", "10 gold", 12, 12, 0, 'None', 'Medium');
// const armorChainShirt = new Armor("鏈甲衫", "chain shirt", "50 gold", 20, 13, 0, 'None', 'Medium');
// const armorScaleMail = new Armor("鱗甲", "scale mail", "50 gold", 45, 14, 0, 'Disadvantage', 'Medium');
// const armorBreastplate = new Armor("護胸甲", "breastplate", "400 gold", 20, 14, 0, 'None', 'Medium');
// const armorHalfPlate = new Armor("半身板甲", "half plate", "750 gold", 40, 15, 0, 'Disadvantage', 'Medium');

// const armorRingMail = new Armor("環甲", "ringmail", "30 gold", 40, 14, 0, 'Disadvantage', 'Heavy');
// const armorChainMail = new Armor("鎖子甲", "chainmail", "75 gold", 55, 16, 13, 'Disadvantage', 'Heavy');
// const armorSplint = new Armor("條板甲", "splint", "200 gold", 60, 17, 15, 'Disadvantage', 'Heavy');
// const armorPlate = new Armor("全身板甲", "plate", "1,500 gold", 65, 18, 15, 'Disadvantage', 'Heavy');

export {
    ArmorStyle,
    Armor,
    // todo 之後改成可以讀csv，更新外部資料就可以，不需要動code
    // armorPadded,
    // armorLeather,
    // armorStuddedLeather,
    // armorRawhide,
    // armorChainShirt,
    // armorScaleMail,
    // armorBreastplate,
    // armorHalfPlate,
    // armorRingMail,
    // armorChainMail,
    // armorSplint,
    // armorPlate
}