export enum Attribute {
    // BASE
    Strength = 'strength',          // 力量
    Dexterity = 'dexterity',        // 敏捷
    Intelligence = 'intelligence',  // 智力
    Wisdom = 'wisdom',              // 睿知
    Charisma = 'charisma',          // 魅力
    Resilience = 'resilience',      // 韌性
    // COMPOSITE
    Constitution = 'constitution',  // 體質
    Spirit = 'spirit',              // 精神
    Willpower = 'willpower',        // 意志
    // PASSIVE
    Athletics = 'athletics',        // 運動
    Perception = 'perception',      // 察覺
    Response = 'response',          // 反應
    Figurative = 'figurative',      // 形象(氣場、氣質)
}

export interface BaseAbilities {
    [Attribute.Strength]: number;
    [Attribute.Dexterity]: number;
    [Attribute.Intelligence]: number;
    [Attribute.Wisdom]: number;
    [Attribute.Charisma]: number;
    [Attribute.Resilience]: number;
}

export interface CompositeAbilities {
    [Attribute.Constitution]: number,   // 體質
    [Attribute.Spirit]: number,         // 精神
    [Attribute.Willpower]: number,      // 意志
}

export interface PassiveAbilities {
    [Attribute.Athletics]: number,      // 運動
    [Attribute.Perception]: number,     // 察覺
    [Attribute.Response]: number,       // 反應
    [Attribute.Figurative]: number,     // 形象
}