import { _decorator, Component, Node, ProgressBar, tween, Vec3, Label } from 'cc';
import { FloatingTextComponent } from '../../tools/FloatingTextComponent';
const { ccclass, property } = _decorator;

@ccclass('HitPointsBarComponent')
export class HitPointsBarComponent extends Component {
    @property(ProgressBar)
    hpBar: ProgressBar = null; // ProgressBar 组件显示血量

    @property(FloatingTextComponent)
    floatingTextComponent: FloatingTextComponent = null; // 浮动文字组件

    @property(Node)
    textSpawnPoint: Node = null; // 文字生成点

    @property(Label)
    hpLabel: Label = null; // 用于显示当前血量和最大血量的 Label

    private curHp: number = 100; // 当前血量
    private maxHp: number = 100; // 最大血量

    set defaultHp(value: number) {
        this.maxHp = value;
        this.curHp = value;
        this.updateBar(this.curHp);
        this.updateHpLabel();
    }

    // protected start(): void {
    //     this.defaultHp = 100; // 默认血量为 100
    //     this.changeHp(-20);
    // }

    _tempHp: number = 0; // 临时变量，用于存储当前血量变化值
    set tempHp(value: number) {
        this._tempHp = value;
        this.updateHpLabel();
    }
    get tempHp() {
        return this._tempHp;
    }

    changeHp(amount: number) {
        const newHp = Math.min(Math.max(this.curHp + amount, 0), this.maxHp);
        const positionPoint = this.textSpawnPoint.position.clone();
        const distance = 40;
        const animationDirection = amount <= 0 ? positionPoint.add(new Vec3(0, distance, 0)) : positionPoint.add(new Vec3(0, -distance, 0));

        // 设置 FloatingTextComponent 的起点和终点
        this.floatingTextComponent.startPoint = animationDirection;
        this.floatingTextComponent.endPoint = this.textSpawnPoint.position;

        // 显示变化的数值
        this.floatingTextComponent.showNumber(amount, () => {
            // 更新血量条
            this.updateBar(newHp);
            this.updateHpLabel(); // 更新血量显示
        });
    }

    updateBar(newHp: number) {
        const duration = 0.25;
        const from = this.hpBar.progress;
        const to = (newHp + this._tempHp) / this.maxHp;

        tween(this.hpBar)
            .to(duration, { progress: to })
            .start();

        this.curHp = newHp;
    }

    updateHpLabel() {
        if (this._tempHp)
            this.hpLabel.string = `HP: ${this.curHp + this._tempHp} (+${this._tempHp}) / ${this.maxHp}`; // 更新 Label 文本显示当前血量和最大血量
        else
            this.hpLabel.string = `HP: ${this.curHp} / ${this.maxHp}`; // 更新 Label 文本显示当前血量和最大血量
    }
}
