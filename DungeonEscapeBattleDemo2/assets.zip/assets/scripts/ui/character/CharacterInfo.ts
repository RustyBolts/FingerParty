import { _decorator, Component, Vec3, Node, RichText, randomRangeInt } from 'cc';
import { EventBus } from '../../managers/EventSystem';
import { TeamMember } from '../combat/TeamMember';
import { Character } from '../../dungeon/Character';
import { Weapon, WeaponProperty } from '../../dungeon/item/Weapon';
import { ArcherySkill } from '../../dungeon/combat/ArcherySkill';
import { CombatCard } from '../../cards/Card';
import { Attribute, BaseAbilities } from '../../dungeon/Ability';
import { EventManager } from '../../managers/EventManager';
import { CardMover } from '../../tools/CardMover';
import { CombatSkill } from '../../dungeon/combat/CombatSkill';
import { MeleeSkill } from '../../dungeon/combat/MeleeSkill';
import { AdventureSkill, Adventure } from '../../dungeon/adventure/AdventureSkill';
import { SkillProficiency } from '../../dungeon/Skill';
import { warriorFeatures } from '../../dungeon/ClassFeatureImplementation';
import { UIEvent } from '../../managers/UIManager';
import { Armor } from '../../dungeon/item/Armor';
import { Shield } from '../../dungeon/item/Shield';

const { ccclass, property } = _decorator;

@ccclass('CharacterInfo')
export class CharacterInfo extends Component {

    @property(TeamMember)
    member: TeamMember = null;

    @property(Node)
    characterInfoPos: Node = null;

    @property(RichText)
    abilitiesInfoText: RichText = null;

    private _character: Character = null;
    private _proficiencyAbilities: BaseAbilities = null;

    private _combatCardDeck: CombatCard[] = [];

    // 激發後的技能，抽卡時需要用到
    private _combatSkills: CombatSkill[] = [];

    private _weapons: Weapon[] = [];
    private _armor: Armor = null;
    private _shield: Shield = null;

    // eventBus: EventBus = null;
    // shielded: boolean = false;

    // private _adventureSkills: { [key: string]: AdventureSkill } = {};
    private _adventureSkills: AdventureSkill[] = [];

    private _missions: string[] = [];//任務id清單

    protected onLoad(): void {
        EventManager.instance.on('CharacterEquipWeapon', this.onEquipWeapon, this);
        EventManager.instance.on('CharacterEquipArmor', this.onEquipArmor, this);
        EventManager.instance.on('CharacterEquipShield', this.onEquipShield, this);
        EventManager.instance.on('CharacterUnequip', this.onUnequip, this);
        EventManager.instance.on('ResultBattle', this.onResultBattle, this);
        // EventManager.instance.on('CopingDramaBehavior', this.onCopingDramaBehavior, this);
        EventManager.instance.on('CopingSkillButtonClickEvent', this.onCopingSkillButtonClickEvent, this);
        EventManager.instance.on('UnderAttackDamage', this.onUnderAttackDamage, this);
        // this.sample();//test
        // this.init();
    }

    protected onDestroy(): void {
        EventManager.instance.off('CharacterEquipWeapon', this.onEquipWeapon, this);
        EventManager.instance.off('CharacterEquipArmor', this.onEquipArmor, this);
        EventManager.instance.off('CharacterEquipShield', this.onEquipShield, this);
        EventManager.instance.off('CharacterUnequip', this.onUnequip, this);
        EventManager.instance.off('ResultBattle', this.onResultBattle, this);
        // EventManager.instance.off('CopingDramaBehavior', this.onCopingDramaBehavior, this);
        EventManager.instance.off('CopingSkillButtonClickEvent', this.onCopingSkillButtonClickEvent, this);
        EventManager.instance.off('UnderAttackDamage', this.onUnderAttackDamage, this);
    }

    protected start(): void {
        this.node.position = Vec3.ZERO;
    }

    init(): void {
        // this._adventureSkills = {
        //     [Adventure.Stunts]: new AdventureSkill(Adventure.Stunts, Attribute.Dexterity, '特技', '肢體動作能演繹出超乎常人的巧妙'),
        //     [Adventure.Stealth]: new AdventureSkill(Adventure.Stealth, Attribute.Dexterity, '隱匿', '身形藏於目標的眼光之外而被忽視'),
        //     [Adventure.Dexterity]: new AdventureSkill(Adventure.Dexterity, Attribute.Dexterity, '巧手', '細微且冷靜地靈活運用手腕乃至手指'),
        //     [Adventure.Knowledge]: new AdventureSkill(Adventure.Knowledge, Attribute.Intelligence, '知識', '常鑽研書中的事物而獲得深厚的學問'),
        //     [Adventure.Experience]: new AdventureSkill(Adventure.Experience, Attribute.Intelligence, '閱歷', '長期冒險時得到的經驗與觀察力'),
        //     [Adventure.Nature]: new AdventureSkill(Adventure.Nature, Attribute.Intelligence, '自然', '遵循萬物平衡真理而存留下的軌跡'),
        //     [Adventure.Religion]: new AdventureSkill(Adventure.Religion, Attribute.Intelligence, '宗教', '從信仰的神明到儀式的文化有所認識'),
        //     [Adventure.Explore]: new AdventureSkill(Adventure.Explore, Attribute.Intelligence, '探索', '從調查細節乃搜索區域而得到訊息'),
        //     [Adventure.Nursing]: new AdventureSkill(Adventure.Nursing, Attribute.Wisdom, '護理', '發現生理結構的徴結而掌握的救護'),
        //     [Adventure.Awareness]: new AdventureSkill(Adventure.Awareness, Attribute.Wisdom, '覺察', '藉由察顏觀色而獲得行動先機'),
        //     [Adventure.Taming]: new AdventureSkill(Adventure.Taming, Attribute.Wisdom, '馴服', '理解並能受到動物的認同而接受指令'),
        //     [Adventure.Survival]: new AdventureSkill(Adventure.Survival, Attribute.Wisdom, '生存', '在野外生存或遭受意外的判斷與技巧'),
        //     [Adventure.Observation]: new AdventureSkill(Adventure.Observation, Attribute.Wisdom, '觀察', '敏銳抓出細節差異或感受違和的發展'),
        //     [Adventure.Performance]: new AdventureSkill(Adventure.Performance, Attribute.Charisma, '表演', '將肢體化為語言來傳達的藝術表現'),
        //     [Adventure.Persuasion]: new AdventureSkill(Adventure.Persuasion, Attribute.Charisma, '說服', '藉由靈活的口才令聞者動搖心智'),
        //     [Adventure.Intimidation]: new AdventureSkill(Adventure.Intimidation, Attribute.Charisma, '威嚇', '以言語或動作表情傳達出脅迫之意'),
        //     [Adventure.Shove]: new AdventureSkill(Adventure.Shove, Attribute.Strength, '推撞', '以自身的力量推撞對手而使其退開'),
        // };
        this._adventureSkills = [
            new AdventureSkill(Adventure.Stunts, Attribute.Dexterity, '特技', '肢體動作能演繹出超乎常人的巧妙'),
            new AdventureSkill(Adventure.Stealth, Attribute.Dexterity, '隱匿', '身形藏於目標的眼光之外而被忽視'),
            new AdventureSkill(Adventure.Dexterity, Attribute.Dexterity, '巧手', '細微且冷靜地靈活運用手腕乃至手指'),
            new AdventureSkill(Adventure.Knowledge, Attribute.Intelligence, '知識', '常鑽研書中的事物而獲得深厚的學問'),
            new AdventureSkill(Adventure.Experience, Attribute.Intelligence, '閱歷', '長期冒險時得到的經驗與觀察力'),
            new AdventureSkill(Adventure.Nature, Attribute.Intelligence, '自然', '遵循萬物平衡真理而存留下的軌跡'),
            new AdventureSkill(Adventure.Religion, Attribute.Intelligence, '宗教', '從信仰的神明到儀式的文化有所認識'),
            new AdventureSkill(Adventure.Explore, Attribute.Intelligence, '探索', '從調查細節乃搜索區域而得到訊息'),
            new AdventureSkill(Adventure.Nursing, Attribute.Wisdom, '護理', '發現生理結構的徴結而掌握的救護'),
            new AdventureSkill(Adventure.Awareness, Attribute.Wisdom, '覺察', '藉由察顏觀色而獲得行動先機'),
            new AdventureSkill(Adventure.Taming, Attribute.Wisdom, '馴服', '理解並能受到動物的認同而接受指令'),
            new AdventureSkill(Adventure.Survival, Attribute.Wisdom, '生存', '在野外生存或遭受意外的判斷與技巧'),
            new AdventureSkill(Adventure.Observation, Attribute.Wisdom, '觀察', '敏銳抓出細節差異或感受違和的發展'),
            new AdventureSkill(Adventure.Performance, Attribute.Charisma, '表演', '將肢體化為語言來傳達的藝術表現'),
            new AdventureSkill(Adventure.Persuasion, Attribute.Charisma, '說服', '藉由靈活的口才令聞者動搖心智'),
            new AdventureSkill(Adventure.Intimidation, Attribute.Charisma, '威嚇', '以言語或動作表情傳達出脅迫之意'),
            new AdventureSkill(Adventure.Shove, Attribute.Strength, '推撞', '以自身的力量推撞對手而使其退開')
        ];

        EventManager.instance.emit('InitAdventureSkills', this._adventureSkills);
    }

    set character(value: Character) {
        this._character = value;
        this.member.characterInitial(value);

        this.refreshCharacterInfo();
    }

    refreshCharacterInfo() {
        this.init();

        this.member.characterInitial(this._character);
        this.member.disableSelect();

        this._proficiencyAbilities = this._character.calculateProficienciesBonus();

        // todo 技能牌庫要在這邊產生, 升級後也要更新 _combatSkills
        // // 角色職業

        // // 依角色技能產生相應卡牌
        // this.eventBus = new EventBus();
        // let skillLevel = 2;
        // const combatSkill = new ArcherySkill(skillLevel, this.eventBus);//todo 從 mainCharacter 取得技能

        // this._combatCardDeck.length = 0;
        // const cardSource = combatSkill.getSkill();
        // const cardLength = cardSource.length;
        // for (let i = 0; i < 14; i++) {
        //     this._combatCardDeck.push(cardSource[randomRangeInt(0, cardLength)]);
        // }

        // todo 從設定上來拿 CombatSkill。內容是用string 暫存已習得技能
        // this._combatSkills.length = 0;
        // Object.keys(this._character.skills).forEach((skillName: string) => {
        //     let skillLevel = this._character.skills[skillName];
        //     switch (skillName) {
        //         case 'Archery':
        //             this._combatSkills.push(new ArcherySkill(skillLevel, this.eventBus));
        //             break;
        //         case 'Melee':
        //             this._combatSkills.push(new MeleeSkill(skillLevel, this.eventBus));
        //             break;
        //     }
        // });

        const proficienciesBonus = this._character.calculateProficienciesBonus();
        const compositeAbilities = this._character.calculateCompositeAbilities();
        const { strength, dexterity, intelligence, wisdom, charisma, resilience } = this._character.abilities;

        this.abilitiesInfoText.string = `姓名: ${this._character.name}\n` +
            `等級: ${this._character.level}\n` +
            `力量: ${strength}(+${proficienciesBonus.strength})\n` +
            `敏捷: ${dexterity}(+${proficienciesBonus.dexterity})\n` +
            `智力: ${intelligence}(+${proficienciesBonus.intelligence})\n` +
            `睿知: ${wisdom}(+${proficienciesBonus.wisdom})\n` +
            `魅力: ${charisma}(+${proficienciesBonus.charisma})\n` +
            `韌性: ${resilience}(+${proficienciesBonus.resilience})\n` +
            `體質: ${compositeAbilities.constitution}\n` +
            `精神: ${compositeAbilities.spirit}\n` +
            `意志: ${compositeAbilities.willpower}\n` +
            this._adventureSkills.map(skill => skill.displayName + ': ' + skill.description + ` | +${this.getAdventureSkillModifier(skill.name as Adventure)}`).join('\n');
        // `${this._adventureSkills[Adventure.Stunts].description} | +${this.getAdventureSkillModifier(Adventure.Stunts)}\n` +
        // `${this._adventureSkills[Adventure.Stealth].description} | +${this.getAdventureSkillModifier(Adventure.Stealth)}\n` +
        // `${this._adventureSkills[Adventure.Dexterity].description} | +${this.getAdventureSkillModifier(Adventure.Dexterity)}\n` +
        // `${this._adventureSkills[Adventure.Knowledge].description} | +${this.getAdventureSkillModifier(Adventure.Knowledge)}\n` +
        // `${this._adventureSkills[Adventure.Experience].description} | +${this.getAdventureSkillModifier(Adventure.Experience)}\n` +
        // `${this._adventureSkills[Adventure.Nature].description} | +${this.getAdventureSkillModifier(Adventure.Nature)}\n` +
        // `${this._adventureSkills[Adventure.Religion].description} | +${this.getAdventureSkillModifier(Adventure.Religion)}\n` +
        // `${this._adventureSkills[Adventure.Explore].description} | +${this.getAdventureSkillModifier(Adventure.Explore)}\n` +
        // `${this._adventureSkills[Adventure.Nursing].description} | +${this.getAdventureSkillModifier(Adventure.Nursing)}\n` +
        // `${this._adventureSkills[Adventure.Awareness].description} | +${this.getAdventureSkillModifier(Adventure.Awareness)}\n` +
        // `${this._adventureSkills[Adventure.Taming].description} | +${this.getAdventureSkillModifier(Adventure.Taming)}\n` +
        // `${this._adventureSkills[Adventure.Survival].description} | +${this.getAdventureSkillModifier(Adventure.Survival)}\n` +
        // `${this._adventureSkills[Adventure.Observation].description} | +${this.getAdventureSkillModifier(Adventure.Observation)}\n` +
        // `${this._adventureSkills[Adventure.Performance].description} | +${this.getAdventureSkillModifier(Adventure.Performance)}\n` +
        // `${this._adventureSkills[Adventure.Persuasion].description} | +${this.getAdventureSkillModifier(Adventure.Persuasion)}\n` +
        // `${this._adventureSkills[Adventure.Intimidation].description} | +${this.getAdventureSkillModifier(Adventure.Intimidation)}\n`;
    }

    upgradeAdventureSkill(name: Adventure): boolean {
        // return !!this._adventureSkills[name]?.upgradeSkillProficiency();
        return !!this._adventureSkills.find(skill => skill.name === name)?.upgradeSkillProficiency();
    }

    acceptMission(missionId: string): void {
        this._missions.push(missionId);

        // if (this._missions.length === 1) {

        // }
    }

    getAdventureSkillModifier(name: Adventure): number {
        // const skill: AdventureSkill = this._adventureSkills[name];
        const skill: AdventureSkill = this._adventureSkills.find(skill => skill.name === name);
        const { level, linkedAttribute } = skill;

        let modifier = this._character.calculateAbilityScoreModifier(linkedAttribute);
        switch (level) {
            case SkillProficiency.Proficient:
                modifier += this._character.calculateClassProficiencyBonus();
                break;
            case SkillProficiency.Expert:
                modifier += this._character.calculateClassProficiencyBonus() * 2;
                break;
            default: break;
        }

        return modifier;
    }

    onCopingSkillButtonClickEvent(event: any): void {
        // const roll = this.performAdventureSkillCheck(event.name);
        // 需要演出，所以分開骰子分開
        const { name, copings } = event;
        const modifier = this.getAdventureSkillModifier(name);
        const roll = randomRangeInt(1, 20);

        EventManager.instance.emit('PerformCopingSkillCheck', roll, modifier, name, copings);
    }

    // // 角色冒險技能檢定
    // performAdventureSkillCheck(name: Adventure): number {
    //     const modifier = this.getAdventureSkillModifier(name);
    //     return randomRangeInt(1, 20) + modifier;
    // }

    // 骰先攻順序 todo: 讓外面拿memeber 去處理，不要在這裡處理
    rollInitiativeOrder() {
        this.member.rollInitiativeOrder(this._proficiencyAbilities.dexterity);
    }

    // 獲得卡牌時暫存在這邊，戰鬥時使用
    addCombatCard(card: CombatCard) {
        this._combatCardDeck.push(card);
    }

    getCombatCards(): CombatCard[] {
        return this._combatCardDeck;
    }

    onEquipWeapon(event: any) {
        const { index, item } = event;
        console.log('onEquipWeapon', index, item);
        const primaryAttribute = this._character.primaryAttribute;
        const abilityProficiencyBonus = this._proficiencyAbilities[primaryAttribute];
        this.member.setWeapon(index, item, abilityProficiencyBonus);
        this.member.showCharacterInfo();

        this._weapons[index] = item;
    }

    onEquipArmor(event: any) {
        const { index, item } = event;
        this.member.setArmor(index, item);
        this.member.showCharacterInfo();

        this._armor = item;
    }

    onEquipShield(event: any): void {
        const { index, item } = event;
        this.member.setShield(index, item);
        this.member.showCharacterInfo();

        this._shield = item;
    }

    onUnequip(event: any): void {
        const { index } = event;
        console.log('onCharacterUnequip', index);
        this.member.setWeapon(index, null);
        this.member.showCharacterInfo();

        this._weapons[index] = null;
    }

    // 因為其他非戰鬥玩法因素而受傷
    onUnderAttackDamage(damageValue: number): void {
        console.log('onDamage', damageValue);
        this.member.changeHpBar(-damageValue);
    }

    refreshItemInfo() {
        this._weapons.forEach((weapon, index) => {
            const primaryAttribute = this._character.primaryAttribute;
            const abilityProficiencyBonus = this._proficiencyAbilities[primaryAttribute];
            this.member.setWeapon(index, weapon, abilityProficiencyBonus);
            this.member.showCharacterInfo();
        });

        this._armor && this.member.setArmor(0, this._armor);

        this._shield && this.member.setShield(0, this._shield);

    }

    async onResultBattle(): Promise<void> {
        // 回到人物資訊頁位置
        await CardMover.moveCard(this.member.node, this.characterInfoPos, new Vec3(0, 0, 0));

        this.member.leaveCombatTeam();
    }

    sample(): void {

        // 建立玩家能力值
        const abilityScores: BaseAbilities = {
            [Attribute.Strength]: 15,
            [Attribute.Dexterity]: 14,
            [Attribute.Intelligence]: 13,
            [Attribute.Wisdom]: 12,
            [Attribute.Charisma]: 10,
            [Attribute.Resilience]: 8
        };

        this._character = new Character('warrior', 1, abilityScores, warriorFeatures);
    }

}