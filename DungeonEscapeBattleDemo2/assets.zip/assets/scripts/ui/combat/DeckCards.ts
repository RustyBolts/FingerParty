import { _decorator, instantiate, Layout, Node } from "cc";
import { BaseCardDisplay } from "../../cards/BaseCardDisplay";
import { CardComponent } from "./CardComponent";
import { CombatCard } from "../../cards/Card";

const { ccclass, property } = _decorator;

@ccclass('DeckCards')
export default class DeckCards extends BaseCardDisplay {
    /** 選出可丟棄的卡牌數量上限 */
    discardLimit: number = 3;

    doShowCard(cards: CombatCard[]):void {
        this.showCards(cards);
    }

    protected showCards(cards: CombatCard[]) {
        const positionNodes = this.positionContainer.children;
        if (positionNodes.length !== cards.length) {
            console.error('卡牌數量與定位節點數量不符');
            return;
        }

        if (this.selectedCardNodes.length > 0) {
            console.error('已經有選取的卡片，請先清除之前的選取');
        }

        this.cardContainer.removeAllChildren();
        cards.forEach((card, index) => {
            const cardNode = instantiate(this.cardPrefab);
            cardNode.name = `Card_${index}`;
            cardNode.getComponent(CardComponent).setup(card);
            cardNode.parent = this.cardContainer;
        });

        // this.updatePositionLayout();
    }
    toggleCardSelection(cardNode: Node) {
        super.toggleCardSelection(cardNode);

        const cardData = cardNode.getComponent(CardComponent).card;

        if (this.selected.includes(cardData)) {
            // 發出事件：取消選取
            // EventManager.instance.emit(GameUIEvent.DeckCardUnselected, cardData);
        } else {
            // 發出事件：選取
            // EventManager.instance.emit(GameUIEvent.DeckCardSelected, cardData);
        }
    }

    // 確認選取
    confirmSelection(): boolean {
        const hadSelected = this.selected.length > 0;
        if (hadSelected) {
            console.log('Discarding cards:', this.selected);
        } else {
            console.log('No card selected.');
        }

        return hadSelected;
    }

    // /** 丟棄已選取的卡牌 */
    // async discardSelectedCards() {
    //     // 結束選取狀態
    //     await this.unselectAllCards();

    //     // this.selected.length = 0;// 不要清空，紀錄已選取的上限，限制選取數量

    //     // 重刷卡牌排版
    //     // const layout = this.cardContainer.getComponent(Layout);
    //     // layout.enabled = true;
    //     // layout.updateLayout();

    //     // layout.enabled = false;
    //     this.updatePositionLayout();
    //     this.followPosition();
    // }

    getSelectedCards() {
        return this.selected;
    }

    getCardContentNodes(): Node[] {
        return this.cardContainer.children;
    }
}