import { _decorator, Button, Component } from 'cc';
import { CombatFormation } from './CombatFormation';
import { CombatVisualizer } from './CombatVisualizer';
import { TeamMember } from './TeamMember';
import { EventManager } from '../../managers/EventManager';
import { EventBus } from '../../managers/EventSystem';
import { CombatOption } from './CombatOption';
import { TipType } from '../../tools/TipText';
import { EffectManager } from '../../managers/EffectManager';
import { CombatCard } from '../../cards/Card';
import { EnemySkill } from '../../dungeon/combat/EnemySkill';
import { UIEvent } from '../../managers/UIManager';
const { ccclass, property } = _decorator;

export enum CombatControllerEvent {
    InitiativeOrder = 'combat_controller_event_initative_order',
    SelectCharacter = 'combat_controller_event_select_character',
    // CharacterSelected = 'combat_controller_event_character_selected',
    SelectMonster = 'combat_controller_event_select_monster',
    // StartCombat = 'combat_controller_event_start_combat',
    EndCombat = 'combat_controller_event_end_combat',
    // CombatCheck = 'combat_controller_event_combat_check',
    // UpdateFormation = 'combat_controller_event_update_formation',
    // EnemyExecuteIntent = 'combat_controller_event_enemy_execute_intent',
    ChoiceCard = 'combat_controller_event_choice_card',
    // ResultBattle = 'combat_controller_event_result_battle',
    // ShowCard = 'combat_controller_event_show_card',
    // HideCard = 'combat_controller_event_hide_card',
    // ShowTip = 'combat_controller_event_show_tip',
    // HideTip = 'combat_controller_event_hide_tip',
    // ShowCharacterInfo = 'combat_controller_event_show_character_info',
}

@ccclass('CombatController')
export class CombatController extends Component {
    @property(CombatFormation)
    combatFormations: CombatFormation[] = [];// [我方，敵方]

    @property(CombatVisualizer)
    combatVisualizer: CombatVisualizer = null;

    @property(CombatOption)
    combatOption: CombatOption = null;

    @property(Button)
    attackButton: Button = null;

    eventBus: EventBus = null;

    combatQueue: TeamMember[] = [];
    initiativeIndex: number = 0;
    mainCharacter: TeamMember = null;

    currentAttacker: TeamMember = null;
    currentDefenders: TeamMember[] = [];

    protected onLoad(): void {
        EventManager.instance.on(CombatControllerEvent.InitiativeOrder, this.onInitiativeOrder, this);
        EventManager.instance.on(CombatControllerEvent.SelectCharacter, this.onSelectCharacter, this);
        // EventManager.instance.on(CombatControllerEvent.CharacterSelected, this.onCharacterSelected, this);
        EventManager.instance.on(CombatControllerEvent.SelectMonster, this.onSelectMonster, this);
        // EventManager.instance.on(CombatControllerEvent.StartCombat, this.startCombat, this);
        EventManager.instance.on(CombatControllerEvent.EndCombat, this.onEndCombat, this);
        // EventManager.instance.on('CombatCheck', this.onCombatCheck, this);
        // EventManager.instance.on(CombatControllerEvent.UpdateFormation, this.onUpdateFormation, this);
        EventManager.instance.on('SubmitSelectedCards', this.onSubmitSelectedCards, this);

        this.eventBus = new EventBus();
    }

    protected onDestroy(): void {
        EventManager.instance.off(CombatControllerEvent.InitiativeOrder, this.onInitiativeOrder, this);
        EventManager.instance.off(CombatControllerEvent.SelectCharacter, this.onSelectCharacter, this);
        // EventManager.instance.off(CombatControllerEvent.CharacterSelected, this.onCharacterSelected, this);
        EventManager.instance.off(CombatControllerEvent.SelectMonster, this.onSelectMonster, this);
        // EventManager.instance.off(CombatControllerEvent.StartCombat, this.startCombat, this);
        EventManager.instance.off(CombatControllerEvent.EndCombat, this.onEndCombat, this);
        // EventManager.instance.off('CombatCheck', this.onCombatCheck, this);
        // EventManager.instance.off(CombatControllerEvent.UpdateFormation, this.onUpdateFormation, this);
        EventManager.instance.off('SubmitSelectedCards', this.onSubmitSelectedCards, this);
    }

    // onStartGame(): void {
    //     this.combatOption.initDeck(2);//todo 不應該在onLoad 就初始化，可能要找一個首次觸發戰鬥介面的地方
    // }

    // 加入戰鬥
    joinCombat(camp: number, teamMember: TeamMember, position: number) {
        console.log('joinCombat', camp, teamMember, position)
        const formation = this.combatFormations[camp];
        if (position === 0)
            formation.addFrontMemeber(teamMember);
        else
            formation.addBackMember(teamMember);

        // this.onUpdateFormation();

        // todo 暫時顯示玩家角色資訊放這邊，之後可以改成通知，並且不止玩家角色
        if (position === 0)
            teamMember.showCharacterInfo();
    }

    // 退出戰鬥
    leaveCombat(camp: number, teamMember: TeamMember) {
        const formation = this.combatFormations[camp];
        formation.removeMember(teamMember);

        // this.onUpdateFormation();
    }

    async startCombat() {
        this.combatVisualizer.node.active = true;

        const team1Fighters: TeamMember[] = this.combatFormations[0].fighters;
        const team2Fighters: TeamMember[] = this.combatFormations[1].fighters;
        const attackDirection = this.currentAttacker.camp === 0 ? 1 : -1;
        console.log('第一次');
        await this.combatVisualizer.showCombat(team1Fighters, team2Fighters, attackDirection, 0);
        // 清狀態

        // console.log('第二次');// todo 反擊的地方會造成問題，所以看是不是把反擊也拉出來
        // if (attackDirection === 1)
        // await this.combatVisualizer.showCombat(team1Fighters, team2Fighters, attackDirection, 1);

        // 結束跑一下效果更新，順道清內容？如何？把這段統一做在這邊，玩家角色也是
        // EffectManager.instance.updateEffects();//todo 把效果在playerHandCards更新做觸發
    }

    combatRound() {
        this.attackButton.node.active = false;

        const attacker = this.combatQueue[this.initiativeIndex];
        // const attacker = this.mainCharacter;//TEST
        if (attacker == null) {
            console.error('Combat queue is empty', this.initiativeIndex);
            return;
        }
        this.currentAttacker = attacker;
        if (attacker === this.mainCharacter) {
            EventManager.instance.emit(TipType.Normal, '玩家回合');
            // 玩家可控制
            // this.mainCharacter.enableSelect();
            this.combatFormations[0].pushFighter(attacker);
            this.onSelectCharacter(attacker);//test 直接指定攻擊玩家角色，之後要想一下怎麼改成隨機抓我方人員進行攻擊
        } else {
            EventManager.instance.emit(TipType.Normal, '怪物回合');
            attacker.roundOver();//
            if (attacker.camp === 0) {
                let defender = this.combatFormations[1].teamMembers[0][0];//todo 想一下怎麼做選擇
                this.combatFormations[0].pushFighter(attacker);
                this.combatFormations[1].pushFighter(defender);
                this.onEnemyExecuteIntent(attacker, defender);
            } else {
                let defender = this.combatFormations[0].teamMembers[0][0];//todo 想一下怎麼做選擇
                this.combatFormations[0].pushFighter(defender);
                this.combatFormations[1].pushFighter(attacker);
                this.onEnemyExecuteIntent(attacker, defender);
            }

            this.scheduleOnce(this.startCombat.bind(this), 1);
        }
        this.initiativeIndex = (this.initiativeIndex + 1) % this.combatQueue.length;
    }

    onEnemyExecuteIntent(attacker: TeamMember, defender: TeamMember): void {
        const cards: any[] = new EnemySkill('monsterkill', '怪物技能', 1, this.eventBus).getSkill1();
        const combatCards: CombatCard[] = cards;
        console.log('playCard', combatCards);
        // 執行技能效果
        attacker.combatCardsToIntent(combatCards.sort(() => Math.random() - 0.5).slice(0, 2));
        attacker.intent();
        // attacker.reaction(defender);
        attacker.showIntent();
    }

    onEndCombat(): void {
        this.combatVisualizer.node.active = false;

        this.onUpdateFormation(true);
        this.endCombat();
    }

    endCombat() {
        // 处理战斗后的逻辑，如角色状态更新等

        // 檢查兩隊是否有全滅的
        let deadTeam = -1;
        this.combatFormations.forEach((formation: CombatFormation, index: number) => {
            if (formation.isAllDead()) {
                deadTeam = index;
            }
        });

        if (deadTeam === -1) {
            this.combatRound();
        } else {
            EventManager.instance.emit('ResultBattle');

            if (deadTeam === 0) {
                EventManager.instance.emit(TipType.Normal, '<color=#ff0000>失敗！<br/>玩家陣亡</color>');

            } else {
                EventManager.instance.emit(TipType.Normal, '<color=#00ff00>勝利！<br/>敵隊陣亡，請選擇一張卡牌加入你的牌庫</color>');

                // 贏了，做三選一
                EventManager.instance.emit('ChoiceCard');
            }

            // this.leaveCombat(deadTeam,)//todo 欸…不好用，目前還沒有一次清一個，所以直接全清
            this.combatFormations.forEach((formation) => formation.clear());
        }

        this.combatVisualizer.closeHitTips();
    }

    onUpdateFormation(clearFighters: boolean = true) {
        // this.combatFormations.forEach((formation) => formation.updateTeamStatus());
        // 调整队形
        this.combatFormations.forEach((formation) => formation.rearrangeMembers(clearFighters));
    }

    // 帶入角色資訊，並決定先攻
    onInitiativeOrder(event: any): void {
        // this.combatOption.initDeck(2);//todo 要改成讀取角色資訊，並且要做角色選擇

        EventManager.instance.emit(UIEvent.InventoryShowUI, false);

        const { mainCharacter, team } = event;
        const [team1, team2] = team;

        this.mainCharacter = mainCharacter;
        this.combatOption.init(this.eventBus, mainCharacter);

        // todo 要處理的是站位傾向，而不是用先攻來決定站位順序

        team1.sort((a, b) => a.initiative - b.initiative).forEach((member: TeamMember, index) => {
            member.joinCombatTeam();
            member.disableSelect();
            this.joinCombat(0, member, index);// todo 加入站位傾向
        });

        team2.sort((a, b) => a.initiative - b.initiative).forEach((member: TeamMember, index) => {
            member.joinCombatTeam();
            member.disableSelect();
            this.joinCombat(1, member, index);// todo 加入站位傾向
        });

        this.combatQueue = [...team1, ...team2].sort((a, b) => b.initiative - a.initiative);
        this.initiativeIndex = 0;

        // 進行戰鬥輪
        this.combatRound();
    }

    onSelectCharacter(member: TeamMember): void {

        //test 顯示玩家控制角色的介面
        this.scheduleOnce(() => {
            this.combatOption.show(member);
            //
            // this.onCharacterSelected();
        }, 1.5);

    }

    onCharacterSelected(): void {
        // 選擇可攻擊的敵隊成員
        const emenyTeam = this.combatFormations[1];
        emenyTeam.updateTeamStatus();
    }

    onSelectMonster(memeber: TeamMember): void {
        this.combatFormations[1].pushFighter(memeber);

        this.startCombat();//直接攻擊，之後再看怎麼調整流程
    }

    onSubmitSelectedCards(): void {
        //TEST
        this.mainCharacter.joinCombatTeam();//todo 測試方便換武器，演戰鬥的時候要隱藏

        // EffectManager.instance.updateEffects();//todo 之後再補效果更新，目前專心做攻擊 modifier

        // 更新陣形
        this.onUpdateFormation(false);
        this.combatOption.close();

        // 選擇可攻擊的敵隊成員
        const emenyTeam = this.combatFormations[1];
        const enemy = emenyTeam.teamMembers.flat(1);
        if (enemy.length === 1) {
            // 自動選唯一的敵人進行攻擊
            this.onSelectMonster(enemy[0]);
        } else {
            // 選擇可攻擊的敵隊成員
            emenyTeam.updateTeamStatus();
        }
    }

    // onCombatCheck(attacker: TeamMember, defenders: TeamMember[]): void {
    //     // attacker.attack(defenders);

    //     // const myCharacter = this.mainCharacter.character;
    //     // const myAttack = myCharacter.getAttack();
    //     // const myDefense = myCharacter.getDefense();
    //     // const myAbility = myCharacter.getAbility(AbilityName.Strength);

    //     // const enemyCharacter = defender.character;
    //     // const enemyAttack = enemyCharacter.getAttack();
    //     // const enemyDefense = enemyCharacter.getDefense();
    //     // const enemyAbility = enemyCharacter.getAbility(AbilityName.Strength);

    //     // const myDamage = myAttack - enemyDefense;
    //     // const enemyDamage = enemyAttack - myDefense;

    //     // console.log(`我方攻击力: ${myAttack}, 防御力: ${myDefense}, 力量: ${myAbility.value}`);
    //     // console.log(`敌方攻击力: ${enemyAttack}, 防御力: ${enemyDefense}, 力量: ${enemyAbility.value}`);
    //     // console.log(`我方造成伤害: ${myDamage}, 敌方造成伤害: ${enemyDamage}`);

    //     // if (myDamage > enemyDamage) {
    //     //     console.log('我方胜利');
    //     // } else if (myDamage < enemyDamage) {
    //     //     console.log('敌方胜利');
    //     // } else {
    //     //     console.log('平局');
    //     // }
    // }

}
