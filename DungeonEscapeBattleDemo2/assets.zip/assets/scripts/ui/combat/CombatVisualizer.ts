import { _decorator, Component, Node, Vec3, tween, UIOpacity, UITransform } from 'cc';
import { TeamMember } from './TeamMember';
import { CounterComponent } from '../../tools/CounterComponent';
import { FloatingTextComponent } from '../../tools/FloatingTextComponent';
import { ParticleEffectComponent } from '../../test/ParticleEffectComponent';
import { TipClipsAnimation } from '../../managers/TipClipsAnimation';
import { EventManager } from '../../managers/EventManager';
import { HitCheckCounter } from '../../tools/HitCheckCounter';
import { CombatControllerEvent } from './CombatController';
const { ccclass, property } = _decorator;

@ccclass('CombatVisualizer')
export class CombatVisualizer extends Component {

    @property(Node)
    blocker: Node = null;

    @property(Node)
    layout: Node = null;

    @property(Node)
    resultSuccessTip: Node = null;

    @property(Node)
    resultFailTip: Node = null;

    @property(Node)
    hitLayout: Node = null;

    @property(HitCheckCounter)
    counter: HitCheckCounter = null;

    protected start(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.position = Vec3.ZERO;
        this.node.active = false;
    }

    async delayAsync(timeSec: number): Promise<void> {
        return new Promise<void>((resolve) => {
            this.scheduleOnce(() => {
                resolve();
            }, timeSec);
        });
    }

    async showCombat(team1Fighters: TeamMember[], team2Fighters: TeamMember[], attackDirection: number, weaponIndex: number): Promise<void> {
        var attacker: TeamMember, defender: TeamMember;
        if (attackDirection > 0) {
            attacker = team1Fighters[0];
            defender = team2Fighters[0];
        } else {
            attacker = team2Fighters[0];
            defender = team1Fighters[0];
        }

        // 進入戰鬥演示模式 (血條會先隱藏)
        attacker.startFight();
        defender.startFight();

        this.blocker.active = true;
        this.resultSuccessTip.active = false;
        this.resultFailTip.active = false;

        const blockerOpacity = this.blocker.getComponent(UIOpacity);
        blockerOpacity.opacity = 0;
        tween(blockerOpacity)
            .to(0.25, { opacity: 185 }, { easing: 'linear' })
            .start();

        // todo teamIndex 可以用來判斷距離敵人的遠近
        // character.teamIndex

        team1Fighters.forEach(fighter => {
            fighter.node.parent = this.layout;
            fighter.node.setPosition(new Vec3(-200, 0, 0));
        });
        team2Fighters.forEach(fighter => {
            fighter.node.parent = this.layout;
            fighter.node.setPosition(new Vec3(200, 0, 0));
        });

        const { bonusHitRolls, extraHitRolls, totalDamageRolls, affixEffects, attackHitRoll, weaponProficiencyBonus } = attacker.attack(defender, weaponIndex);

        if (affixEffects.stun > 0) {
            console.log('要處理眩暈的特效');
            affixEffects.stun--;//todo 處理數值變化不要做在動畫這邊

            tween(attacker.node)
                .to(0.5, { position: new Vec3(-220*attackDirection, 0, 0) }, { easing: 'bounceInOut' })
                .start();

            await new Promise((resolve) => this.scheduleOnce(resolve, 1));
            EventManager.instance.emit(CombatControllerEvent.EndCombat);

            return;//中斷效果
        }

        if (attackHitRoll.isFull) {
            console.log('要處理爆骰的特效');
        }

        // 1. 骰武器熟練命中        
        this.counter.node.parent = this.hitLayout;
        if (attackDirection < 0) {// todo 這邊先這樣，怪物是演的時候才骰，也可以拉出來先做

            this.counter.checkType = 'Neutral';
            this.counter.count = attackHitRoll.roll;
            this.counter.counterEffect();
            await this.delayAsync(0.25);
        }

        if (weaponProficiencyBonus > 0) {
            this.counter.addCount(weaponProficiencyBonus, '武器熟練加值');
            await this.delayAsync(0.5);
        }

        // 2. 先做個命中前的蓄力動畫，然後把它加進命中加值
        // if (affixEffects.hitBonus > 0) {
        if (bonusHitRolls.length > 0) {
            tween(attacker.node)
                .to(0.25, { position: Vec3.ZERO }, { easing: 'quadOut' })
                .call(() => {
                    const particle = attacker.getComponentInChildren(ParticleEffectComponent);
                    particle?.setupEffect();
                    particle?.playEffect();
                })
                .start();
            await this.delayAsync(0.25);

            // 顯示命中加值動畫
            for (let i = 0; i < bonusHitRolls.length; i++) {
                console.log('bonusHitRolls[', i, ']:', bonusHitRolls[i]);
                this.counter.addCount(bonusHitRolls[i], '命中加值');
                await this.delayAsync(0.25);
            }
            await this.delayAsync(1 + bonusHitRolls.length * 0.25);

            tween(attacker.node)
                .to(0.15, { position: new Vec3(-200 * attackDirection, 0, 0) }, { easing: 'quadOut' })
                .start();
        }

        // 3. 開始進攻，動畫演出
        var centerPos = new Vec3(0, 0, 0);

        // todo: 先做進攻攻擊動畫示意，之後改為投影片播放
        for (let i = 0; i < extraHitRolls.length; i++) {
            await this.battle1(team1Fighters[0], team2Fighters[0], attackDirection, centerPos);
            console.log('extraHitRolls[', i, ']:', extraHitRolls[i]);
            this.counter.addCount(extraHitRolls[i], '額外命中');
        }
        extraHitRolls.length = 0;

        await this.delayAsync(0.5);

        // 4. 執行傷害結果
        const damageResult = defender.resultDamage();
        console.log('damageResult:', damageResult);

        // 防守方反應
        const { dodgeCounterattackDamageValue, counterattackDamageValue } = defender.reaction(attacker);

        console.log('閃避反擊:', dodgeCounterattackDamageValue, '復仇:', counterattackDamageValue);
        // 臨時生命
        const tempHP = defender.getTempHP();

        if (damageResult > 0) {
            this.resultSuccessTip.active = true;
            tween(this.resultSuccessTip)
                .to(0.25, { scale: new Vec3(1.2, 1.2, 1) })
                .to(0.25, { scale: Vec3.ONE })
                .start();

            // 顯示傷害擲骰結果
            let damageCallback = null;
            console.log('totalDamageRolls:', totalDamageRolls);
            if (totalDamageRolls.length > 0) {
                var aac = defender.getComponentInChildren(TipClipsAnimation);
                // await aac.spreadCards(totalDamageRolls.map(x => x.toString()));
                // todo 這個傷害的分片動畫，可以的話想做成骰子丟出的樣子。
                // 如果可以的話，想做成丟出後變成擲骰結果，然後裝填在下方一列顯示傷害
                // 最後飛入同一點變成傷害的加總顯示
                damageCallback = () => aac.spreadCards(totalDamageRolls.map(x => x.toString()));
            }

            await this.battleSuccess(team1Fighters[0], team2Fighters[0], attackDirection, centerPos, damageCallback);

            // 攻擊誰，誰要損血
            // defender.changeHpBar(Math.min(0,-damageResult+tempHP));
            defender.changeHpBar(-damageResult);

            await this.delayAsync(1.5);

            // 未命中觸發反應的事件，這邊才處理扣血 (因為想做QTE系統，而且不會知道是誰會攻擊自己，不能預先把反擊的傷害算好)
            if (counterattackDamageValue) {
                centerPos = new Vec3(0, 0, 0);
                let counterattackCallback = () => attacker.getComponentInChildren(TipClipsAnimation).spreadCards([counterattackDamageValue.toString()]);
                // todo team1Fighters 之後改非陣列
                await this.battleSuccess(defender, attacker, -attackDirection, centerPos, counterattackCallback);

                attacker.changeHpBar(-counterattackDamageValue);
                attacker.resultDamage();

                await this.delayAsync(1.5);

            }

        } else {
            this.resultFailTip.active = true;
            tween(this.resultFailTip)
                .to(0.25, { scale: new Vec3(1.2, 1.2, 1) })
                .to(0.25, { scale: Vec3.ONE })
                .start();

            await this.battleFail(team1Fighters[0], team2Fighters[0]);

            // 命中觸發反應的事件
            if (dodgeCounterattackDamageValue) {
                centerPos = new Vec3(0, 0, 0);
                let counterattackCallback = () => attacker.getComponentInChildren(TipClipsAnimation).spreadCards([dodgeCounterattackDamageValue.toString()]);
                // todo team1Fighters 之後改非陣列
                await this.battleSuccess(defender, attacker, -attackDirection, centerPos, counterattackCallback);

                attacker.changeHpBar(-dodgeCounterattackDamageValue);
                attacker.resultDamage();

                await this.delayAsync(1.5);

            }
        }

        await new Promise((resolve) => this.scheduleOnce(resolve, 1));
        EventManager.instance.emit(CombatControllerEvent.EndCombat);
    }

    // 隱藏命中成功/失敗的提示
    closeHitTips(): void {
        this.resultSuccessTip.active = false;
        this.resultFailTip.active = false;
    }

    addHitBouns(attacker: TeamMember, attckDirection: number = 1): Promise<void> {
        return new Promise(resolve => {

            tween(attacker.node)
                .to(0.25, { position: Vec3.ZERO }, { easing: 'quadOut' })
                .delay(1)
                .to(0.15, { position: new Vec3(-200, 0, 0) }, { easing: 'quadOut' })
                .call(() => {
                    resolve();
                })
                .start();

        });
    }

    battle1(attacker: TeamMember, defender: TeamMember, attckDirection: number = 1, centerPos: Vec3 = new Vec3(0, 0, 0)): Promise<void> {
        return new Promise(resolve => {

            const attackerPosition = centerPos.clone();
            const defenderPosition = centerPos.clone();
            const delay = 0.05;

            tween(attacker.node)
                .to(0.25, { position: attackerPosition.add(new Vec3(-200, 0, 0)) }, { easing: 'quadOut' })
                .delay(delay)
                .by(0.15, { position: new Vec3(120, 0, 0) }, { easing: 'quadIn' })
                .by(0.15, { position: attackerPosition }, { easing: 'quadOut' })
                .call(() => {
                    centerPos.add(new Vec3(10 * attckDirection, 0, 0));
                    // 攻擊者決定結束時間
                    resolve();
                })
                .start();

            tween(defender.node)
                .to(0.25, { position: defenderPosition.add(new Vec3(200, 0, 0)) }, { easing: 'quadOut' })
                .delay(delay)
                .by(0.15, { position: new Vec3(-120, 0, 0) }, { easing: 'quadIn' })
                .by(0.15, { position: defenderPosition }, { easing: 'quadOut' })
                .start();

        });
    }

    battleFail(attacker: TeamMember, defender: TeamMember): Promise<void> {
        return new Promise(resolve => {

            tween(attacker.node)
                .to(0.15, { position: new Vec3(0, 0, 0) }, { easing: 'linear' })
                .to(0.25, { position: new Vec3(-200, 0, 0) }, { easing: 'quadIn' })
                .call(() => {
                    resolve();
                })
                .start();

            tween(defender.node)
                .to(0.15, { position: new Vec3(0, 0, 0) }, { easing: 'linear' })
                .to(0.25, { position: new Vec3(200, 0, 0) }, { easing: 'quadIn' })
                .start();

        });
    }

    battleSuccess(attacker: TeamMember, defender: TeamMember, attckDirection: number = 1, centerPos: Vec3 = new Vec3(0, 0, 0), callback: Function = null): Promise<void> {
        return new Promise(resolve => {

            const attackerPosition = centerPos.clone();
            const defenderPosition = centerPos.clone();

            if (attckDirection > 0) {
                tween(attacker.node)
                    .to(0.15, { position: new Vec3(-200, 0, 0) }, { easing: 'linear' })
                    .by(0.15, { position: new Vec3(220, 0, 0) }, { easing: 'quadIn' })
                    .start();

                tween(defender.node)
                    .to(0.25, { position: defenderPosition.add(new Vec3(100, 0, 0)) }, { easing: 'quadOut' })
                    .parallel(
                        tween(defender.node).by(0.15, { position: new Vec3(80, 0, 0) }, { easing: 'quadIn' }),
                        tween(defender.node).to(0.25, { angle: -45 * attckDirection }, { easing: 'linear' })
                    )
                    .call(() => {
                        callback?.();
                    })
                    .delay(1.25)//跟callback 綁，所以這邊要再想辦法處理，而不是硬塞個delay
                    .to(0.25, { angle: 0 }, { easing: 'linear' })
                    .call(() => {
                        // 噴完血再結束時間
                        resolve();
                    })
                    .start();
            } else {
                tween(attacker.node).to(0.25, { position: defenderPosition.add(new Vec3(-100, 0, 0)) }, { easing: 'quadOut' })
                    .parallel(
                        tween(defender.node).by(0.15, { position: new Vec3(-80, 0, 0) }, { easing: 'quadIn' }),
                        tween(defender.node).to(0.25, { angle: 45 }, { easing: 'linear' })
                    )
                    .to(0.25, { angle: 0 }, { easing: 'linear' })
                    .call(() => {
                        // 噴完血再結束時間
                        resolve();
                    }).start();

                tween(defender.node)
                    .to(0.15, { position: new Vec3(200, 0, 0) }, { easing: 'linear' })
                    .by(0.15, { position: new Vec3(-220, 0, 0) }, { easing: 'quadIn' })
                    .start();

            }
        });
    }
}