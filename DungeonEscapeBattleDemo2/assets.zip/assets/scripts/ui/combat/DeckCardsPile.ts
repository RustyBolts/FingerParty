import { Component, _decorator, Node, Vec3 } from "cc";
import { CardMover } from "../../tools/CardMover";
import { EventManager } from "../../managers/EventManager";
import { CombatCard } from "../../cards/Card";
import { DeckPileEvent, PlayerHandCardEvent } from "../../managers/GameEvents";
import DeckCards from "./DeckCards";

const { ccclass, property } = _decorator;

@ccclass('DeckCardsPile')
export default class DeckCardsPile extends Component {
    @property(Node)
    private deckPile: Node = null;
    private deckCardsPile;

    @property(Node)
    private deckGatherings: Node = null;

    @property(Node)
    private deckDiscard: Node = null;

    private cards: CombatCard[] = [];

    protected onLoad(): void {
        EventManager.instance.on(DeckPileEvent.ShowCards, this.onShowCards, this);
        // EventManager.instance.on(DeckPileEvent.DeckGatherings, this.onDeckGatherings, this);
        // EventManager.instance.on(DeckPileEvent.DiscardCards, this.onDiscardCards, this);
        EventManager.instance.on(DeckPileEvent.DealPlayerCards, this.onDealPlayerCards, this);
        // EventManager.instance.on(DeckPileEvent.HideCards, this.eventHideCards, this);

        this.deckCardsPile = this.deckPile.getComponentsInChildren(DeckCards);
    }

    protected onDestroy(): void {
        EventManager.instance.off(DeckPileEvent.ShowCards, this.onShowCards, this);
        // EventManager.instance.off(DeckPileEvent.DeckGatherings, this.onDeckGatherings, this);
        // EventManager.instance.off(DeckPileEvent.DiscardCards, this.onDiscardCards, this);
        EventManager.instance.off(DeckPileEvent.DealPlayerCards, this.onDealPlayerCards, this);
        // EventManager.instance.off(DeckPileEvent.HideCards, this.eventHideCards, this);
    }

    protected start(): void {
        this.node.position = Vec3.ZERO;
    }

    /**
     * 顯示卡牌牌組
     * @param cards 卡牌陣列
     */
    showdDeckPile(cards: CombatCard[]): void {
        this.cards = cards;

        // 顯示依花色分類好的卡牌牌組
        this.deckCardsPile.forEach((cardDisplay: DeckCards, suitIndex: number) => {
            cardDisplay.initPositionNodes(cards.length);
            cardDisplay.doShowCard(cards);
            cardDisplay.setToggleSelection();
            cardDisplay.followPosition();
        });
    }

    // 卡牌收至 deckGatherings 節點上的動畫
    async collectAllCardsToDeckGatherings(): Promise<void> {
        for (const cardDisplay of this.deckCardsPile) {
            const cardNodes = cardDisplay.getCardContentNodes().slice();
            for (const cardNode of cardNodes) {
                await CardMover.moveCard(cardNode, this.deckGatherings, Vec3.ZERO);
            }
        }

        // 延遲後繼續流程，讓動畫跑完
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.25));

        // 隱藏牌匣
        this.deckCardsPile.forEach((cardDisplay) => cardDisplay.node.active = false);
    }

    //#region 接收事件

    onShowCards(event: any): void {
        this.node.active = true;

        this.deckGatherings.removeAllChildren();
        this.deckDiscard.removeAllChildren();

        const cards: CombatCard[] = event;
        this.showdDeckPile(cards);

        this.collectAllCardsToDeckGatherings();
    }

    // 把展示狀態的卡牌都放入牌庫位置 todo deckGatherings 改成 deck，原本的 deck 改成 demoArea
    async onDeckGatherings(): Promise<void> {
        this.node.active = true;

        for (const cardNode of this.deckDiscard.children.slice()) {
            // console.log('收到卡牌');
            // console.log('1this.deckDiscard.children:', this.deckDiscard.children.length);
            await CardMover.moveCard(cardNode, this.deckGatherings, Vec3.ZERO);
        }
        // console.log('2this.deckDiscard.children:', this.deckDiscard.children.length);
        // console.log('this.deckGatherings.children:', this.deckGatherings.children.length);
        // todo 查一下數量，確保卡牌內容是正確的

        // 延遲後繼續流程，讓動畫跑完
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.25));

        console.log('重洗');
        // 先用nextround
        // EventManager.instance.emit(GameLogicEvent.GameRoundNextPlayerTurn);
    }

    // 發玩家手牌
    onDealPlayerCards(event): void {
        const length: number = event;

        if (this.cards.length < length) {
            // 重新洗牌
            EventManager.instance.emit('ShuffleDeckRequest');
            return;
        }

        EventManager.instance.emit(PlayerHandCardEvent.DealCards, {
            cards: this.cards.splice(0, length),
            deckGatherings: this.deckGatherings
        });
    }

    // 卡牌隱藏
    eventHideCards(event): void {
        this.node.active = false;
    }

    //#endregion

    //#region 點擊事件

    onDiscardClicked() {
        var selectedCards = [];

        // 取得所有被選擇的卡牌
        this.deckCardsPile.forEach((cardDisplay) => {
            if (cardDisplay.confirmSelection()) {
                // 棄牌
                cardDisplay.discardSelectedCards();

                // 取得被選擇的卡牌
                selectedCards = selectedCards.concat(cardDisplay.getSelectedCards());
            }
        });

        // 若沒有被選擇的卡牌，則不做任何事
        if (selectedCards.length == 0) {
            return;
        }

        // 通知: 丟棄被選擇的卡牌
        // EventManager.instance.emit(GameLogicEvent.GameRoundStartDiscardCards, selectedCards);
    }

    //#endregion
}
