import { _decorator, Node, Vec3 } from "cc";
import { EventManager } from "../../managers/EventManager";
import { CombatCard } from "../../cards/Card";
import { CardMover } from "../../tools/CardMover";
import { PlayerHandCardEvent } from "../../managers/GameEvents";
import { CombatSkill } from "../../dungeon/combat/CombatSkill";
import { CardComponent } from "./CardComponent";
import { BaseCardDisplay } from "../../cards/BaseCardDisplay";
import { EffectManager } from "../../managers/EffectManager";
import { TipType } from "../../tools/TipText";

const { ccclass, property } = _decorator;
// caombat
@ccclass('PlayerHandCards')
export default class PlayerHandCards extends BaseCardDisplay {

    // combatSkill: CombatSkill = null;
    @property(Node)
    discardPile: Node = null;

    selectMax: number = 2;
    selectNum: number = 0;

    protected onLoad(): void {
        EventManager.instance.on(PlayerHandCardEvent.DealCards, this.onDealCards, this);
        // EventManager.instance.on(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
        // EventManager.instance.on(PlayerHandCardEvent.SendCards, this.onSendCards, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(PlayerHandCardEvent.DealCards, this.onDealCards, this);
        // EventManager.instance.off(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
        // EventManager.instance.off(PlayerHandCardEvent.SendCards, this.onSendCards, this);
    }

    protected start(): void {
        this.node.active = false;
    }

    dealCard(index: number, cardNode: Node): Promise<void> {
        const delaySec = 0.15;
        const position = this.positionContainer.children[index].position;
        return CardMover.moveCard(cardNode, this.cardContainer, position, delaySec * 2, (index + 1) * delaySec);
    }

    dealCards(cards: CombatCard[], deckGatherings: Node): void {
        this.node.active = true;
        this.updatePositionLayout();

        const gatheringNodes = deckGatherings.children;
        cards.forEach(async (card, index) => {
            const cardNode = gatheringNodes[gatheringNodes.length - 1];
            cardNode.getComponent(CardComponent).setup(card);
            await this.dealCard(index, cardNode);
        });

        this.stopToggleSelection();
        this.setToggleSelection(this.checkCardSelected.bind(this));

        this.selectNum = this.selectMax;
    }

    checkCardSelected(): void {
        if (this.selectedCardNodes.length > this.selectNum) {
            EventManager.instance.emit(TipType.Warning, '玩家回合\n您最多只能選擇' + this.selectMax + '張卡牌出牌');
        } else {
            EventManager.instance.emit(TipType.Normal, '玩家回合');
        }
    }

    async sendCards(): Promise<void> {
        const combatCards: CombatCard[] = [];
        for (const cardNode of this.selectedCardNodes) {
            const card: CombatCard = cardNode.getComponent(CardComponent).card;
            console.log('card', card);
            combatCards.push(card);

            await CardMover.moveCard(cardNode, this.discardPile, Vec3.ZERO, 0.05, 0.15);
        }

        await new Promise((resolve) => this.scheduleOnce(resolve, 0.1));

        const cardNodes = this.cardContainer.children.slice();
        cardNodes.forEach(async (cardNode) => {
            await CardMover.moveCard(cardNode, this.discardPile, Vec3.ZERO, 0.05, 0.15);
        });

        await new Promise((resolve) => this.scheduleOnce(resolve, 0.5));

        EventManager.instance.emit('ExecuteIntent', combatCards);

        this.selected.length = 0;
        this.selectedCardNodes.length = 0;

        this.stopToggleSelection();
    }

    onDealCards(event): void {
        const cards: CombatCard[] = event.cards;
        const deckGatherings: Node = event.deckGatherings;
        this.initPositionNodes(cards.length);
        this.dealCards(cards, deckGatherings);
    }

    onSendCards() {
        this.sendCards();
    }

    //#endregion

    //#region 按鈕事件

    async onSubmitSelectedClicked(): Promise<void> {
        if (this.selectedCardNodes.length === 0) {
            EventManager.instance.emit(TipType.Warning, '玩家回合\n請選擇卡牌');
            return;
        }

        if (this.selectedCardNodes.length > this.selectNum) {
            EventManager.instance.emit(TipType.Error, '玩家回合\n能量不足，最多只能選擇' + this.selectMax + '張卡牌');
            return;
        }

        await this.sendCards();

        console.log('提交選擇');
        EventManager.instance.emit('SubmitSelectedCards');//把選出的牌丟到棄牌堆
    }

    //#endregion
}