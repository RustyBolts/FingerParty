import { _decorator, Component, Vec3, Node, UIOpacity, tween, randomRangeInt } from 'cc';
import { TeamMember } from './TeamMember';
import { EventBus } from '../../managers/EventSystem';
import { CardMover } from '../../tools/CardMover';
import { ArcherySkill } from '../../dungeon/combat/ArcherySkill';
import { EventManager } from '../../managers/EventManager';
import { DeckPileEvent, PlayerHandCardEvent } from '../../managers/GameEvents';
import { EffectManager } from '../../managers/EffectManager';
import { CombatCard } from '../../cards/Card';
import { CounterComponent } from '../../tools/CounterComponent';
import { CardReward } from '../reward/CardReward';
import { HitCheckCounter } from '../../tools/HitCheckCounter';
import { UIEvent } from '../../managers/UIManager';
import { CombatControllerEvent } from './CombatController';
import { MeleeSkill } from '../../dungeon/combat/MeleeSkill';
import { CombatSkill } from '../../dungeon/combat/CombatSkill';
import { TipType } from '../../tools/TipText';
const { ccclass, property } = _decorator;

@ccclass('CombatOption')
export class CombatOption extends Component {
    @property(Node)
    blocker: Node = null;

    @property(Node)
    layout: Node = null;

    @property(Node)
    hitLayout: Node = null;

    @property(HitCheckCounter)
    counter: HitCheckCounter = null;

    @property(CardReward)
    cardReward: CardReward = null;

    eventBus: EventBus = null;

    myTeamCharacter: TeamMember = null;
    combatSkill: MeleeSkill = null;//todo CombatSkill = null;

    _deck: CombatCard[] = [];//todo 之後再補資料結構

    protected onLoad(): void {
        // EventManager.instance.on('CloseCombatOption', this.close, this);
        EventManager.instance.on('ExecuteIntent', this.onExecuteIntent, this);
        EventManager.instance.on('ShuffleDeckRequest', this.shuffleDeckRequest, this);
        // EventManager.instance.on('StartDealCards', this.dealCards, this);
        EventManager.instance.on('ChoiceCard', this.onChoiceCard, this);
        EventManager.instance.on('SelectedRewardCard', this.onSelectedRewardCard, this);
        // EventManager.instance.on('ReactionIntent', this.onReactionIntent, this);

        // this.counter.node.active = false;
    }

    protected onDestroy(): void {
        // EventManager.instance.off('CloseCombatOption', this.close, this);
        EventManager.instance.off('ExecuteIntent', this.onExecuteIntent, this);
        EventManager.instance.off('ShuffleDeckRequest', this.shuffleDeckRequest, this);
        // EventManager.instance.off('StartDealCards', this.dealCards, this);
        EventManager.instance.off('ChoiceCard', this.onChoiceCard, this);
        EventManager.instance.off('SelectedRewardCard', this.onSelectedRewardCard, this);
        // EventManager.instance.off('ReactionIntent', this.onReactionIntent, this);
    }

    protected start(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        // this.node.position = Vec3.ZERO;
        this.node.active = false;

        //test 這個之後再改成統一在 characterInfo 的 _combatSkills 裡面暫存
        // 依角色技能產生相應卡牌
        this.combatSkill = new MeleeSkill(1, '近戰技能', this.eventBus);//todo 從 mainCharacter 取得技能
        this.initDeck(1);
    }

    init(eventBus: EventBus, mainCharacter: TeamMember): void {
        this.eventBus = eventBus;
        this.myTeamCharacter = mainCharacter;

        // 角色職業

        // 加入牌庫並洗牌
        this.shuffleDeck();
        EventManager.instance.emit(DeckPileEvent.ShowCards, this._deck.slice());
    }

    initDeck(skillLevel: number): void {

        this._deck.length = 0;
        const cardSource: CombatCard[] = this.combatSkill.getSkill(0);
        // const cardLength = cardSource.length;
        // for (let i = 0; i < 10; i++) {// todo 學殺戮尖塔，一開始10張卡片。殺戮尖塔5攻擊4防禦1技能
        //     this._deck.push(cardSource[randomRangeInt(0, cardLength)]);
        // }
        this._deck = cardSource.slice();
    }

    shuffleDeckRequest(): void {
        this.shuffleDeck();
        EventManager.instance.emit(DeckPileEvent.ShowCards, this._deck.slice());

        this.scheduleOnce(() => {
            console.log('shuffleDeckRequest 後開始發牌，6張');
            EventManager.instance.emit(DeckPileEvent.DealPlayerCards, 6);
        }, 1);
    }

    // dealCards(): void {
    //     EventManager.instance.emit(DeckPileEvent.DealPlayerCards, 6);
    // }

    /** 洗牌 */
    shuffleDeck(): void {
        for (let i = 0; i < this._deck.length; i++) {
            // const j = Math.floor(Math.random() * (i + 1));
            const j = randomRangeInt(0, i + 1);
            [this._deck[i], this._deck[j]] = [this._deck[j], this._deck[i]];
        }
    }

    async show(member: TeamMember): Promise<void> {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.position = Vec3.ZERO;
        this.node.active = true;

        // this.blocker.active = true;
        const blockerOpacity = this.blocker.getComponent(UIOpacity);
        blockerOpacity.opacity = 0;

        await CardMover.moveCard(member.node, this.layout, Vec3.ZERO);
        member.node.parent = this.layout;

        tween(blockerOpacity)
            .to(0.25, { opacity: 205 }, { easing: 'linear' })
            .call(() => {
                EventManager.instance.emit(DeckPileEvent.DealPlayerCards, 6);

                this.onRoundOver();// todo 聽事件來決定，正在考慮由玩家點擊"結束回合"來觸發

                if (this.myTeamCharacter.isAdvantage()) {
                    // 命中優勢骰
                    const hitRolls = this.myTeamCharacter.hits('Advantage').map(a => a.roll);
                    this.counter.node.parent = this.hitLayout;
                    this.counter.checkType = 'Advantage';
                    this.counter.count = hitRolls[0];
                    this.counter.count = hitRolls[1];

                } else {
                    // 預先骰命中，讓玩家決定怎麼安排
                    const hitRoll = this.myTeamCharacter.hit();
                    console.log('hitRoll', hitRoll);
                    this.counter.node.parent = this.hitLayout;
                    this.counter.count = hitRoll.roll;
                    this.counter.counterEffect();
                }

                //TEST
                this.myTeamCharacter.leaveCombatTeam();//todo 測試方便換武器


            })
            .start();
    }

    close() {
        this.node.active = false;
    }

    onRoundOver(): void {
        this.myTeamCharacter.roundOver();
    }

    async choiceCard(): Promise<void> {
        await this.cardReward.show(true);

        const cardSource: CombatCard[] = this.combatSkill.getSkill(1);
        this.cardReward.init(cardSource.sort(() => Math.random() - 0.5).slice(0, 5));
    }

    onExecuteIntent(combatCards: CombatCard[]): void {
        console.log('playCard', combatCards);
        // 執行技能效果
        this.myTeamCharacter.combatCardsToIntent(combatCards);
        this.myTeamCharacter.intent();
    }

    onSelectedRewardCard(event: any): void {
        const card: CombatCard = event;

        this._deck.push(card);
        console.log('卡片牌庫', this._deck);

        this.cardReward.show(false);

        // EventManager.instance.emit('battleStart');// 測試戰鬥用
        EventManager.instance.emit(UIEvent.DescriptionScrollViewShowUI, true);// 故事跑完後繼續

        EventManager.instance.emit(TipType.Hide);
    }

    // 做在 CombatVisualizer 裡面，視覺化的QTE 可以做在這邊
    // onReactionIntent(event: any):void {
    //     // 顯示QTE按鈕，時間內處理的話增加額外效果
    //     // todo 目前先不做，等測試後再確定要不要做

    //     // 觸發反應，處理玩家的反擊、臨時生命等效果
    //     this.myTeamCharacter.reactionAsync();
    // }

    onChoiceCard(): void {
        this.choiceCard();
    }

    //#region 按鈕事件

    // onSubmitSelectedClicked(): void {
    //     this.submitSelectedCards();
    //     console.log('提交選擇');
    // }

    //#endregion
}