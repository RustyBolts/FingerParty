import { _decorator, Component, Node, Layout, Prefab, instantiate, Vec3, tween, Label, Sprite, resources, SpriteFrame, randomRangeInt, Texture2D } from 'cc';
import { CombatCharacter } from '../../dungeon/combat/CombatCharacter';
import { Character } from '../../dungeon/Character';
import { CombatMonster } from '../../dungeon/combat/CombatMonster';
import { CombatEntity } from '../../dungeon/combat/CombatEntity';
import { EventManager } from '../../managers/EventManager';
import { CombatSkill } from '../../dungeon/combat/CombatSkill';
import { EffectManager } from '../../managers/EffectManager';
import { CombatCard } from '../../cards/Card';
import { CombatWeapon } from '../../dungeon/combat/CombatWeapon';
import { BaseAbilities, Attribute, CompositeAbilities } from '../../dungeon/Ability';
import { HitPointsBarComponent } from '../character/HitPointsBarComponent';
import { CombatIntent } from '../../dungeon/combat/CombatIntent';
import { Damage, Weapon, WeaponProperty } from '../../dungeon/item/Weapon';
import { Armor } from '../../dungeon/item/Armor';
import { Shield } from '../../dungeon/item/Shield';
import { CombatArmor } from '../../dungeon/combat/CombatArmor';
import { CheckType } from '../../tools/HitCheckCounter';
import { EquipmentDropZoneIndex } from '../../dungeon/inventory/EquipmentDropZone';
import { CombatControllerEvent } from './CombatController';
const { ccclass, property } = _decorator;

@ccclass('TeamMember')
export class TeamMember extends Component {

    @property(HitPointsBarComponent)
    hitPointsBar: HitPointsBarComponent = null;

    @property(Node)
    selectButton: Node = null;

    @property(Label)
    nameLabel: Label = null;
    @property(Label)
    acLabel: Label = null;
    @property(Label)
    atLabel: Label[] = [];
    @property(Label)
    initiativeLabel: Label = null;

    @property(Label)
    intentLabel: Label = null;
    @property(Label)
    characterInfoLabel: Label = null;// todo 這邊是提示資訊用的，角色的所有資訊都會放這邊，看是否之後改成用通知的方式通一在介面上顯示

    @property(Node)
    weaponLayout: Node = null;

    @property(Node)
    equipmentLayout: Node = null;

    @property(Sprite)
    photo: Sprite = null;

    private combatEntity: CombatEntity;

    movement: number[];// 移動能力, [剩餘移動能力, 最大移動能力]
    // combatSkills: CombatSkill[];// 戰鬥技能

    teamIndex: number;// 隊伍站位索引
    // 先攻值
    initiative: number = 0;

    camp: number = 0; // 陣營 0我方 1敵方

    // combatWeapons: CombatWeapon[] = [];
    // 暫存武器熟練加值
    weaponProficiencyAbilities: BaseAbilities = {
        [Attribute.Strength]: 0,
        [Attribute.Dexterity]: 0,
        [Attribute.Intelligence]: 0,
        [Attribute.Wisdom]: 0,
        [Attribute.Charisma]: 0,
        [Attribute.Resilience]: 0
    };

    // 裝備護甲，包含一般的裝甲跟盾牌
    // combatArmors: CombatArmor[] = [];

    get isDead() {
        return this.combatEntity.isDead;
    }

    protected onLoad(): void {

    }

    joinCombatTeam(): void {
        this.weaponLayout.active = false;
        this.equipmentLayout.active = false;
    }

    leaveCombatTeam(): void {
        this.weaponLayout.active = true;
        this.equipmentLayout.active = true;
    }

    characterInitial(character: Character): void {
        this.movement = [character.movement, character.movement];

        // 取得玩家的熟練度加成
        const proficiencyAbilities = character.calculateProficienciesBonus();

        // 總和能力 體質、精神與意志
        const compositeAbilities = character.calculateCompositeAbilities();

        console.log('計算所有能力的熟練加值:', proficiencyAbilities);
        console.log('計算各能力屬性對應的綜合屬性:', compositeAbilities);

        const name = character.name;

        this.combatEntity = new CombatCharacter(name, compositeAbilities, proficiencyAbilities, character.weaponProficiencies);

        this.setInfos(name, compositeAbilities);

        this.selectButton.off('click');
        this.selectButton.on('click', this.onSelectCharacterClicked, this);

        this.camp = 0;
    }

    monsterInitial(name: string, compositeAbilities: CompositeAbilities, armorClass: number): void {
        this.combatEntity = new CombatMonster(name, compositeAbilities, armorClass, 1);

        this.setInfos(name, compositeAbilities);

        this.selectButton.off('click');
        this.selectButton.on('click', this.onSelectMonsterClicked, this);

        this.camp = 1;
    }

    setInfos(name: string, compositeAbilities: CompositeAbilities) {
        this.nameLabel.string = name;

        this.updateInfo();
        this.setPhotoImage(name);

        this.hitPointsBar.defaultHp = compositeAbilities.constitution;
    }

    updateInfo():void {
        this.acLabel.string = `AC ${this.combatEntity.ac}`;
        this.atLabel[0].string = '';
        this.atLabel[1].string = '';

    }

    // 計算先攻值
    rollInitiativeOrder(dexterity: number): void {
        this.combatEntity.resetBonuses();//todo 先偷放這邊，讓戰鬥初始化時重置

        this.initiative = dexterity + randomRangeInt(1, 20);
        this.initiativeLabel.string = `先攻:${this.initiative}`;
    }

    enableSelect() {
        this.selectButton.active = true;
    }

    disableSelect() {
        this.selectButton.active = false;
    }

    setPhotoImage(imageName: string) {//todo 可以統一在 CombatEntity 裡面做
        // Load and set the sprite
        const sprite = this.photo.getComponent(Sprite);
        const imagePath = `maps/${imageName}/spriteFrame`;
        resources.load(imagePath, SpriteFrame, (err, spriteFrame) => {
            if (err) {
                console.error('Failed to load image: ' + err);
                return;
            }
            sprite.spriteFrame = spriteFrame;
            sprite.spriteFrame.texture.setFilters(Texture2D.Filter.NONE, Texture2D.Filter.NONE);
        });
    }

    //戰士	武術戰鬥的大師，掌握著一系列武器與護甲的使用技巧	d10	力量 或 敏捷	力量 & 體質	所有護甲，盾牌，簡易武器，軍用武器
    setWeapon(index: number, weapon: Weapon, proficiencyBonus: number = 0): void {
        if (weapon == null) {
            console.log(`清除武器${index}`, this.combatEntity);
            this.combatEntity?.unequipWeapon(index);
            // if (index === EquipmentDropZoneIndex.WeaponOrShield)
            this.atLabel[index].string = '';
            return;
        }

        // 武器上手，主手武器熟練 todo 要檢查是否有雙持客專長，這樣就算 index!== 0 也要加上武器熟練加值
        let weaponProficiency: number = 0;
        if (index === 0) {
            // 是否有武器熟練
            if (this.combatEntity.weaponProficiencies.includes(weapon.style)) {
                weaponProficiency = proficiencyBonus;
            }
        }
        console.log(`獲得武器${index}熟練加值:`, weaponProficiency, '/', proficiencyBonus);
        this.combatEntity.equipWeapon(index, weapon, weaponProficiency);
        this.atLabel[index].string = weapon.damage.dice;
    }

    setArmor(index: number, armor: Armor): void {
        if (armor)
            this.combatEntity.equipArmor(armor);
        else
            this.combatEntity.unequipArmor();
        this.acLabel.string = `AC ${this.combatEntity.ac}`;
    }

    setShield(index: number, shield: Shield): void {
        if (shield)
            this.combatEntity.equipShield(shield);
        else
            this.combatEntity.unequipShield();
        this.acLabel.string = `AC ${this.combatEntity.ac}`;
    }

    startFight() {
        this.initiativeLabel.string = '';
        console.log('開始戰鬥');
        this.hitPointsBar.node.active = false;
    }

    endFight() {
        console.log('結束戰鬥');
        this.hitPointsBar.node.active = true;
    }

    isAdvantage() {
        return this.combatEntity.isAdvantage;
    }

    // 執行卡牌轉意圖
    combatCardsToIntent(combatCards: CombatCard[]) {
        console.log('執行卡牌轉意圖combatCards:', combatCards);

        // this.combatEntity.resetBonuses();//TODO effectmanager 那邊也有，就小心一點

        const intent = this.combatEntity.combatIntent;
        intent.clearIntents();
        combatCards.forEach((combatCard: CombatCard) => {
            // 將卡牌效果轉換成意圖 todo 可以在選卡牌的時候， getCurrentTargetRestriction 來檢查是否target 一致，若不同則不可選取
            console.log('combatCard.modifiers length:', combatCard.modifiers.length);
            combatCard.modifiers.forEach((modifier) => {
                intent.addIntent(modifier, combatCard.target);
            });

            // 處理消費 todo 卡牌消耗的行動，如果可以在選卡牌時就能提示是否條件充足會更好
            const { type, fee } = combatCard.cost;
            console.log('this.combatEntity.actionPoints:', this.combatEntity.actionPoints);
            // 反應動作
            if (type === 'Reaction' && this.combatEntity.actionPoints[type] > 0) {
                console.log('反應卡');
                intent.setReactionIntent(combatCard.modifiers.slice());
                // this.combatEntity.actionPoints[type] -= fee;//todo 這邊消費還沒想好，用掉就會讓另一個反應的效果沒有動作消耗
            }
            // 附贈動作
            if (type === 'Bonus' && this.combatEntity.actionPoints[type] > 0) {
                // intent.setBonusIntent(combatCard.modifiers.slice());
                // this.combatEntity.actionPoints[type] -= fee;
            }
        });
    }

    intent(): void {
        // 意圖與武器有關時，把命中與傷害加成在意圖類別中處理
        // intent.executeIntents(this.combatWeapons);// todo 現在先設計武器相關的意圖，所以先做傳入武器的
        this.combatEntity.intent(this);
        this.hitPointsBar.tempHp = this.combatEntity.tempHP;
    }

    hit(): { roll: number } {
        return this.combatEntity.hit();
    }
    hits(checkType: CheckType): { roll: number }[] {
        this.combatEntity.isAdvantage = false;//todo 先偷放這邊，讓戰鬥初始化時重置
        if (checkType === 'Advantage')
            return this.combatEntity.advantageHit();
        if (checkType === 'Disadvantage')
            return this.combatEntity.disadvantageHit();
        return [this.hit()];
    }

    // attack(targets: TeamMember[]): { bonusHitRolls: number[], extraHitRolls: number[], totalDamageRolls: number[], affixEffects: { [key: string]: number }, attackHitRoll: { isFull: boolean, roll: number }, weaponProficiencyBonus: number } {
    // console.log('攻擊目標:', targets);
    // for (const target of targets) {
    //     this.combatEntity.attack(target.combatEntity);
    //     }
    attack(target: TeamMember, weaponIndex: number): { bonusHitRolls: number[], extraHitRolls: number[], totalDamageRolls: number[], affixEffects: { [key: string]: number }, attackHitRoll: { isFull: boolean, roll: number }, weaponProficiencyBonus: number } {
        if (this.combatEntity.affixEffects.stun > 0) {


            console.log('受到眩暈效果，無法攻擊');
            return this.combatEntity;
        }
        this.combatEntity.attack(target.combatEntity, weaponIndex);

        return this.combatEntity;
    }

    resultDamage(): number {
        // todo 這邊補顯示 intentContents，需要考慮統一顯示以及效果處理
        if (this.intentLabel) {
            console.log('this.combatEntity.intentContents:', this.combatEntity.intentContents);
            this.intentLabel.string = this.combatEntity.intentContents.join('\n');
        }
        return this.combatEntity.resultDamage();
    }

    getTempHP(): number {
        return this.combatEntity.tempHP;
    }

    // resultCounterattack(): number {
    //     return this.combatEntity.resultCounterattack();
    // }

    changeHpBar(amount: number) {
        this.hitPointsBar.node.active = true;
        var damageValue = amount + this.hitPointsBar.tempHp;
        this.hitPointsBar.tempHp = Math.max(0, damageValue);
        this.hitPointsBar.changeHp(Math.min(0, damageValue));
    }

    reaction(target: TeamMember): { dodgeCounterattackDamageValue: number, counterattackDamageValue: number } {
        const isReactionSuccess = this.combatEntity.reaction();
        console.log(this.combatEntity.name, '反應成功:', isReactionSuccess);
        if (isReactionSuccess) {

            const isCounterattackSuccess = this.combatEntity.counterattack(target.combatEntity);
            // if (isCounterattackSuccess) {

            // }
            console.log('反擊成功:', isCounterattackSuccess);
        }

        // 用完就歸零
        const { dodgeCounterattackDamageValue, counterattackDamageValue } = this.combatEntity;
        this.combatEntity.dodgeCounterattackDamageValue = 0;
        this.combatEntity.counterattackDamageValue = 0;

        return { dodgeCounterattackDamageValue, counterattackDamageValue };
    }

    showIntent() {
        console.log('顯示意圖');
        const monster: CombatMonster = this.combatEntity as CombatMonster;
        if (monster.intentContents.length === 0) {
            this.intentLabel.string = '';
            return;
        }
        if (this.intentLabel)
            this.intentLabel.string = monster.intentContents.join('\n');

        monster.intentContents.length = 0;
    }

    showCharacterInfo() {
        const character: CombatCharacter = this.combatEntity as CombatCharacter;
        if (character && this.characterInfoLabel) {
            this.characterInfoLabel.string = '';
            console.log('character.combatWeapons:', character.combatWeapons);
            character.combatWeapons.forEach((weapon, index) => {
                // this.atLabel[index].string = weapon.damage.dice;
                // WeaponProperty = 'Light' | 'Finesse' | 'Thrown' | 'Two-Handed' | 'Reach' | 'Heavy' | 'Ammunition' | 'Loading' | 'Special' | 'Versatile';
                var weaponProperties: string[] = [];
                weapon.properties.forEach((property) => {
                    // '射程. 可以被用來進行遠程攻擊的武器，都會在彈藥或投擲屬性後用括號標示射程。射程列有兩個數字。第一個是該武器的正常射程，第二個則代表著武器的長射程。當攻擊處於正常射程之外的目標時，你在該攻擊檢定上承受劣勢。你不能攻擊處於武器長射程之外的目標。'

                    switch (property) {
                        case 'Light':
                            weaponProperties.push('輕型武器小而易用，適合被用於雙武器戰鬥。');
                            break;
                        case 'Finesse':
                            weaponProperties.push('靈巧武器可以選擇在該次攻擊檢定和傷害骰中使用你的力量或敏捷調整值。這兩次擲骰必須使用相同的調整值。');
                            break;
                        case 'Thrown':
                            weaponProperties.push('投擲武器。投擲武器的攻擊力與命中值都較小型生物的攻擊力低。');
                            // weaponProperties.push('投擲. 如果一把武器具有投擲屬性，則你可以投擲此武器以進行一次遠程攻擊。如果該武器是一把近戰武器，則你在該攻擊檢定和傷害骰中使用與你用其進行近戰攻擊時相同的屬性調整值。舉例來說，若你投擲一把手斧，則你使用你的力量。但如果你投擲的是一把匕首，由於匕首具有靈巧屬性，因此你可以從你的力量或敏捷中擇一使用。');
                            break;
                        case 'Two-Handed':
                            // weaponProperties.push('雙手武器。雙手武器的攻擊力較大型生物的攻擊力高。');
                            weaponProperties.push('雙手. 此武器需要雙手使用。這個屬性只關聯於你使用此武器攻擊時，而非單純持握它的時候。');
                            break;
                        case 'Reach':
                            // weaponProperties.push('遠程武器。遠程武器的攻擊距離較大型生物的攻擊距離短。');
                            weaponProperties.push('觸及. 當你使用此武器攻擊時，此武器讓你的觸及距離增加5呎。這個屬性也影響你使用觸及武器進行藉機攻擊的觸及距離。');

                            break;
                        case 'Heavy':
                            weaponProperties.push('小型生物在使用重型武器進行攻擊時會承受劣勢。重型武器的尺寸和重量使它對小型生物而言太過龐大而無法有效使用。');
                            // weaponProperties.push('重型武器。重型武器的攻擊力較小型生物的攻擊力低。');
                            break;
                        case 'Ammunition':
                            // weaponProperties.push('彈藥武器。彈藥武器的攻擊力較小型生物的攻擊力低。');
                            weaponProperties.push('彈藥. 你只能在擁有該武器射擊所需要的彈藥時，才能使用具有彈藥屬性的武器進行一次遠程攻擊。每次你使用該武器攻擊，你消耗一發彈藥。從箭袋、盒子、或其他容器抽出彈藥被視為該攻擊的一部份。裝填單手武器需要一隻空手。在戰鬥結束後，你可以藉由花費一分鐘的時間搜索戰場，以拿回一半你所消耗掉的彈藥量。');

                            break;
                        case 'Loading':
                            // weaponProperties.push('裝填武器。裝填武器的攻擊力較小型生物的攻擊力低。');
                            weaponProperties.push('裝填. 由於裝填此武器所需的時間，當你使用動作、附贈動作、或反應以該武器射擊時，無論你原本可以進行幾次攻擊，你都只能用其射出一發彈藥。');
                            break;
                        case 'Special':
                            // weaponProperties.push('特殊武器。特殊武器的攻擊力較小型生物的攻擊力低。');
                            weaponProperties.push('特殊. 具有特殊屬性的武器有著獨特的規則以處理其使用，詳情請參閱該武器的描述（參見本段落中後述的「特殊武器」）。');

                            break;
                        case 'Versatile':
                            // weaponProperties.push('多功能武器。多功能武器的攻擊力較小型生物的攻擊力低。');
                            weaponProperties.push('可雙手. 此武器可以被單手或雙手使用。這個屬性後方所顯示括號內的傷害數值，代表著以雙手使用此武器進行一次近戰攻擊時的傷害。');
                            break;
                        default:
                            break;
                    }
                });

                if (weapon.name !== '拳擊') {
                    this.characterInfoLabel.string += `\n${weapon.name}： ${weaponProperties.join('\n')}`;
                }

                switch (weapon.damage.type) {
                    // case 'Unarmed':
                    //     this.characterInfoLabel.string += '\n徒手攻擊';
                    //     break;
                    case 'Bludgeoning':
                        this.characterInfoLabel.string += '\n此武器為鈍器攻擊';
                        break;
                    case 'Piercing':
                        this.characterInfoLabel.string += '\n此武器為穿刺攻擊';
                        break;
                    case 'Slashing':
                        this.characterInfoLabel.string += '\n此武器為揮砍攻擊';
                        break;
                }
            });

            if (character.combatArmor.isCasterArmor) {
                this.characterInfoLabel.string += '\n身著法衣，便於施法。AC 為敏捷加值。';
            } else if (character.combatArmor.isLightArmor) {
                this.characterInfoLabel.string += '\n身著輕甲，可靈活動作。AC 為敏捷加值，但上限為2。';
            } else if (character.combatArmor.armorClass > 10) {
                this.characterInfoLabel.string += '\n身著重甲，防禦力強，但在需要靈活動作時會直接失敗。';
            }

            if (character.combatArmor.shielded) {
                this.characterInfoLabel.string += '\n裝備盾牌可獲的2點AC(Armor Class)。';
            }
            // this.characterInfoLabel.string += character.infoContents.join('\n');
        }
    }

    move(distance: number): boolean {
        if (this.movement[0] >= distance) {
            this.movement[0] -= distance;
            return true;
        }
        return false;
    }

    roundOver() {
        // this.movement[0] = this.movement[1];//todo

        // todo 直接改好像不好，看能不能統一
        this.combatEntity.temporaryArmor = 0;
        this.combatEntity.tempHP = 0;
        // this.combatEntity.resetBonuses();
        this.hitPointsBar.tempHp = 0;

        // this.combatEntity.isAdvantage = false;
        // console.log('優勢回合結束');

        this.acLabel.string = `AC: ${this.combatEntity.ac}`;
    }

    onSelectCharacterClicked() {
        console.log('選擇角色');
        this.disableSelect();
        EventManager.instance.emit(CombatControllerEvent.SelectCharacter, this);
    }

    onSelectMonsterClicked() {
        console.log('選擇怪物');
        this.disableSelect();
        EventManager.instance.emit(CombatControllerEvent.SelectMonster, this);
    }
}