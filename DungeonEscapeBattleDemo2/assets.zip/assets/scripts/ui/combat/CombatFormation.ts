import { _decorator, Component, Node, Layout, Prefab, instantiate, Vec3, tween } from 'cc';
import { TeamMember } from './TeamMember';
const { ccclass, property } = _decorator;

@ccclass('CombatFormation')
export class CombatFormation extends Component {
    @property(Prefab)
    characterPrefab: Prefab = null; // 角色的Prefab

    @property(Node)
    frontRoot: Node = null; // 前排的Node

    @property(Node)
    backRoot: Node = null; // 後排的Node

    @property
    distanceBetweenRows = 20; // 前後排之間的距離

    @property
    distanceBetweenMembers = 5; // 角色之間的距離

    frontRow: Node[] = []; // 前排角色節點的實體陣列
    backRow: Node[] = []; // 後排角色節點的實體陣列

    teamMembers: TeamMember[][] = [[], []]; // 所有角色的陣列

    fighters: TeamMember[] = []; // 當前指定進入戰鬥演出的角色

    protected onLoad(): void {
        this.frontRow = this.frontRoot.children;
        this.backRow = this.backRoot.children;
    }

    addFrontMemeber(member: TeamMember) {
        // Member.movement -= this.distanceBetweenRows;

        const teamFront = this.teamMembers[0];
        teamFront.push(member);
        teamFront.forEach((member, index) => {
            member.teamIndex = index;
            member.node.parent = this.frontRow[index];
            member.node.setPosition(new Vec3(0, 0, 0));

            // member.node.parent.active = true;
        });
    }

    addBackMember(member: TeamMember) {
        // Member.movement -= this.distanceBetweenRows;

        const frontCount = this.frontRow.length;

        const teamBack = this.teamMembers[1];
        teamBack.unshift(member);
        teamBack.forEach((member, index) => {
            member.teamIndex = index + frontCount;
            member.node.parent = this.backRow[index];
            member.node.setPosition(new Vec3(0, 0, 0));

            // member.node.parent.active = true;
        });
    }

    addMember(memeber: TeamMember) {
        if (memeber.teamIndex < 0) {
            this.addFrontMemeber(memeber);
        } else if (memeber.teamIndex >= 0) {
            this.addBackMember(memeber);
        }
    }

    removeFrontMember(memeber: TeamMember) {
        this.teamMembers[0].splice(this.teamMembers[0].indexOf(memeber), 1);
    }

    removeBackMember(member: TeamMember) {
        this.teamMembers[1].splice(this.teamMembers[1].indexOf(member), 1);
    }

    removeMember(member: TeamMember) {
        if (member.teamIndex < this.frontRow.length) {
            this.removeFrontMember(member);
        } else {
            this.removeBackMember(member);
        }
    }

    moveFrontMember(memeber: TeamMember, step: number) {
        const frontCount = this.frontRow.length;

        // 索引值越小，隊伍序列越前
        const teamIndex = memeber.teamIndex;

        // 從後排移到前排
        if (teamIndex >= frontCount) {
            this.removeBackMember(memeber);
            this.addFrontMemeber(memeber);
            return;
        }

        // step 為負數，代表向前移動
        const teamFront = this.teamMembers[0];
        if (teamIndex + step <= 0) {
            memeber.teamIndex = 0;
        } else {
            memeber.teamIndex += step;
        }

        const switchMember = teamFront[memeber.teamIndex];
        if (switchMember)
            switchMember.teamIndex += Math.sign(step) * 0.1;// 因為要換位置，下面會再處理成整數

        teamFront.sort((a, b) => a.teamIndex - b.teamIndex);
        teamFront.forEach((member, index) => {
            member.teamIndex = index;
            member.node.parent = this.frontRow[index];
            member.node.setPosition(new Vec3(0, 0, 0));
        });
    }

    moveBackMember(memeber: TeamMember, step: number) {
        const frontCount = this.frontRow.length;

        // 索引值越小，隊伍序列越前
        const teamIndex = memeber.teamIndex;

        // 從前排移到後排
        if (teamIndex < frontCount) {
            this.removeFrontMember(memeber);
            this.addBackMember(memeber);
            return;
        }

        // step 為負數，代表向前移動
        const teamBack = this.teamMembers[1];
        if (teamIndex + step <= frontCount) {
            memeber.teamIndex = frontCount;
        } else {
            memeber.teamIndex += step;
        }

        const switchMember = teamBack[memeber.teamIndex];
        if (switchMember)
            switchMember.teamIndex += Math.sign(step) * 0.1;// 因為要換位置，下面會再處理成整數

        teamBack.sort((a, b) => a.teamIndex - b.teamIndex);
        teamBack.forEach((member, index) => {
            member.teamIndex = index + frontCount;
            member.node.parent = this.backRow[index];
            member.node.setPosition(new Vec3(0, 0, 0));
        });
    }

    updateTeamStatus() {
        // 可選擇指定攻擊的敵人
        this.teamMembers.forEach(team => {
            team.forEach(member => {
                member.enableSelect();
            });
        });
    }

    pushFighter(memeber: TeamMember): void {
        this.fighters.push(memeber);
    }

    // 重新排列隊內成員
    rearrangeMembers(clearFighters: boolean) {
        const frontCount = this.frontRow.length;

        // 原本在 CombatVisualizer 演出的 TeamCharacter 拉回來
        this.fighters.forEach(fighter => {
            if (fighter.teamIndex < frontCount) {
                // 前排角色
                fighter.node.parent = this.frontRow[fighter.teamIndex];
            } else {
                // 後排角色
                fighter.node.parent = this.backRow[fighter.teamIndex - frontCount];
            }
            fighter.endFight();
            fighter.node.setPosition(new Vec3(0, 0, 0));
        });

        if (clearFighters)
            this.fighters.length = 0;
    }

    isAllDead(): boolean {
        return this.teamMembers.every(team => {
            return team.every((member: TeamMember) => member.isDead);
        });
    }

    // 清除隊列中所有角色，包含實體
    clear(): void {
        this.backRow.forEach(node => node.removeAllChildren());
        this.frontRow.forEach(node => node.removeAllChildren());
        this.teamMembers = [[], []];
        this.fighters.length = 0;

        this.fighters.forEach(x => x.updateInfo());
    }
}
