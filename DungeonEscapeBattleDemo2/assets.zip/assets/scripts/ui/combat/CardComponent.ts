import { Component, Label, _decorator } from "cc";
import { CombatCard } from "../../cards/Card";
import { CombatActionType } from "../../dungeon/combat/CombatEntity";

const { ccclass, property } = _decorator;

@ccclass("CardComponent")
export class CardComponent extends Component {

    @property(Label)
    private cardSuit: Label = null;

    @property(Label)
    private cardRank: Label = null;

    card: CombatCard = null;

    setup(card: CombatCard) {
        this.card = card;

        this.cardSuit.string = card.name;
        this.cardRank.string = card.description;
        // let title = '';//todo 要針對effect 的內容去做顯示，殺戮尖塔的設計是可以隨著角色受到的debuff 而去改成數值的顯示，可以的話我想把這個功能加進來
        // let content = '';
        // const skillType: CombatActionType = card.type ;
        // switch (skillType) {
        //     case 'DamageExtra':
        //         title = '額外傷害';
        //         content = card.damage;
        //         break;
        //     case 'HitExtra':
        //         title = '額外命中';
        //         content = card.hits;
        //         break;
        //     case 'HitBonus':
        //         title = '命中加值';
        //         content = card.hits;
        //         break;
        //     case 'DamageBonus':
        //         title = '傷害加值';
        //         content = card.damage;
        //         break;
        // }
        // this.cardRank.string = `${title} ${content}`;
    }
}