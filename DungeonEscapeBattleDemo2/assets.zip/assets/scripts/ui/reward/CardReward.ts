import { _decorator, Component, Node, tween, UIOpacity, Vec3 } from "cc";
import { CombatCard } from "../../cards/Card";
import { RewardCards } from "./RewardCards";
import { EventManager } from "../../managers/EventManager";
import { PlayerHandCardEvent } from "../../managers/GameEvents";
const { ccclass, property } = _decorator;

@ccclass('CardReward')
export class CardReward extends Component {
    @property(Node)
    blocker: Node = null;

    @property(RewardCards)
    rewardCards: RewardCards = null;

    show(active: boolean): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.position = Vec3.ZERO;
        this.node.active = active;

        const blockerOpacity = this.blocker.getComponent(UIOpacity);
        blockerOpacity.opacity = 0;
        if (active) {
            tween(blockerOpacity)
                .delay(0.1)
                .to(0.25, { opacity: 185 }, { easing: 'linear' })
                .start();
        }
    }

    init(cards: CombatCard[]) {
        // this.rewardCards.showCards(cards);
        EventManager.instance.emit(PlayerHandCardEvent.ShowCards, cards);
    }
}