import { _decorator, Button, CCInteger, Color, Component, instantiate, Layout, Node, Prefab, Sprite, Tween, tween, UITransform, Vec3 } from "cc";
import { EventManager } from "../../managers/EventManager";
import { PlayerHandCardEvent } from "../../managers/GameEvents";
import { BaseCardDisplay } from "../../cards/BaseCardDisplay";
import { CombatCard } from "../../cards/Card";
import { CardComponent } from "../combat/CardComponent";
import { TipType } from "../../tools/TipText";

const { ccclass, property } = _decorator;

@ccclass('RewardCards')
export abstract class RewardCards extends BaseCardDisplay {

    protected onLoad(): void {
        EventManager.instance.on(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.on(PlayerHandCardEvent.DealCards, this.onDealCards, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.off(PlayerHandCardEvent.DealCards, this.onDealCards, this);
    }

    protected start(): void {
        this.node.active = false;
    }

    protected showCards(cards: CombatCard[]) {
        const positionNodes = this.positionContainer.children;
        if (positionNodes.length !== cards.length) {
            console.error('卡牌數量與定位節點數量不符');
            return;
        }

        if (this.selectedCardNodes.length > 0) {
            console.error('已經有選取的卡片，請先清除之前的選取');
        }

        this.cardContainer.removeAllChildren();
        cards.forEach((card, index) => {
            const cardNode = instantiate(this.cardPrefab);
            cardNode.name = `Card_${index}`;
            cardNode.getComponent(CardComponent).setup(card);
            cardNode.parent = this.cardContainer;
        });
    }

    onShowCards(event): void {
        this.node.active = true;

        const cards: CombatCard[] = event;
        console.log("show cards", cards);
        this.initPositionNodes(cards.length);

        this.showCards(cards);

        this.followPosition();

        this.setToggleSelection();
    }

    onDealCards(): void {

    }

    onChoosedCardClicked(): void {
        const selectedCardNodes = this.selectedCardNodes;
        if (selectedCardNodes.length === 0) {
            EventManager.instance.emit(TipType.Warning, '沒有選取任何卡片');
            return;
        }

        if (selectedCardNodes.length > 1) {
            EventManager.instance.emit(TipType.Warning, '只能選取一張卡片');
            return;
        }

        const cardNode = selectedCardNodes[0];
        const cardComponent = cardNode.getComponent(CardComponent);
        if (!cardComponent) {
            console.error('卡片物件沒有CardComponent');
            return;
        }

        const card = cardComponent.card;
        console.log('選取卡片', card);

        EventManager.instance.emit('SelectedRewardCard', card);

        this.stopToggleSelection();
        this.unselectAllCards();
    }
}




// import { _decorator, Button, CCInteger, Color, Component, instantiate, Layout, Node, Prefab, Sprite, Tween, tween, UITransform, Vec3 } from "cc";
// import { EventManager } from "../../managers/EventManager";
// import { PlayerHandCardEvent } from "../../managers/GameEvents";
// import { BaseCardDisplay } from "../../cards/BaseCardDisplay";
// import { CombatCard } from "../../cards/Card";
// import { CardComponent } from "../combat/CardComponent";

// const { ccclass, property } = _decorator;

// @ccclass('RewardCards')
// // export abstract class RewardCards extends BaseCardDisplay {
// export abstract class RewardCards extends Component {

//     @property(Prefab)
//     protected cardPrefab: Prefab = null;

//     @property(Node)
//     protected positionContainer: Node = null;  // 存放定位節點

//     @property(Node)
//     protected cardContainer: Node = null;  // 存放所有卡牌節點

//     @property(CCInteger)
//     protected selectedPositionY: number = 50;
//     private oriPositionY: number = 0;

//     protected selected: CombatCard[] = [];

//     protected selectedCardNodes: Node[] = [];
//     private originalIndexMap: Map<Node, number> = new Map();  // 用於保存原始 siblingIndex

//     protected onLoad(): void {
//         EventManager.instance.on(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
//         // EventManager.instance.on(PlayerHandCardEvent.DealCards, this.onDealCards, this);
//     }

//     protected onDestroy(): void {
//         EventManager.instance.off(PlayerHandCardEvent.ShowCards, this.onShowCards);
//         // EventManager.instance.off(PlayerHandCardEvent.DealCards, this.onDealCards);
//     }

//     protected start(): void {
//         // this.initPositionNodes(2);
//         this.node.active = false;
//     }

//     /**
//      * 初始化定位節點
//      * @param length 定位節點數量
//      */
//     initPositionNodes(length: number) {
//         this.positionContainer.removeAllChildren();

//         for (let i = 0; i < length; i++) {
//             const positionNode = new Node();  // 創建定位用節點
//             positionNode.name = `Position_${i}`;
//             positionNode.parent = this.positionContainer;
//             positionNode.addComponent(Sprite).color = Color.RED;
//             positionNode.getComponent(UITransform).setContentSize(100, 100);
//         }

//         // this.updatePositionLayout();
//     }

//     // 讓卡牌位置跟隨定位點
//     followPosition() {
//         this.node.active = true;
//         this.updatePositionLayout();

//         const cardNodes = this.cardContainer.children;
//         const positionNodes = this.positionContainer.children;
//         console.log('followPosition cardNodes.length:', cardNodes.length);
//         console.log('followPosition positionNodes.length:', positionNodes.length);
//         if (cardNodes.length !== positionNodes.length) {
//             console.error('卡牌數量與定位節點數量不符');
//             return;
//         }
//         positionNodes.forEach((positionNode, index) => {
//             const cardNode = cardNodes[index];
//             cardNode.setPosition(positionNode.position);
//             console.log('followPosition positionNode.position:', positionNode.position);
//         });
//     }

//     protected showCards(cards: CombatCard[]) {
//         const positionNodes = this.positionContainer.children;
//         if (positionNodes.length !== cards.length) {
//             console.error('卡牌數量與定位節點數量不符');
//             return;
//         }

//         if (this.selectedCardNodes.length > 0) {
//             console.error('已經有選取的卡片，請先清除之前的選取');
//         }

//         this.cardContainer.removeAllChildren();
//         cards.forEach((card, index) => {
//             const cardNode = instantiate(this.cardPrefab);
//             cardNode.name = `Card_${index}`;
//             cardNode.getComponent(CardComponent).setup(card);//todo baseCardDisplay 要另外拉出來了，這樣card跟 cardcomponent 每種卡片都不一樣，沒必要統一
//             cardNode.parent = this.cardContainer;
//         });
//     }

//     setToggleSelection(onCompleted: (isSelected: boolean) => void = null) {
//         this.cardContainer.children.forEach((cardNode) => {
//             cardNode.on('click', () => this.toggleCardSelection(cardNode, onCompleted), this);
//         });
//     }

//     stopToggleSelection() {
//         this.cardContainer.children.forEach((cardNode) => {
//             cardNode.off('click');
//         });
//     }

//     /**
//      * 選取或取消選取卡片
//      * @param cardNode 選定卡片的實體
//      * @param onCompleted 選取或取消選取完成後的回呼函式
//      */
//     protected toggleCardSelection(cardNode: Node, onCompleted: (isSelected: boolean) => void = null): void {
//         // 檢查是否已選取，根據當前狀態切換
//         const isSelected = this.selectedCardNodes.includes(cardNode);
//         if (isSelected) {
//             this.selectedCardNodes = this.selectedCardNodes.filter(c => c !== cardNode);
//             const originalIndex = this.originalIndexMap.get(cardNode) || 0;
//             cardNode.setSiblingIndex(originalIndex);  // 恢復原始索引
//         } else {
//             this.selectedCardNodes.push(cardNode);
//             this.originalIndexMap.set(cardNode, cardNode.getSiblingIndex());
//             cardNode.setSiblingIndex(this.cardContainer.children.length - 1);  // 提升至最高
//         }

//         const targetY = isSelected ? 0 : this.selectedPositionY;
//         this.animateSelectCardMovement(cardNode, targetY).then(() => {
//             onCompleted?.(isSelected);
//             console.log('toggleCardSelection selectedCardNodes:', this.selectedCardNodes);
//         });
//     }

//     protected updatePositionLayout() {
//         const layout = this.positionContainer.getComponent(Layout);

//         // 刷新 Layout 並顯示卡片
//         layout.enabled = true;
//         layout.updateLayout();

//         // 關閉 Layout，避免後續選取卡片後，卡片順序錯亂
//         layout.enabled = false;
//     }

//     /** 取消所有卡牌選取 */
//     unselectAllCards(): Promise<void[]> {
//         console.log('取消所有共', this.selected.length, '張卡牌選取');

//         this.selected.length = 0;
//         return Promise.all(
//             this.selectedCardNodes.map((cardNode) => {
//                 return this.animateSelectCardMovement(cardNode, 0).then(() => {
//                     this.selectedCardNodes = this.selectedCardNodes.filter(c => c !== cardNode);
//                     const originalIndex = this.originalIndexMap.get(cardNode) || 0;
//                     cardNode.setSiblingIndex(originalIndex);  // 恢復原始索引
//                 });
//             })
//         );
//     }

//     onShowCards(event): void {
//         this.node.active = true;

//         const cards: CombatCard[] = event;
//         console.log("show cards", cards);
//         this.initPositionNodes(cards.length);

//         this.showCards(cards);

//         this.followPosition();

//         this.setToggleSelection();
//     }

//     /**
//      * 動畫卡片移動
//      * @param cardNode 卡片的 Node 實體
//      * @param deltaY 移動的 y 軸增量
//      */
//     protected animateSelectCardMovement(cardNode: Node, deltaY: number): Promise<void> {
//         const button = cardNode.getComponent(Button);
//         button.interactable = false;

//         return new Promise(resolve => {
//             // 使用現有的 y 位置並加上 deltaY 來計算新位置
//             let newY = this.oriPositionY + deltaY;

//             // 創建一個新的 Vec3 為目標位置，只改變 y 軸
//             let targetPosition = new Vec3(cardNode.position.x, newY, cardNode.position.z);

//             // 開始動畫
//             tween(cardNode)
//                 .to(0.25, { position: targetPosition }, { easing: 'quadInOut' })
//                 .call(() => {
//                     button.interactable = true;
//                     resolve();
//                 })
//                 .start();
//         });
//     }

//     onChoosedCardClicked(): void {
//         const selectedCardNodes = this.selectedCardNodes;
//         if (selectedCardNodes.length === 0) {
//             console.error('沒有選取任何卡片');
//             return;
//         }

//         const cardNode = selectedCardNodes[0];
//         const cardComponent = cardNode.getComponent(CardComponent);
//         if (!cardComponent) {
//             console.error('卡片物件沒有CardComponent');
//             return;
//         }

//         const card = cardComponent.card;
//         console.log('選取卡片', card);

//         EventManager.instance.emit('SelectedRewardCard', card);

//         this.stopToggleSelection();
//         this.unselectAllCards();
//     }
// }