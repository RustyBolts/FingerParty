import { _decorator, Component, instantiate, Node, Vec3 } from 'cc';
import { AttributeAllocation } from '../dungeon/adventure/AttributeAllocation';
import { AttributeComponent } from '../dungeon/adventure/AttributeComponent';
import { Attribute, BaseAbilities } from '../dungeon/Ability';
import { EventManager } from './EventManager';
import { CharacterInfo } from '../ui/character/CharacterInfo';
import { Character } from '../dungeon/Character';
import { warriorFeatures } from '../dungeon/ClassFeatureImplementation';
import { DescriptionScrollView } from '../tools/DescriptionScrollView';
import { Inventory } from '../dungeon/inventory/Inventory';
import { DataModal } from '../data/DataModal';
import { ButtonOption, PopupWindowComponent } from '../tools/PopupWindowComponent';
import { MapConnection } from '../dungeon/adventure/MapConnection';
import { CopingSkillCheck } from '../dungeon/rogue/CopingSkillCheck';
import { NarratorCore } from '../dungeon/rogue/NarratorCore';
const { ccclass, property } = _decorator;

export enum UIEvent {
    BaseAbilitiesShowUI = 'ui_event_base_abilities_show_ui',
    BaseAbilityAllocation = 'ui_event_base_ability_allocation',
    InventoryShowUI = 'ui_event_inventory_show_ui',
    DescriptionScrollViewShowUI = 'ui_event_description_scroll_view_show_ui',
    PopupWindow = 'ui_event_popup_window',
    UpdateCharacterInfo = 'ui_event_update_character_info',
    MapConnectionShowUI = 'ui_event_map_connection_show_ui',
}

@ccclass('UIManager')
export class UIManager extends Component {
    @property(Node)
    abilitiesInfoContainer: Node = null;
    @property(Node)
    abilitiesContainer: Node = null;

    @property(Node)
    characterInfoContainer: Node = null;

    @property(Node)
    inventoryContainer: Node = null;

    @property(Node)
    descriptionScrollContainer: Node = null!;

    @property(Node)
    mapConnectionContainer: Node = null!;

    @property(Node)
    copingSkillContainer: Node = null!;

    @property(Node)
    popupWindowContainer: Node = null!;

    @property(Node)
    story: Node = null!;//todo 暫時先放在這裡，之後再想辦法把它移到其他地方

    protected onLoad(): void {
        EventManager.instance.on(UIEvent.BaseAbilitiesShowUI, this.onBaseAbilitiesShowUI, this);
        EventManager.instance.on(UIEvent.BaseAbilityAllocation, this.onBaseAbilityAllocation, this);
        EventManager.instance.on(UIEvent.InventoryShowUI, this.onInventoryShowUI, this);
        EventManager.instance.on(UIEvent.DescriptionScrollViewShowUI, this.onDescriptionScrollViewShowUI, this);
        EventManager.instance.on(UIEvent.PopupWindow, this.onPopupWindow, this);
        EventManager.instance.on(UIEvent.UpdateCharacterInfo, this.onUpdateCharacterInfo, this);
        EventManager.instance.on(UIEvent.MapConnectionShowUI, this.onMapConnectionShowUI, this);
        EventManager.instance.on('QuestAccept', this.onQuestAccept, this);
        EventManager.instance.on('DramaEvent', this.onDramaEvent, this);
        EventManager.instance.on('StartStory', this.onStartStory, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(UIEvent.BaseAbilitiesShowUI, this.onBaseAbilitiesShowUI, this);
        EventManager.instance.off(UIEvent.BaseAbilityAllocation, this.onBaseAbilityAllocation, this);
        EventManager.instance.off(UIEvent.InventoryShowUI, this.onInventoryShowUI, this);
        EventManager.instance.off(UIEvent.DescriptionScrollViewShowUI, this.onDescriptionScrollViewShowUI, this);
        EventManager.instance.off(UIEvent.PopupWindow, this.onPopupWindow, this);
        EventManager.instance.off(UIEvent.UpdateCharacterInfo, this.onUpdateCharacterInfo, this);
        EventManager.instance.off(UIEvent.MapConnectionShowUI, this.onMapConnectionShowUI, this);
        EventManager.instance.off('QuestAccept', this.onQuestAccept, this);
        EventManager.instance.off('DramaEvent', this.onDramaEvent, this);
        EventManager.instance.off('StartStory', this.onStartStory, this);
    }

    private onBaseAbilitiesShowUI(active: boolean): void {
        this.abilitiesContainer.active = active;
        this.abilitiesInfoContainer.active = active;

        if (!active) {
            // 關閉時更新內容
            this.updateBaseAbilityByComponents();
        }
    }

    // 能力屬性分配
    private onBaseAbilityAllocation(event: any): void {
        const { allocatePoints, baseAbilities } = event;
        console.log('onBaseAbilityAllocation', allocatePoints, baseAbilities);
        this.allocateBaseAbility(allocatePoints, baseAbilities);
    }

    private onInventoryShowUI(active: boolean): void {
        const inventory: Inventory = this.inventoryContainer.getComponent(Inventory);
        if (inventory) {
            inventory.show(active);
        }

        const characterInfo: CharacterInfo = this.characterInfoContainer.getComponent(CharacterInfo);
        if (characterInfo) {
            characterInfo.member.characterInfoLabel.node.active = active;
        }
    }

    private onDescriptionScrollViewShowUI(active: boolean): void {
        this.descriptionScrollContainer.active = active;
    }

    private onUpdateCharacterInfo(): void {
        this.characterInfoContainer.active = true;
        const characterInfo: CharacterInfo = this.characterInfoContainer.getComponent(CharacterInfo);
        if (characterInfo) {
            characterInfo.character = DataModal.getInstance().playerCharacter;
            characterInfo.refreshCharacterInfo();
            characterInfo.refreshItemInfo();
        }
    }

    private onQuestAccept(missionId: string): void {
        const characterInfo: CharacterInfo = this.characterInfoContainer.getComponent(CharacterInfo);
        if (characterInfo) {
            characterInfo.acceptMission(missionId);

            const quest = DataModal.getInstance().storyData.quests[missionId];

            // test 如果沒有其他任務，這邊就直接開啟description scroll view

            if (quest.location) {
                this.onMapConnectionShowUI(true);

                const mapConnection: MapConnection = this.mapConnectionContainer.getComponent(MapConnection);
                mapConnection?.createCenterLocation(quest.location);

                this.copingSkillContainer.active = true;
                // const copingSkillCheck: CopingSkillCheck = this.copingSkillContainer.getComponent(CopingSkillCheck);
                // if (copingSkillCheck) {
                //     copingSkillCheck.setQuestData(quest);
                // }

                const narratorCore: NarratorCore = this.copingSkillContainer.getComponent(NarratorCore);
                if (narratorCore) {
                    narratorCore.quest = missionId;
                }

                // const descriptionScrollView: DescriptionScrollView = this.descriptionScrollContainer.getComponent(DescriptionScrollView);
                // descriptionScrollView?.show(true);
                // descriptionScrollView?.setData(quest.descriptions);
            }
        }
    }

    private onDramaEvent(id: string): void {
        this.copingSkillContainer.active = true;
        // const copingSkillCheck: CopingSkillCheck = this.copingSkillContainer.getComponent(CopingSkillCheck);
        // if (copingSkillCheck) {
        //     copingSkillCheck.setDramaData(DataModal.getInstance().storyData.dramas[id]);
        // }
        
        const narratorCore: NarratorCore = this.copingSkillContainer.getComponent(NarratorCore);
        if (narratorCore) {
            narratorCore.drama = id;
        }

    }

    private onMapConnectionShowUI(active: boolean): void {
        this.mapConnectionContainer.active = active;
    }

    private onStartStory(): void {
        this.story.active = true;
    }

    private onPopupWindow(title: string, context: string, buttons: ButtonOption[]): void {
        this.popupWindowContainer.active = true;
        const popupWindow: PopupWindowComponent = this.popupWindowContainer.getComponent(PopupWindowComponent);
        if (popupWindow) {
            popupWindow.openPopup(title, context, buttons);
        }
    }

    protected start(): void {
        this.node.position = Vec3.ZERO;

        this.abilitiesInfoContainer.active = false;
        // this.characterInfoContainer.active = false;
        this.inventoryContainer.active = false;
        // this.descriptionScrollContainer.active = false;
        this.popupWindowContainer.active = false;
    }

    updateBaseAbilityByComponents(): void {
        const abilityComponents: AttributeComponent[] = this.abilitiesContainer.getComponentsInChildren(AttributeComponent);
        const abilityies: Partial<BaseAbilities> = {};
        abilityComponents.forEach((component: AttributeComponent) => {
            // console.log('component.Name:', component.Name, component.Value);
            abilityies[component.Name] = component.Value;
        });

        const baseAbilities: BaseAbilities = abilityies as BaseAbilities;
        DataModal.getInstance().playerCharacter.abilities = baseAbilities;

        this.characterInfoUpdate();
    }

    characterInfoUpdate(): void {
        const characterInfo: CharacterInfo = this.characterInfoContainer.getComponent(CharacterInfo);
        if (characterInfo) {
            characterInfo.refreshCharacterInfo();
            characterInfo.refreshItemInfo();
        }
    }

    /**
     * 分配角色能力點數 todo 可以拉出來另外做一個類別
     * @param beAllocatedPoints 給幾個點數分配
     * @param baseAbilities 已分配好的能力點數
     */
    allocateBaseAbility(beAllocatedPoints: number, baseAbilities: BaseAbilities): void {
        const allocation: AttributeAllocation = this.abilitiesContainer.getComponent(AttributeAllocation);
        const abilities: AttributeComponent[] = this.abilitiesContainer.getComponentsInChildren(AttributeComponent);
        if (allocation && abilities) {
            this.abilitiesContainer.active = true;

            let totalPoints = 0;
            Object.values(baseAbilities).forEach((ability: number, index: number) => {
                let abilityComponent = abilities[index];
                if (!abilityComponent) {
                    let node = instantiate(abilities[0].node);
                    node.parent = this.abilitiesContainer;
                    node.active = true;
                    abilityComponent = node.getComponent(AttributeComponent);
                }
                abilityComponent.Name = Object.keys(baseAbilities)[index];
                abilityComponent.Value = ability;

                totalPoints += ability;
            });

            allocation.pointsUsed = totalPoints;
            allocation.totalPoints = beAllocatedPoints + totalPoints;
        }
    }

    //#region Click Event

    onAbilitiesCloseClicked(): void {
        this.onBaseAbilitiesShowUI(false);
    }

    onAbilityInfoClicked() {
        this.onBaseAbilitiesShowUI(!this.abilitiesContainer.active);
    }

    onInventoryButtonClicked(): void {
        this.onInventoryShowUI(!this.inventoryContainer.active);
    }

    //#endregion Click Event

}
