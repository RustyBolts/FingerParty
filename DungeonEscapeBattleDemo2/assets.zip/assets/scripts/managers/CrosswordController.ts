import { _decorator, Component, Node, RichText } from "cc";
import { EventManager } from "./EventManager";
const { ccclass, property } = _decorator;

export enum CrosswordEvent {
    CrosswordSolved = 'crossword_event_crossword_solved',
    CrosswordFailed = 'crossword_event_crossword_failed',
    CrosswordCellCleared = 'crossword_event_crossword_cell_cleared'
}

// TODO 原本想做一個統一管理的中介層，但目前可能沒辦法統一。之後應該會刪掉

@ccclass('CrosswordController')
export class CrosswordController extends Component {

    protected onLoad(): void {
        EventManager.instance.on(CrosswordEvent.CrosswordSolved, this.onCrosswordSolved, this);
        EventManager.instance.on(CrosswordEvent.CrosswordCellCleared, this.onCrosswordCellCleared, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(CrosswordEvent.CrosswordSolved, this.onCrosswordSolved, this);
        EventManager.instance.off(CrosswordEvent.CrosswordCellCleared, this.onCrosswordCellCleared, this);
    }

    onCrosswordSolved(event: any): void {

    }

    onCrosswordCellCleared(event: any): void {
        
    }
}