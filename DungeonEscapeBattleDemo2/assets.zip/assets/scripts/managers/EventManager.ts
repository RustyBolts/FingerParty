export class EventManager {
    private static _instance: EventManager;
    private _listeners = new Map<string, { method: Function, scope: any }[]>();

    public static get instance() {
        if (!this._instance) {
            this._instance = new EventManager();
        }
        return this._instance;
    }

    on(event: string, method: Function, scope: any) {
        if (!this._listeners.has(event)) {
            this._listeners.set(event, []);
        }
        this._listeners.get(event).push({ method, scope });
    }

    emit(event: string, ...args: any[]) {
        if (this._listeners.has(event)) {
            this._listeners.get(event).forEach(({ method, scope }) => method.call(scope, ...args));
        }
    }

    off(event: string, method: Function, scope: any) {
        if (this._listeners.has(event)) {
            const callbacks = this._listeners.get(event);
            const index = callbacks.findIndex((listener) => listener.method === method && listener.scope === scope);
            if (index > -1) {
                callbacks.splice(index, 1);
            }
        }
    }
}