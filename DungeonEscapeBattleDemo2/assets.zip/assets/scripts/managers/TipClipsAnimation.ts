import { _decorator, Component, Node, Prefab, instantiate, tween, Vec3, v3, Label, randomRange } from "cc";
import { CardMover } from "../tools/CardMover";

const { ccclass, property } = _decorator;

@ccclass('TipClipsAnimation')
export class TipClipsAnimation extends Component {
    @property(Node)
    private destinationNode: Node = null;  // 最終卡牌的目標節點

    @property(Prefab)
    private answerClipPrefab: Prefab = null;

    onLoad() {

    }

    /**
     * 創建卡牌實體並進行散開動畫，然後移動到指定節點
     * @param textData 卡牌資料陣列
     */
    async spreadCards(textData: string[]) {
        const cardNodes: Node[] = [];

        // 創建卡牌節點
        textData.forEach(text => {
            const cardNode = instantiate(this.answerClipPrefab);
            cardNode.getComponentInChildren(Label).string = text;
            this.node.addChild(cardNode);  // 暫時將卡牌添加到此管理器節點下
            cardNodes.push(cardNode);
        });

        // 執行散開動畫
        await CardMover.scatterCards(cardNodes, this.node, [60, 100], randomRange(0.75, 1.25));
        cardNodes.forEach(async (cardNode, index) => {
            await CardMover.moveCard(cardNode, this.destinationNode, Vec3.ZERO, 0.25, 0.25);
            tween(this.destinationNode)// todo 這邊並沒有真的對不同cardNode 做延時，所以按鈕的收納動態其實只需要做一次就好
                .to(0.1, { scale: v3(1.2, 1.2, 1) })
                .call(() => cardNode.destroy())
                .to(0.1, { scale: v3(1, 1, 1) })
                .start();
        });

    }
}
