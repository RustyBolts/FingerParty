export class NotifyEvent {
    type: string;
    detail: any;

    constructor(type: string, detail: any) {
        this.type = type;
        this.detail = detail;
    }
}

export class EventBus {
    private listeners: { [key: string]: Function[] } = {};

    // 訂閱事件
    subscribe(eventType: string, listener: Function) {
        if (!this.listeners[eventType]) {
            this.listeners[eventType] = [];
        }
        this.listeners[eventType].push(listener);
    }

    // 取消訂閱事件
    unsubscribe(eventType: string, listener: Function) {
        if (this.listeners[eventType]) {
            this.listeners[eventType] = this.listeners[eventType].filter(subscriber => subscriber !== listener);
        }
    }

    // 發佈事件
    publish(event: NotifyEvent) {
        (this.listeners[event.type] || []).forEach(listener => listener(event.detail));
    }
}