import { Damage } from "../dungeon/item/Weapon";
import { CombatActionType, CombatEntity } from "../dungeon/combat/CombatEntity";
export class EffectManager {
    private static _instance: EffectManager;
    public static get instance() {
        if (!EffectManager._instance) {
            EffectManager._instance = new EffectManager();
        }
        return EffectManager._instance;
    }

    private effects = new Map<CombatEntity, Effect[]>();

    // 新增效果
    addEffect(target: CombatEntity, effect: Effect) {
        const currentEffects = this.effects.get(target) || [];
        currentEffects.push(effect);
        this.effects.set(target, currentEffects);

        // console.log(`Effect added to ${target.name}, type: ${effect.type}`);
        console.log('this.effects:', JSON.stringify(this.effects));
    }

    // 移除效果
    removeEffect(target: CombatEntity, effect: Effect) {
        let effects = this.effects.get(target) || [];
        let index = effects.indexOf(effect);
        if (index !== -1) {
            effects.splice(index, 1);
        }
        if (effects.length === 0) {
            this.effects.delete(target);
        }
        console.log(`Effect removed from ${target.name}`);
    }

    applySkillEffects(entity: CombatEntity, skills: any[]) {
        // entity.applySkill(skills);
    }

    // // replace by applyBenefit
    // applyAffixEffect(entity: CombatEntity, effect: Effect) {
    //     const thresholdList = [4, 7, 9];
    //     if (thresholdList[0] > effect.value) {
    //         return;
    //     }

    //     let effectValue = effect.value;
    //     let level = thresholdList.findIndex((step) => step <= effectValue);

    //     effect.value -= thresholdList[level];
    //     switch (effect.affix) {
    //         // // case 'resistance'://抵抗
    //         case 'flexible'://靈活
    //             entity.applyEffect('damageReduction', [1, 2, 3][level]);
    //             // entity.applyEffect(effect.attribute, [1, 2, 3][level]);
    //             break;
    //         case 'alertness'://警覺
    //             // entity.armorClass += [1, 2, 3][level];
    //             entity.applyEffect('deffenseBonus', [1, 2, 3][level]);
    //             // entity.applyEffect(effect.attribute, [1, 2, 3][level]);
    //             break;
    //         case 'precision'://精準
    //             entity.applyEffect('hitBonus', [1, 2, 3][level]);
    //             // entity.applyEffect(effect.attribute, [1, 2, 3][level]);
    //             break;
    //         case 'inspiration'://振奮
    //             entity.applyEffect('damageBonus', [1, 2, 3][level]);
    //             // entity.applyEffect(effect.attribute, [1, 2, 3][level]);
    //             break;
    //         case 'energize'://激勵
    //             entity.extraHitDices.push(['1d4', '1d6', '1d8'][level]);
    //             // todo，統一的話，改為在 CombatEntity 裡面定義 extraHitDices ，這邊只調整輸入的等級
    //             // 如 entity.applyEffect(effect.attribute, level); 來處理 ['1d4', '1d6', '1d8'][level] 這個陣列
    //             break;
    //         case 'rage'://狂怒
    //             let damages: Damage[] = [{ type: 'Bludgeoning', formula: '1d4' }, { type: 'Bludgeoning', formula: '1d6' }, { type: 'Bludgeoning', formula: '1d8' }]
    //             entity.extraDamageDices.push(damages[level]);
    //             // todo，同 energize
    //             break;
    //         case 'eye':
    //             entity.applyEffect('blind', 1);
    //             break;
    //     }
    // }

    updateEffects() {
        console.log('updateEffects', this.effects);
        this.effects.forEach((effects, entity) => {
            // 更新效果前，先重置之前所有效果
            entity.resetBonuses();

            this.effects.set(entity, effects.filter(effect => {
                if (effect.duration > 0) {
                    // this.applyAffixEffect(entity, effect);//這個可能不會使用詞綴了，詞綴目前的設計感覺不是很強烈

                    effect.duration--;
                    if (effect.duration <= 0) {
                        this.removeEffect(entity, effect);
                        return false;
                    }
                    return true;
                }
                return false;
            }));

            // 清除效果已過期的實體
            if (effects.length === 0) {
                this.clearEffects(entity);
            }
        });
    }

    // 清除指定實體的所有效果
    clearEffects(target: CombatEntity) {
        this.effects.delete(target);
        console.log(`All effects cleared from ${target.name}`);
    }

}

export type AffixAttribute = 'flexible' | 'alertness' | 'precision' | 'inspiration' | 'energize' | 'rage' | 'eye';
export type EffectAttribute = 'hitBonus' | 'damageBonus' | 'damageReduction' | 'deffenseBonus' | 'criticalHit' | 'criticalDamage' | 'disarm' | 'escape' | 'poison' | 'bleeding' | 'frenzy' | 'stun' | 'blind' | 'paralyze' | 'confusion';

export interface Effect {
    affix?: AffixAttribute;//todo 取代這個，之後應該是拿掉就好
    attribute?: CombatActionType;//todo 暫時設為可有可無，之後轉正
    value: number;
    duration: number;
    // type: 'attribute' | 'damage';
    // detail: AttributeDetail | DamageDetail;
}
// export interface Effect {
//     type: 'attribute' | 'damage';
//     detail: AttributeDetail | DamageDetail;
//     duration: number;
// }

// export interface AttributeDetail {
//     attribute: string;
//     value: number;
// }

// export interface DamageDetail {
//     damage: Damage;
//     modifier: number;  // 這可以是正值或負值，用於調整擲骰結果
// }
