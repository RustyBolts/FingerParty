export enum GameLogicEvent {
    // UpdateGameState = 'update-game-state',
    // PlayerActionRequired = 'player-action-required',

    GameStart = 'game-logic-game-start',
    GameEnd = 'game-logic-game-end',
    GameResume = 'game-logic-game-resume',
    GamePause = 'game-logic-game-pause',
    GameRoundStart = 'game-logic-game-round-start',

    GameRoundStartShowCards = 'game-logic-game-round-start-show-cards',
    GameRoundStartConfirmSelection = 'game-logic-game-round-start-confirm-selection',
    GameRoundPlayerDiscardCards = 'game-logic-game-round-player-discard-cards',

    GameRoundStartDiscardCards = 'game-logic-game-round-start-discard-cards',
    GameRoundStartDealCards = 'game-logic-game-round-start-deal-cards',
    GameRoundStartShowCommunityCards = 'game-logic-game-round-start-show-community-cards',//
    GameRoundStartShowPlayerHands = 'game-logic-game-round-start-show-player-hands',//
    GameRoundStartShowDiscardPile = 'game-logic-game-round-start-show-discard-pile',//
    GameRoundNextPlayerTurn = 'game-logic-game-round-next-player-turn',
    GameRoundEndShowCards = 'game-logic-game-round-end-show-cards',
}

export enum GameUIEvent {
    GameStart = 'game-ui-game-start',
    GameEnd = 'game-ui-game-end',
    DeckCardSelected = 'game-ui-card-selected',
    DeckCardUnselected = 'game-ui-card-unselected',
    DeckCardDiscard = 'game-ui-card-discard',
    ShowCardConditions = 'game-ui-show-card-conditions',
    ShowCardConditions2 = 'game-ui-show-card-conditions2',
    // NewAnswersTip = 'game-ui-new-answers-tip',
}

export enum DeckPileEvent {
    ShowCards = 'deck-card-show-cards',
    DiscardCards = 'deck-card-discard-cards',
    DealCommunityCards = 'deck-card-deal-cards',
    DealPlayerCards = 'deck-card-deal-player-cards',
    DeckGatherings = 'deck-card-gatherings',
    HideCards = 'deck-card-hide-cards',
}

export enum CommunityCardEvent {
    DealCards = 'community-card-deal-cards',
    ShowCards = 'community-card-show-cards',
    CompareCards = 'community-card-campare-cards',
}

export enum PlayerHandCardEvent {
    DealCards = 'player-hand-card-deal-cards',
    ShowCards = 'player-hand-card-show-cards',
    CompareCards = 'player-hand-card-compare-cards',
    SendCards = 'player-hand-card-send-cards',
    ReceiveCards = 'player-hand-card-receive-cards',
}

// export enum DiscardPileEvent {
//     GameRoundStartDiscardCards = 'game-logic-game-round-start-discard-cards',

// }

export enum WordPuzzleGameLogicEvent {
    WordPuzzleGameStart = 'word-puzzle-game-start',
    WordPuzzleGameEnd = 'word-puzzle-game-end',
    ShowQuestion = 'word-puzzle-game-logic-show-question',
    ShowAnswer = 'word-puzzle-game-logic-show-answer',
    ShowHint = 'word-puzzle-game-logic-show-hint',
    TexasGameStart = 'word-puzzle-game-logic-texas-game-start',
    TexasGameResume = 'word-puzzle-game-logic-texas-game-resume',
    // TexasGameEnd = 'word-puzzle-game-logic-texas-game-end',
}
