import { _decorator, Component, ParticleSystem2D, Vec2, tween, Color } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ParticleEffectComponent')
export class ParticleEffectComponent extends Component {
    @property(ParticleSystem2D)
    particleSystem: ParticleSystem2D = null; // 粒子系统组件

    playEffect() {
        if (this.particleSystem) {
            // 重置粒子系统开始播放
            this.particleSystem.resetSystem();
            // 确保粒子效果播放结束后停止
            const totalDuration = this.particleSystem.duration + this.particleSystem.life;
            console.log('totalDuration', totalDuration);
            this.scheduleOnce(() => {
                this.particleSystem.stopSystem();
            }, totalDuration);
        }
    }

    // 可以在此函数内调整粒子属性
    setupEffect() {
        // 确保粒子系统属性适用于向上飘动效果
        this.particleSystem.gravity = new Vec2(0, -100); // 设置重力向上
        this.particleSystem.speed = 50; // 设置粒子速度
        this.particleSystem.startColor = new Color(255, 255, 255, 255); // 设置起始颜色为白色
        this.particleSystem.endColor = new Color(255, 255, 255, 0); // 结束时颜色透明
        this.particleSystem.startSize = 10; // 起始大小
        this.particleSystem.endSize = 0; // 结束大小变为0

        this.particleSystem.duration = 1;

        // todo 再研究一下，這邊有點搞不太懂
    }
}
