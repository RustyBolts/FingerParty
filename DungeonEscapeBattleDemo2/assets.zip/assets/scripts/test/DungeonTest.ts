import { _decorator, Component, instantiate, randomRangeInt } from 'cc';
import { StoryData } from '../data/StoryData';
import Rogue from '../dungeon/Rogue';
import { Attribute, BaseAbilities, CompositeAbilities } from '../dungeon/Ability';
import { Character } from '../dungeon/Character';
import { CharacterInfo } from '../ui/character/CharacterInfo';
import { warriorFeatures } from '../dungeon/ClassFeatureImplementation';
import { EventManager } from '../managers/EventManager';
import { UIEvent } from '../managers/UIManager';
import { DataModal } from '../data/DataModal';
import { Weapon, WeaponStyle } from '../dungeon/item/Weapon';
import { Inventory } from '../dungeon/inventory/Inventory';
import { Armor } from '../dungeon/item/Armor';
import { Shield } from '../dungeon/item/Shield';
import { TeamMember } from '../ui/combat/TeamMember';
import { CombatControllerEvent } from '../ui/combat/CombatController';
const { ccclass, property } = _decorator;

@ccclass('DungeonTest')
export class DungeonTest extends Component {

    @property(Rogue)
    rogue: Rogue = null!;

    @property(CharacterInfo)
    characterInfo: CharacterInfo = null;

    @property(Inventory)
    inventory: Inventory = null;

    monsterEmeny: TeamMember = null;

    protected onLoad(): void {
        EventManager.instance.on('battleStart', this.battleStart, this);
    }
    protected onDestroy(): void {
        EventManager.instance.off('battleStart', this.battleStart, this);
    }
    protected start(): void {
        // const data = DataModal.getInstance().storyData.dungeons['abcd234'];
        // this.rogue.setDungeonData(data);

        // 劇本
            // EventManager.instance.emit('DramaEvent', 'hdse11589');
            // EventManager.instance.emit('DramaEvent', 'bispe1335');
            EventManager.instance.emit('QuestAccept', 'kuai_kuai_cat1');

        // 建立玩家能力值
        const baseAbilities: BaseAbilities = {
            [Attribute.Strength]: 15,
            [Attribute.Dexterity]: 14,
            [Attribute.Intelligence]: 13,
            [Attribute.Wisdom]: 12,
            [Attribute.Charisma]: 10,
            [Attribute.Resilience]: 8
        };
        const allocatePoints = 0;

        this.characterInfo.node.active = true;

        DataModal.getInstance().playerCharacter = new Character('warrior', 1, baseAbilities, warriorFeatures);
        this.characterInfo.character = DataModal.getInstance().playerCharacter;
        EventManager.instance.emit(UIEvent.BaseAbilityAllocation, { allocatePoints, baseAbilities });//調整屬性值設定

        // 建立敌人能力值
        const monster = instantiate(this.characterInfo.member.node);
        this.monsterEmeny = monster.getComponent(TeamMember);

        // 道具欄
        this.setInventory();
    }

    setInventory(): void {
        EventManager.instance.emit(UIEvent.InventoryShowUI, true);
        // 建立武器庫
        const weapons: Weapon[] = [
            new Weapon('長劍', '15 gold', 3, WeaponStyle.Longsword, 'long_swood', { dice: '1d8', dice2: '1d10', type: 'Slashing' }, ['Versatile'], 'Melee'),
            new Weapon('銅錘', '2 gold', 2, WeaponStyle.LightHammer, 'hammer', { dice: '1d4', type: 'Bludgeoning' }, ['Light', 'Thrown'], 'Melee'),//todo 可以投擲
            new Weapon('匕首', '2 gold', 1, WeaponStyle.Dagger, 'dagger', { dice: '1d4', type: 'Piercing' }, ['Finesse', 'Light', 'Thrown'], 'Melee'),//Finesse 靈巧
            new Weapon('手斧', '5 gold', 2, WeaponStyle.Handaxe, 'axe', { dice: '1d6', type: 'Slashing' }, ['Light', 'Thrown'], 'Melee'),
        ];
        weapons.forEach(weapon => this.inventory.addItem(weapon));
        const armors: Armor[] = [
            new Armor("綿甲", 'padded', "5 gold", 8, 11, 0, 'Disadvantage', 'Light'),
            new Armor("生皮甲", 'rawhide', "10 gold", 12, 12, 0, 'None', 'Medium'),
            new Armor("鎖子甲", 'chainmail', "75 gold", 55, 16, 13, 'Disadvantage', 'Heavy')
        ];
        armors.forEach(armor => this.inventory.addItem(armor));
        this.inventory.addItem(new Shield('盾牌', 'shield', '5 gold', 9, 2));

    }


    emenyParam: CompositeAbilities = { constitution: 5, spirit: 20, willpower: 15 };
    emenyAC: number = 10;

    battleStart(enemyName:string) {
        this.characterInfo.rollInitiativeOrder();

        const monster = DataModal.getInstance().storyData.monsters[enemyName];
        const {icon, ac, dex, constitution, spirit, willpower} = monster;
        this.emenyParam.constitution = constitution;
        this.monsterEmeny.monsterInitial(icon, this.emenyParam, ac);
        this.monsterEmeny.rollInitiativeOrder(dex);

        // // 重置並增加怪物角色
        // const icons = ['monster', 'wisdom_brain', 'iron_warroir'];
        // this.emenyParam.constitution += randomRangeInt(1, 10);
        // this.emenyAC = Math.min(18, Math.max(this.emenyAC, this.emenyAC + randomRangeInt(-1, 2)));
        // this.monsterEmeny.monsterInitial(icons[randomRangeInt(0, icons.length - 1)], this.emenyParam, this.emenyAC);
        // this.monsterEmeny.rollInitiativeOrder(1);//test 敏捷先用1

        // 加入戰鬥
        const mainCharacter = this.characterInfo.member;
        EventManager.instance.emit(CombatControllerEvent.InitiativeOrder, { mainCharacter: mainCharacter, team: [[mainCharacter], [this.monsterEmeny]] });

    }

    onBattleStartClicked(evt): void {
        evt.target.active = false;// 防止多次觸發

        EventManager.instance.emit(UIEvent.DescriptionScrollViewShowUI, false);//測試無盡戰鬥

        this.battleStart('goblinLv1');
    }
}