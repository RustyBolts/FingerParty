import { _decorator, Button, Component, instantiate, Prefab, randomRangeInt } from "cc";
import { TeamMember } from "../ui/combat/TeamMember";
import { BaseAbilities, Attribute, CompositeAbilities } from "../dungeon/Ability";
import { Character } from "../dungeon/Character";
import { EventManager } from "../managers/EventManager";
import { CharacterInfo } from "../ui/character/CharacterInfo";
import { Weapon, WeaponStyle } from "../dungeon/item/Weapon";
import { Armor } from "../dungeon/item/Armor";
import { Shield } from "../dungeon/item/Shield";
import { ParticleEffectComponent } from "./ParticleEffectComponent";
import { Inventory } from "../dungeon/inventory/Inventory";
import { warriorFeatures } from "../dungeon/ClassFeatureImplementation";
import { Adventure } from "../dungeon/adventure/AdventureSkill";
import { UIEvent } from "../managers/UIManager";
import { CombatControllerEvent } from "../ui/combat/CombatController";
const { ccclass, property } = _decorator;

@ccclass('CardCombatCheckTest')
export default class CardCombatCheckTest extends Component {
    @property(CharacterInfo)
    characterInfo: CharacterInfo = null;

    @property(ParticleEffectComponent)
    particleEffect: ParticleEffectComponent = null;

    @property(Inventory)
    inventory: Inventory = null;

    monsterEmeny: TeamMember = null;
    //test
    emenyParam: CompositeAbilities = { constitution: 5, spirit: 20, willpower: 15 };
    emenyAC: number = 10;

    protected start(): void {
        EventManager.instance.on('battleStart', this.battleStart, this);
        // 建立武器庫
        const weapons: Weapon[] = [
            new Weapon('長劍', '15 gold', 3, WeaponStyle.Longsword, 'long_swood', { dice: '1d8', dice2: '1d10', type: 'Slashing' }, ['Versatile'], 'Melee'),
            new Weapon('銅錘', '2 gold', 2, WeaponStyle.LightHammer, 'hammer', { dice: '1d4', type: 'Bludgeoning' }, ['Light', 'Thrown'], 'Melee'),//todo 可以投擲
            new Weapon('匕首', '2 gold', 1, WeaponStyle.Dagger, 'dagger', { dice: '1d4', type: 'Piercing' }, ['Finesse', 'Light', 'Thrown'], 'Melee'),//Finesse 靈巧
            new Weapon('手斧', '5 gold', 2, WeaponStyle.Handaxe, 'axe', { dice: '1d6', type: 'Slashing' }, ['Light', 'Thrown'], 'Melee'),
        ];
        weapons.forEach(weapon => this.inventory.addItem(weapon));
        const armors: Armor[] = [
            new Armor("綿甲", 'padded', "5 gold", 8, 11, 0, 'Disadvantage', 'Light'),
            new Armor("生皮甲", 'rawhide', "10 gold", 12, 12, 0, 'None', 'Medium'),
            new Armor("鎖子甲", 'chainmail', "75 gold", 55, 16, 13, 'Disadvantage', 'Heavy')
        ];
        armors.forEach(armor => this.inventory.addItem(armor));
        this.inventory.addItem(new Shield('盾牌', 'shield', '5 gold', 9, 2));

        // todo inventory的功能可以想一下直接emit事件給UIManager，UIManager再更新

        // 設定角色
        // 建立玩家能力值
        const baseAbilities: BaseAbilities = {
            [Attribute.Strength]: 15,
            [Attribute.Dexterity]: 14,
            [Attribute.Intelligence]: 13,
            [Attribute.Wisdom]: 12,
            [Attribute.Charisma]: 10,
            [Attribute.Resilience]: 8
        };
        const allocatePoints = 0;

        this.characterInfo.character = new Character('warrior', 1, baseAbilities, warriorFeatures);
        this.characterInfo.rollInitiativeOrder();//todo 不應該做在設定時，要改成發動戰鬥時骰先攻
        // test
        // console.log('巧手:', this.characterInfo.performAdventureSkillCheck(Adventure.Dexterity));
        EventManager.instance.emit(UIEvent.BaseAbilityAllocation, { allocatePoints, baseAbilities });

        // 建立敌人能力值
        const monster = instantiate(this.characterInfo.member.node);
        this.monsterEmeny = monster.getComponent(TeamMember);
        // this.monsterEmeny.initMonster(this.emenyParam, this.emenyAC);

        // this.particleEffect.setupEffect();//test
        // this.particleEffect.playEffect();
    }

    protected onDestroy(): void {
        EventManager.instance.off('battleStart', this.battleStart, this);
    }

    battleStart() {
        this.characterInfo.rollInitiativeOrder();

        // 重置並增加怪物角色
        this.emenyParam.constitution += randomRangeInt(1, 10);
        this.emenyAC = Math.min(18, Math.max(this.emenyAC, this.emenyAC + randomRangeInt(-1, 2)));
        this.monsterEmeny.monsterInitial('monster', this.emenyParam, this.emenyAC);
        this.monsterEmeny.rollInitiativeOrder(1);//test 敏捷先用1

        // 加入戰鬥
        const mainCharacter = this.characterInfo.member;
        EventManager.instance.emit(CombatControllerEvent.InitiativeOrder, { mainCharacter: mainCharacter, team: [[mainCharacter], [this.monsterEmeny]] });

    }

    onBattleStartClicked(evt): void {
        evt.target.active = false;// 防止多次觸發

        this.battleStart();
    }
}