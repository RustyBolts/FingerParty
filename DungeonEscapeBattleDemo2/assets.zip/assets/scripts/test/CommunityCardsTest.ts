import { _decorator, Component } from "cc";
import { Card } from "../cards/Card";
import { CardSuit } from "../cards/ExplorationCard";
import { EventManager } from "../managers/EventManager";
import { DeckPileEvent, GameLogicEvent } from "../managers/GameEvents";

const { ccclass, property } = _decorator;

@ccclass('CommunityCardsTest')
export default class CommunityCardsTest extends Component {
    private _deck: Card[] = [];

    protected onLoad(): void {
        EventManager.instance.on(GameLogicEvent.GameRoundStartDealCards, this.onGameRoundStartDealCards, this);
    }

    protected start(): void {
        this.initializeDeck();

        EventManager.instance.emit(DeckPileEvent.ShowCards, this._deck, this);
    }

    /** 初始化牌庫 */
    initializeDeck(): void {
        const suits = [CardSuit.Prop, CardSuit.Clue, CardSuit.Doubt, CardSuit.Presage];
        // const ranks = ['2', '3', '4', '5', '6', '7', 'A'];
        const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
        const conditions = ['stealth', 'power', 'wisdom', 'speed', 'luck'];

        for (let suit of suits) {
            for (let rank of ranks) {
                // temp
                let conditionCount = Math.floor(Math.random() * 3) + 1;  // 每張卡隨機1到3個條件
                let cardConditions = [];
                for (let i = 0; i < conditionCount; i++) {
                    cardConditions.push(conditions[Math.floor(Math.random() * conditions.length)]);
                }
                //temp

                this._deck.push({ suit, rank, conditions: cardConditions });
            }

        }
    }

    async onGameRoundStartDealCards(): Promise<void> {
        EventManager.instance.emit(DeckPileEvent.DealCommunityCards, this._deck.splice(0, 5));

        // 延遲時間後繼續發玩家牌
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.5));
        EventManager.instance.emit(DeckPileEvent.DealPlayerCards, [this._deck.splice(0, 2), this._deck.splice(0, 2), this._deck.splice(0, 2)]);
    }
}