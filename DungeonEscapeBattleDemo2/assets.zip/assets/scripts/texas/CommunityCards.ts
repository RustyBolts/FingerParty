import { _decorator, Node } from "cc";
import { Card } from "../cards/Card";
import { BaseCardDisplay } from "../cards/BaseCardDisplay";
import { CommunityCardEvent } from "../managers/GameEvents";
import { EventManager } from "../managers/EventManager";
import { CardMover } from "../tools/CardMover";
import { CardComponent } from "../cards/CardComponent";

const { ccclass, property } = _decorator;

@ccclass('CommunityCards')
export default class CommunityCards extends BaseCardDisplay {
    protected onLoad(): void {
        EventManager.instance.on(CommunityCardEvent.DealCards, this.onDealCards, this);
        EventManager.instance.on(CommunityCardEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.on(CommunityCardEvent.CompareCards, this.eventCompareCards, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(CommunityCardEvent.DealCards, this.onDealCards, this);
        EventManager.instance.off(CommunityCardEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.off(CommunityCardEvent.CompareCards, this.eventCompareCards, this);
    }

    protected start(): void {
        this.initPositionNodes(5);
        this.node.active = false;
    }

    // getCardContainer(): Node {
    //     return this.cardContainer;
    // }

    // getPositionNodes(): Node[] {
    //     return this.positionContainer.children;
    // }

    // showCards(cards: Card[]): void {
    //     super.showCards(cards);

    //     // const data = this.getCardNodes(cards).map((cardNode, index) => ({ card: cards[index], pos: cardNode.position }));
    //     // this.cardContainer.children.forEach((cardNode) => {
    //     //     cardNode.active = false;
    //     // });

    //     // EventManager.instance.emit(DeckCardEvent.DealCards, data);
    // }

    // 發牌

    dealCards(cards: Card[]): void {

        // cards.forEach((card) => this.addCardLink(card));
        this.updatePositionLayout();
        // EventManager.instance.emit(DeckCardEvent.DealCards, data);//todo 發牌後會減少 deck。之後也可以進一步，把所有需要動畫的部份，改成 basecarddisplay 上的 container child 都是定位點，讓連結的node 追隨這個點
    }

    moveDealCard(index: number, cardNode: Node): Promise<void> {
        // cardNode.getComponent(CardComponent).setup(card);
        this.node.active = true;
        const delaySec = 0.15;
        return CardMover.moveCard(cardNode, this.cardContainer, this.positionContainer.children[index].position, delaySec * 5, (index + 1) * delaySec);
    }

    // 完成比牌後，將牌組放入棄牌堆中
    dropCards(cards: Card[]): void {

    }

    clearCards(): void {
        this.cardContainer.removeAllChildren();
        this.selected = [];
    }

    // /**
    //  * 選取卡牌
    //  * @param cardData 卡片資料
    //  * @param cardNode 卡片的 Node 實體
    //  */
    // selectCard(cardData: Card, cardNode: Node) {
    //     if (this.selected.includes(cardData)) {
    //         // 卡牌已被選取，取消選取
    //         this.selected = this.selected.filter(card => card !== cardData);

    //         // 將卡牌移回原本的位置
    //         this.moveCardToOriginalContainer(cardNode);
    //     } else {
    //         // 卡牌尚未被選取，加入選取
    //         this.selected.push(cardData);

    //         // 保存原始索引
    //         this.cardOriginalIndex.set(cardNode, cardNode.getSiblingIndex());

    //         // 將卡牌移到 selectedCardDisplay，以顯示卡牌被選取的效果
    //         this.moveCardToSelectedDisplay(cardNode);
    //     }

    //     // 更新顯示卡牌實體的顯示
    //     this.updateSelectedCardDisplay(cardNode);
    // }

    /**
     * 比牌
     * @param cardNode 帶入卡牌的 Node 實體
     */
    compareCards(cardsList: Card[][]) {
        const tipCards = cardsList[0];// todo 可以做選擇，但目前預設選第一組

        // 將選取的卡牌移到 selectedCardDisplay，做出卡牌被選取的效果
        this.getCardNodes(tipCards).forEach((cardNode) => {
            // this.moveCardToSelectedDisplay(cardNode);
            this.toggleCardSelection(cardNode);
        });
    }

    //#region 接收事件

    async onDealCards(event): Promise<void> {
        this.node.active = true;

        // 取消選取所有卡牌
        await this.unselectAllCards();

        const cards = event;
        this.dealCards(cards);
    }

    async onShowCards(event): Promise<void> {
        this.node.active = true;

        // 取消選取所有卡牌
        await this.unselectAllCards();

        // this.showCards(event);
    }

    eventCompareCards(event): void {
        this.compareCards(event);
    }

    //#endregion
}