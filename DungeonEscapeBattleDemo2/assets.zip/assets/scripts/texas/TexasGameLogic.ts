import { _decorator, Component, Vec3 } from "cc";
import { Card, TipCard } from "../cards/Card";
import { CardSuit, ExplorationCard } from "../cards/ExplorationCard";
import { CommunityCardEvent, DeckPileEvent, GameLogicEvent, GameUIEvent, PlayerHandCardEvent, WordPuzzleGameLogicEvent } from "../managers/GameEvents";
import { CardEvaluations, HandEvaluator } from "../cards/HandEvaluator";
import { EventManager } from "../managers/EventManager";
import { TexasGamePlayer } from "./TexasGamePlayer";
import { FillBlanks, ReplacedTipCard } from "../tools/FillBlanks";
import WordPuzzleGameLogic from "../wordPuzzle/WordPuzzleGameLogic";

const { ccclass, property } = _decorator;

@ccclass('TexasGameLogic')
export default class TexasGameLogic extends Component {
    private _deck: Card[] = [];
    private _community: Card[] = [];
    private _players: Card[][] = [];
    private _discarded: Card[] = [];

    private _gamePlayers: TexasGamePlayer[] = [];

    private _answerTipCards: TipCard[] = [];

    protected onLoad(): void {
        EventManager.instance.on(GameLogicEvent.GameStart, this.eventGameStart, this);
        EventManager.instance.on(GameLogicEvent.GameEnd, this.eventGameEnd, this);
        EventManager.instance.on(GameLogicEvent.GameResume, this.eventGameResume, this);
        EventManager.instance.on(GameLogicEvent.GameRoundStartDiscardCards, this.eventDiscardCards, this);
        EventManager.instance.on(GameLogicEvent.GameRoundStartDealCards, this.onGameRoundStartDealCards, this);
        EventManager.instance.on(GameLogicEvent.GameRoundNextPlayerTurn, this.playerNextTurn, this);
        EventManager.instance.on(GameLogicEvent.GameRoundEndShowCards, this.endShowCards, this);
        // EventManager.instance.on(GameLogicEvent.GameRoundStartConfirmSelection, this.confirmSelection, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(GameLogicEvent.GameStart, this.eventGameStart, this);
        EventManager.instance.off(GameLogicEvent.GameEnd, this.eventGameEnd, this);
        EventManager.instance.off(GameLogicEvent.GameResume, this.eventGameResume, this);
        EventManager.instance.off(GameLogicEvent.GameRoundStartDiscardCards, this.eventDiscardCards, this);
        EventManager.instance.off(GameLogicEvent.GameRoundStartDealCards, this.onGameRoundStartDealCards, this);
        EventManager.instance.off(GameLogicEvent.GameRoundNextPlayerTurn, this.playerNextTurn, this);
        EventManager.instance.off(GameLogicEvent.GameRoundEndShowCards, this.endShowCards, this);
        // EventManager.instance.off(GameLogicEvent.GameRoundStartConfirmSelection, this.confirmSelection, this);
    }

    protected start(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.position = Vec3.ZERO;
        this.node.active = false;
    }

    //#region 初始化工作

    _intros;
    /**
     * 初始化遊戲，決定該局有多少玩家，再多就不會繼續
     * @param playersInfo 開始時玩家加入牌局的人數
     */
    initGame(playersInfo, intros): void {
        this.node.active = true;

        // todo 玩家暫存資訊
        this._gamePlayers = playersInfo;

        this._intros = intros;

        // 開始前先初始化牌庫內容
        this.initializeDeck();

        // 發事件: 將整個牌庫進行秀牌
        EventManager.instance.emit(DeckPileEvent.ShowCards, this._deck);
    }

    /** 初始化牌庫 */
    initializeDeck(): void {
        // const explorationCard = new ExplorationCard();
        // var intros = explorationCard.test().cards;
        // intros.sort(() => Math.random() - 0.5);
        const intros = this._intros;
        console.log('intros:', intros);
        const suits = [CardSuit.Prop, CardSuit.Clue, CardSuit.Doubt, CardSuit.Presage];
        // const ranks = ['2', '3', '4', '5', '6', '7', 'A'];
        const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'].slice(13 - intros.length);
        const conditions = ['stealth', 'power', 'wisdom', 'speed', 'luck'];//todo 成為不起眼的屬性，之後要改成隨機的條件

        this._deck.length = 0;

        for (let suit of suits) {
            for (let rank of ranks) {
                let index = ranks.indexOf(rank);
                var cardConditions = [];
                if (index < intros.length) {
                    cardConditions = [intros[index][suit]];
                } else {
                    // temp
                    let conditionCount = Math.floor(Math.random() * 3) + 1;  // 每張卡隨機1到3個條件
                    cardConditions = [];
                    for (let i = 0; i < conditionCount; i++) {
                        cardConditions.push(conditions[Math.floor(Math.random() * conditions.length)]);
                    }
                    //temp
                }

                this._deck.push({ suit, rank, conditions: cardConditions });
            }
        }
        // console.log('this._deck:', this._deck);

    }

    /** 洗牌 */
    shuffleDeck(): void {
        for (let i = 0; i < this._deck.length; i++) {
            const j = Math.floor(Math.random() * (i + 1));
            [this._deck[i], this._deck[j]] = [this._deck[j], this._deck[i]];
        }
    }

    //#endregion

    //#region 遊戲主線流程

    /** 遊戲開局 */
    async startGame(): Promise<void> {

        // 發牌前先洗牌
        this.shuffleDeck();

        console.log('deck:', this._deck);

        // 發牌
        await this.dealCards();

        // 等幾秒後比牌
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.5));

        this.compareCards();

        // this.determineWinner();
    }

    /** 發牌 */
    async dealCards(): Promise<void> {
        if (this._deck.length < 7) {
            throw new Error("Not enough cards in the deck.");
        }

        const playerCount = 1;//this._gamePlayers.length;

        // 玩家手牌
        this._players.forEach(player => { player.length = 0; });
        for (let i = 0; i < playerCount; i++) {
            this._players[i] = [this._deck.pop(), this._deck.pop()];
        }

        // 公牌
        this._community.length = 0;
        for (let i = 0; i < 5; i++) {
            this._community.push(this._deck.pop());
        }

        // 發事件: 更新牌組
        // EventManager.instance.emit(CommunityCardEvent.ShowCards, this._community);
        // // EventManager.instance.emit(CommunityCardEvent.DealCards, this._community);
        EventManager.instance.emit(PlayerHandCardEvent.ShowCards, this._players[0]);


        EventManager.instance.emit(DeckPileEvent.DealCommunityCards, this._community);

        // 延遲時間後繼續發玩家牌
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.5));
        EventManager.instance.emit(DeckPileEvent.DealPlayerCards, this._players);
    }

    /** 比牌 */
    compareCards(): void {
        // 牌型提示
        const cards = this._players[0].concat(this._community);//todo 未指定player
        const bestHand = this.findBestHand(cards);
        const combinations: Card[][] = this.findCombinationsForSpecificHandType(cards, bestHand);
        EventManager.instance.emit(CommunityCardEvent.CompareCards, combinations);
        EventManager.instance.emit(PlayerHandCardEvent.CompareCards, combinations);

        // 將蒐集到的條件提示標上重點字，然後秀在UI上
        const conditions = combinations[0].map(x => x.conditions[0]);//todo 德撲只處理一組，如果要處理多組的話再看要怎麼做
        const replaced:ReplacedTipCard[] = FillBlanks.replaceMarkedWithKeywords(conditions, this._answerTipCards.map(x => x.string));
        // ES6 中如果希望「陣列（Array）」的元素不會重複，可以使用 Set；如果是希望物件（Object）的鍵不會重複，則可以使用 Map。
        // const newAnswers = Array.from(new Set<TipCard>(newKeywords.flat().filter((tip:TipCard) => !this._answerTipCards.includes(tip))));// 用集合的特性去除重複的關鍵字
        // const newAnswers: TipCard[] = Array.from(new Map<string, TipCard>(replaced.flat().map(tip => [tip.string, tip])).values());
        const newAnswers:TipCard[] = replaced.map(x=>x.tipCards).flat();//todo 沒改到去除重複的，再處理
        // EventManager.instance.emit(GameUIEvent.ShowCardConditions, { conditions: replacedTexts, answers: newAnswers });// 原本用這個，去除重複只需要一次丟出關鍵字的蒐集
        EventManager.instance.emit(GameUIEvent.ShowCardConditions2, { conditions: conditions });//後來先改這個，讓答案的蒐集每個condition 都會丟一次

        // 將答案卡蒐集起來
        this._answerTipCards = this._answerTipCards.concat(newAnswers);
        EventManager.instance.emit(WordPuzzleGameLogicEvent.ShowAnswer, { answers: this._answerTipCards });
    }

    /** 決定贏家 */
    // todo 這邊用點數來決定贏家，不過我打算捨棄這個方法，之後用 推理 結果來進行贏家的決定，或是這邊的遊戲規則不需要決定贏家
    determineWinner(): void {
        let results = this._players.map((hand, index) => ({
            score: this.evaluateHand(hand.concat(this._community)),
            conditions: hand.reduce((acc, card) => acc.concat(card.conditions), []),
            index
        }));

        results.forEach(result => {
            console.log(`Player ${result.index + 1} score: ${result.score}, conditions: ${result.conditions.join(', ')}`);
        });
    }

    /** 手牌計分 */
    evaluateHand(hand: Card[]): number {
        let score = 0;
        let conditionMap: { [key: string]: number } = {};

        hand.forEach(card => {
            card.conditions.forEach(condition => {
                conditionMap[condition] = (conditionMap[condition] || 0) + 1;
            });
        });

        for (let condition in conditionMap) {
            score += conditionMap[condition];  // 簡單地將條件出現次數作為分數
        }

        return score;
    }

    async nextRound(): Promise<void> {
        // 結束一輪，更新UI
        // this.updateGameState('endRound');

        // this.updateDiscardCardsPile();

        EventManager.instance.emit(DeckPileEvent.DiscardCards, this._community.concat(this._players[0]));//

        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.5));

        if (this._deck.length < 7) {
            EventManager.instance.emit(DeckPileEvent.DeckGatherings);

            this.initializeDeck();
        }
        else {
            // 開始下一輪
            this.startGame();
        }
    }

    //#endregion

    //#region 玩家進行動作

    updateGameState(state: string): void {
        // EventManager.instance.emit(GameLogicEvent.UpdateGameState, { state: state });
    }

    playerMakesMove(playerIndex: number, move: string) {
        // EventManager.instance.emit(GameLogicEvent.PlayerActionRequired, { playerIndex: playerIndex, move: move });
    }

    /**
     * 玩家可以選擇保留或丟棄牌
     * @param playerIndex 
     * @param cardIndex 
     * @param keep 
     */
    selectOrDiscardCard(playerIndex: number, cardIndex: number, keep: boolean): void {
        if (keep) {
            console.log(`Player ${playerIndex + 1} keeps card: ${this._players[playerIndex][cardIndex].rank} of ${this._players[playerIndex][cardIndex].suit}`);
        } else {
            // 丟棄並重新抽一張牌
            this._players[playerIndex][cardIndex] = this._deck.pop();
            console.log(`Player ${playerIndex + 1} discards and draws a new card: ${this._players[playerIndex][cardIndex].rank} of ${this._players[playerIndex][cardIndex].suit}`);
        }
    }

    // confirmSelection(playerIndex: number, selectedCards: Card[]): void {
    //     console.log(`Player ${playerIndex + 1} selects cards: ${selectedCards.map(card => `${card.rank} of ${card.suit}`).join(', ')}`);
    //     // 發牌
    //     EventManager.instance.emit(GameLogicEvent.GameRoundStartShowCards, this._players[playerIndex].concat(this._community));
    // }

    // /**
    //  * 玩家可以選擇要丟棄的牌
    //  * @param playerIndex 
    //  * @param cards 
    //  */
    // discardCards(playerIndex: number, cards: Card[]): void {
    //     console.log(`Player ${playerIndex + 1} discards cards: ${cards.map(card => `${card.rank} of ${card.suit}`).join(', ')}`);
    //     // 丟棄並重新抽一張牌
    //     cards.forEach(card => {
    //         this._players[playerIndex].splice(this._players[playerIndex].indexOf(card), 1);
    //         this._deck.push(card);
    //     });
    //     // 發牌 (丟棄的牌不再出現)
    //     EventManager.instance.emit(GameLogicEvent.GameRoundStartShowCards, this._players[playerIndex].concat(this._communityCards));
    // }

    //#endregion

    //#region 處理牌型檢查

    /**
     * 從牌組中找出符合指定牌型的組合
     * @param cards 
     * @param comboLength 
     * @returns 
     */
    getCombinations(cards: Card[], comboLength: number): Card[][] {
        const combinations = [];
        const combo = [];

        function run(level: number, start: number) {
            for (let i = start; i < cards.length - (comboLength - level) + 1; i++) {
                combo[level] = cards[i];
                if (level < comboLength - 1) {
                    run(level + 1, i + 1);
                } else {
                    combinations.push(combo.slice());
                }
            }
        }

        run(0, 0);
        return combinations;
    }

    /**
     * 找出最佳牌型
     * @param cards 
     * @returns 
     */
    findBestHand(cards: Card[]): string {
        if (cards.length !== 7) throw new Error("Must evaluate exactly 7 cards.");

        const allFiveCardCombinations = this.getCombinations(cards, 5);
        let bestHand = CardEvaluations.HighCard;

        allFiveCardCombinations.forEach(combo => {
            const handEvaluation = HandEvaluator.evaluateHand(combo);
            if (this.compareHands(handEvaluation, bestHand) > 0) {
                bestHand = handEvaluation;
            }
        });

        console.log("Best hand:", bestHand);
        return bestHand;
    }

    compareHands(handOne: CardEvaluations, handTwo: CardEvaluations): number {
        const values = Object.values(CardEvaluations);
        const indexOne = values.indexOf(handOne);
        const indexTwo = values.indexOf(handTwo);
        return indexOne - indexTwo;
    }

    /**
     * 處理牌型提示: 查找并返回所有符合指定牌型的五张牌组合。
     * @param cards 要从中查找组合的七张牌数组。
     * @param targetHandType 目标牌型。
     * @returns 所有符合指定牌型的组合数组。
     */
    findCombinationsForSpecificHandType(cards: Card[], targetHandType: string): Card[][] {
        if (cards.length < 5) {
            throw new Error("Not enough cards to evaluate.");
        }

        const allFiveCardCombinations = this.getCombinations(cards, 5);
        const matchingHands: Card[][] = [];

        allFiveCardCombinations.forEach(combo => {
            const handType = HandEvaluator.evaluateHand(combo);
            if (handType === targetHandType) {
                matchingHands.push(combo);
            }
        });

        return matchingHands;
    }


    handleDiscardCards(cards: Card[]): void {
        this._discarded = this._discarded.concat(cards);
        console.log('Updated discard pile:', this._discarded);

        // 發事件: UI 處理牌庫棄牌
        EventManager.instance.emit(GameUIEvent.DeckCardDiscard, this._discarded);
    }

    //#endregion

    //#region 處理事件

    eventDiscardCards(event): void {
        const cards: Card[] = event;
        this.handleDiscardCards(cards);
    }

    playerNextTurn(playerIndex: number): void {
        // GameLogicEventemit(GameEvents.PlayerNextTurn, { playerIndex: playerIndex });

        // todo 暫時先用這個方法來進行下一輪
        this.nextRound();
    }

    endShowCards(cards: Card[]): void {
        console.log('End show cards:', cards);
        // 開始進行推理
        this.findBestHand(cards);
    }

    eventGameStart(event): void {
        console.log('Game start');

        const { playersInfo, intros } = event;
        this.initGame(playersInfo, intros);

        EventManager.instance.emit(GameUIEvent.GameStart);
    }

    eventGameResume(event): void {

        console.log('Game resume');
        // 開始前先初始化牌庫內容
        // this.initializeDeck();

    }

    eventGameEnd(event): void {
        this._community.length = 0;
        EventManager.instance.emit(CommunityCardEvent.ShowCards, this._community);

        this._players.forEach(player => { player.length = 0; });
        EventManager.instance.emit(PlayerHandCardEvent.ShowCards, this._players[0]);

        // 讓ui 知道遊戲結束
        this._answerTipCards.length = 0;
        // EventManager.instance.emit(GameUIEvent.DeckCardUnselected);
        EventManager.instance.emit(GameUIEvent.GameEnd);
        EventManager.instance.emit(WordPuzzleGameLogicEvent.WordPuzzleGameEnd);

        this.node.active = false;
    }

    onGameRoundStartDealCards(): void {
        console.log('Deal cards');
        // 開始遊戲
        this.startGame();
    }

    //#endregion

}

/**
 * 棄牌堆的卡牌仍然可以透過點擊閱讀牌面資訊，但不能取得，只能等待牌局的所有牌都被用完後，重新洗牌才會回到牌庫中。
 */