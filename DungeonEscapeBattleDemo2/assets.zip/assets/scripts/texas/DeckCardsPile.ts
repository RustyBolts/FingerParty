import { Component, _decorator, Node, Vec3 } from "cc";
import { Card } from "../cards/Card";
import { DeckPileEvent, GameLogicEvent } from "../managers/GameEvents";
import { HandEvaluator } from "../cards/HandEvaluator";
import { EventManager } from "../managers/EventManager";
import { CardMover } from "../tools/CardMover";
import { CardComponent } from "../cards/CardComponent";
import DeckCards from "./DeckCards";
import CommunityCards from "./CommunityCards";
import PlayerHandCards from "./PlayerHandCards";

const { ccclass, property } = _decorator;

@ccclass('DeckCardsPile')
export default class DeckCardsPile extends Component {
    @property(Node)
    private deckPile: Node = null;
    private deckCardsPile;

    @property(Node)
    private deckGatherings: Node = null;

    @property(Node)
    private deckDiscard: Node = null;

    @property(CommunityCards)
    private communityCards: CommunityCards = null;

    @property(PlayerHandCards)
    private playerHands: PlayerHandCards[] = [];

    protected onLoad(): void {
        EventManager.instance.on(DeckPileEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.on(DeckPileEvent.DeckGatherings, this.onDeckGatherings, this);
        EventManager.instance.on(DeckPileEvent.DiscardCards, this.onDiscardCards, this);
        EventManager.instance.on(DeckPileEvent.DealCommunityCards, this.onDealCommunityCards, this);
        EventManager.instance.on(DeckPileEvent.DealPlayerCards, this.onDealPlayerCards, this);
        EventManager.instance.on(DeckPileEvent.HideCards, this.eventHideCards, this);

        this.deckCardsPile = this.deckPile.getComponentsInChildren(DeckCards);
    }

    protected onDestroy(): void {
        EventManager.instance.off(DeckPileEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.off(DeckPileEvent.DeckGatherings, this.onDeckGatherings, this);
        EventManager.instance.off(DeckPileEvent.DiscardCards, this.onDiscardCards, this);
        EventManager.instance.off(DeckPileEvent.DealCommunityCards, this.onDealCommunityCards, this);
        EventManager.instance.off(DeckPileEvent.DealPlayerCards, this.onDealPlayerCards, this);
        EventManager.instance.off(DeckPileEvent.HideCards, this.eventHideCards, this);
    }

    protected start(): void {
        this.node.position = Vec3.ZERO;
    }

    /**
     * 顯示卡牌牌組
     * @param cards 卡牌陣列
     */
    showdDeckPile(cards: Card[]): void {
        this.deckCardsPile.forEach((cardDisplay) => cardDisplay.node.active = true);

        // 依花色分類卡牌
        const suits = HandEvaluator.groupBySuit(cards);

        // 顯示依花色分類好的卡牌牌組
        this.deckCardsPile.forEach((cardDisplay, suitIndex) => {
            const suitCards = suits[suitIndex];
            cardDisplay.initPositionNodes(suitCards.length);
            cardDisplay.showCards(suitCards);
            cardDisplay.followPosition();
            cardDisplay.setToggleSelection();
        });
    }

    // 卡牌收至 deckGatherings 節點上的動畫
    async collectAllCardsToDeckGatherings(): Promise<void> {
        for (const cardDisplay of this.deckCardsPile) {
            await cardDisplay.unselectAllCards();
            cardDisplay.stopToggleSelection();

            const cardNodes = cardDisplay.getCardContentNodes().slice();
            for (const cardNode of cardNodes) {
                await CardMover.moveCard(cardNode, this.deckGatherings, Vec3.ZERO);
            }
        }

        // 延遲後繼續流程，讓動畫跑完
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.25));
    }

    //#region 接收事件

    onShowCards(event): void {
        this.node.active = true;

        this.communityCards.clearCards();
        this.playerHands.forEach((hand) => hand.clearCards());

        this.deckGatherings.removeAllChildren();
        this.deckDiscard.removeAllChildren();

        this.showdDeckPile(event);
    }

    async onDeckGatherings(event): Promise<void> {
        this.node.active = true;

        for (const cardNode of this.deckDiscard.children.slice()) {
            // console.log('收到卡牌');
            // console.log('1this.deckDiscard.children:', this.deckDiscard.children.length);
            await CardMover.moveCard(cardNode, this.deckGatherings, Vec3.ZERO);
        }
        // console.log('2this.deckDiscard.children:', this.deckDiscard.children.length);
        // console.log('this.deckGatherings.children:', this.deckGatherings.children.length);
        // todo 查一下數量，確保卡牌內容是正確的

        // 延遲後繼續流程，讓動畫跑完
        await new Promise<void>((resolve) => this.scheduleOnce(resolve, 0.25));

        console.log('重洗');
        // 先用nextround
        EventManager.instance.emit(GameLogicEvent.GameRoundNextPlayerTurn);
    }

    async onDiscardCards(event): Promise<void> {
        this.node.active = true;
        const cards: Card[] = event;


        await this.communityCards.unselectAllCards();
        var cardNodes = this.communityCards.getCardNodes(cards).slice();
        for (const cardNode of cardNodes) {
            await CardMover.moveCard(cardNode, this.deckDiscard, Vec3.ZERO);
        }

        await this.playerHands.forEach(async (hand) => {
            await hand.unselectAllCards();
            cardNodes = hand.getCardNodes(cards).slice();
            for (const cardNode of cardNodes) {
                await CardMover.moveCard(cardNode, this.deckDiscard, Vec3.ZERO);
            }
        });
    }

    // 發公牌
    onDealCommunityCards(event): void {
        this.node.active = true;

        const deckPileNodes = this.deckGatherings.children;

        const data = event;
        console.log(data);
        var index = 0;
        data.forEach(async (card) => {
            const cardNode = deckPileNodes[deckPileNodes.length - 1];
            cardNode.getComponent(CardComponent).setup(card);
            await this.communityCards.moveDealCard(index++, cardNode);
        });
    }

    // 發玩家手牌
    onDealPlayerCards(event): void {
        const deckPileNodes = this.deckGatherings.children;
        const data = event;
        data.forEach((cards, playerIndex) => {
            // var handIndex = 0;
            // cards.forEach(async (card) => {
            //     const cardNode = deckPileNodes[deckPileNodes.length - 1];
            //     cardNode.getComponent(CardComponent).setup(card);
            //     await this.playerHands[playerIndex].dealCard(handIndex++, cardNode);
            // });//取代為下面這行
            this.playerHands[playerIndex].dealCards(cards, deckPileNodes);
        });
    }

    // 卡牌隱藏
    eventHideCards(event): void {
        this.node.active = false;
    }

    //#endregion

    //#region 點擊事件

    onDiscardClicked() {
        var selectedCards = [];

        // 取得所有被選擇的卡牌
        this.deckCardsPile.forEach((cardDisplay) => {
            if (cardDisplay.confirmSelection()) {
                // 棄牌
                cardDisplay.discardSelectedCards();

                // 取得被選擇的卡牌
                selectedCards = selectedCards.concat(cardDisplay.getSelectedCards());
            }
        });

        // 若沒有被選擇的卡牌，則不做任何事
        if (selectedCards.length == 0) {
            return;
        }

        // 通知: 丟棄被選擇的卡牌
        EventManager.instance.emit(GameLogicEvent.GameRoundStartDiscardCards, selectedCards);
    }

    async onGameStartDealClicked() {
        await this.collectAllCardsToDeckGatherings();

        // 隱藏牌匣
        this.deckCardsPile.forEach((cardDisplay) => cardDisplay.node.active = false);

        // 通知: 開始發牌
        EventManager.instance.emit(GameLogicEvent.GameRoundStartDealCards);
    }

    //#endregion
}
