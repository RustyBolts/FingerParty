import { _decorator, Component, Node, Prefab, RichText, tween, UITransform, v3, Vec3 } from "cc";
import { GameLogicEvent, GameUIEvent, WordPuzzleGameLogicEvent } from "../managers/GameEvents";
import { EventManager } from "../managers/EventManager";
import { Card } from "../cards/Card";
import { FillBlanks, ReplacedText } from "../tools/FillBlanks";
import { HandCards } from "../cards/HandCards";
// import DiscardCardsPile from "./DiscardCardsPile";
import { CardMover } from "../tools/CardMover";
import { TipClipsAnimation } from "../managers/TipClipsAnimation";
import { DescriptionScrollView } from "../tools/DescriptionScrollView";

const { ccclass, property } = _decorator;

@ccclass('TexasGameUI')
export default class TexasGameUI extends Component {
    // @property(DiscardCardsPile)
    // private discardCardsPile: DiscardCardsPile = null;

    @property(HandCards)
    private answerHandCards: HandCards = null;

    @property(RichText)
    private cardIntroLabel: RichText = null;
    @property(DescriptionScrollView)
    private descriptionScrollView: DescriptionScrollView = null;

    @property(Node)
    private BackPuzzleBtn: Node = null;

    @property(Node)
    private NextRoundBtn: Node = null;

    @property(Node)
    private DiscardCardBtn: Node = null;

    @property(Node)
    private DeckGatheringBtn: Node = null;

    @property(TipClipsAnimation)
    private answerClipsAnimation: TipClipsAnimation = null;

    protected onLoad(): void {
        // 註冊事件
        // 發牌前玩家選擇卡牌的事件 (主要用於棄牌，減少卡牌數量，提升"推理"環節的效率)
        EventManager.instance.on(GameUIEvent.GameStart, this.eventGameStart, this);
        EventManager.instance.on(GameUIEvent.GameEnd, this.eventGameEnd, this);
        EventManager.instance.on(GameUIEvent.DeckCardSelected, this.eventDeckCardSelected, this);
        EventManager.instance.on(GameUIEvent.DeckCardUnselected, this.eventDeckCardUnselected, this);
        EventManager.instance.on(GameUIEvent.DeckCardDiscard, this.eventDeckCardDiscard, this);
        // 
        EventManager.instance.on(GameUIEvent.ShowCardConditions, this.eventShowCardConditions, this);
        EventManager.instance.on(GameUIEvent.ShowCardConditions2, this.eventShowCardConditions2, this);
        // EventManager.instance.on(GameUIEvent.NewAnswersTip, this.eventNewAnswersTip, this);

        // this.answerHandCards.show(false);
    }

    protected onDestroy(): void {
        EventManager.instance.off(GameUIEvent.GameStart, this.eventGameStart, this);
        EventManager.instance.off(GameUIEvent.GameEnd, this.eventGameEnd, this);
        EventManager.instance.off(GameUIEvent.DeckCardSelected, this.eventDeckCardSelected, this);
        EventManager.instance.off(GameUIEvent.DeckCardUnselected, this.eventDeckCardUnselected, this);
        EventManager.instance.off(GameUIEvent.DeckCardDiscard, this.eventDeckCardDiscard, this);
        EventManager.instance.off(GameUIEvent.ShowCardConditions, this.eventShowCardConditions, this);
        EventManager.instance.off(GameUIEvent.ShowCardConditions2, this.eventShowCardConditions2, this);
        // EventManager.instance.off(GameUIEvent.NewAnswersTip, this.eventNewAnswersTip, this);
    }

    protected start(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.position = Vec3.ZERO;
        // this.node.active = false;

        this.answerHandCards.show(false);
    }

    // /**
    //  * 更新UI來顯示棄牌堆
    //  * @param discard 要棄掉的卡牌
    //  */
    // discardCards(discard: Card[]): void {
    //     discard.forEach(card => {
    //         this.discardCardsPile.addCardToDiscardPile(card);
    //     });
    // }

    /**
     * 更新卡牌介紹文字
     * @param text 卡牌的條件
     */
    private updateCardIntroLabel(text = '') {
        this.cardIntroLabel.string = text;
    }

    //#region 接收事件

    eventGameStart(event) {
        // this.node.active = true;

        this.BackPuzzleBtn.active = false;
        this.NextRoundBtn.active = false;
        this.DiscardCardBtn.active = false;
        this.DeckGatheringBtn.active = true;
    }

    eventGameEnd(event) {
        // this.node.active = false;// todo 結束就隱藏？

        this.BackPuzzleBtn.active = false;
        this.NextRoundBtn.active = false;
        this.DiscardCardBtn.active = false;
        this.DeckGatheringBtn.active = false;
        console.log('關!!');
        this.answerHandCards.show(false);
        this.descriptionScrollView.show(false);
    }

    eventDeckCardSelected(event) {
        const conditions = event.conditions;
        // const { replacedTexts } = FillBlanks.replaceKeywordsWidthBlanks(conditions);
        const replacedTexts: ReplacedText[] = FillBlanks.replaceKeywordsWidthBlanks(conditions);

        const text = replacedTexts.map(item => item.text).join('\n');
        this.updateCardIntroLabel(text);
        // this.updateCardIntroLabel(replacedTexts.join('\n'));
    }

    eventDeckCardUnselected(event) {
        // this.updateCardIntroLabel();
        this.descriptionScrollView.clear();
    }

    eventDeckCardDiscard(event) {
        const cards: Card[] = event;
        // this.discardCards(cards);//todo 補上

        // this.updateCardIntroLabel();
        this.descriptionScrollView.clear();
    }

    eventShowCardConditions(event) {
        const conditions = event.conditions;
        this.updateCardIntroLabel(conditions.join('\n'));

        const answers = event.answers;
        this.answerClipsAnimation.spreadCards(answers);

        this.BackPuzzleBtn.active = true;
        this.NextRoundBtn.active = true;
        this.DiscardCardBtn.active = false;
        this.DeckGatheringBtn.active = false;
    }

    eventShowCardConditions2(event) {
        console.log("event.conditions:", event.conditions);
        this.descriptionScrollView.show();
        this.descriptionScrollView.setData(event.conditions);
        // this.descriptionScrollView.setChooseButtons([{
        //     text: '確定',
        //     callback: () => {
        //         this.descriptionScrollView.close();
        //     }
        // }]);todo 做在聽DescriptionScrollViewEnd事件 

        this.BackPuzzleBtn.active = true;
        this.NextRoundBtn.active = true;
        this.DiscardCardBtn.active = false;
        this.DeckGatheringBtn.active = false;
    }

    // eventNewAnswersTip(event) {
    //     const answers = event.answers;
    //     this.answerClipsAnimation.spreadCards(answers);
    // }

    //#endregion

    //#region 發牌動畫

    // 假設有一個動畫節點已經設置在 Cocos Creator 的編輯器中
    animateCardDeal(playerNode: Node, cardNode: Node, delay: number = 0.25) {
        // 動畫移動牌到指定玩家位置
        tween(cardNode)
            .delay(delay)
            .to(0.5, { position: playerNode.position })
            .start();
    }

    //#endregion

    //#region 點擊事件

    onNextPlayerTurn() {
        this.descriptionScrollView.show(false);

        this.BackPuzzleBtn.active = false;
        this.NextRoundBtn.active = false;
        this.DiscardCardBtn.active = false;
        this.DeckGatheringBtn.active = false;

        // 發出下一位玩家的回合開始事件
        EventManager.instance.emit(GameLogicEvent.GameRoundNextPlayerTurn);
    }

    onWordPuzzleClicked() {
        // EventManager.instance.emit(WordPuzzleGameUIEvent.ShowHint);
        EventManager.instance.emit(WordPuzzleGameLogicEvent.ShowHint, { active: true });
    }

    //#endregion
}