import { _decorator, Component, instantiate, Node, Prefab, tween, Vec3 } from "cc";
import { Card } from "../cards/Card";
import { CardComponent } from "../cards/CardComponent";
// import { EventManager } from "../managers/EventManager";
// import { DiscardPileEvent } from "./GameEvents";

const { ccclass, property } = _decorator;

@ccclass('DiscardCardsPile')
export default class DiscardCardsPile extends Component {
    @property(Prefab)
    private cardPrefab: Prefab = null;

    @property(Node)
    private discardPileContainer: Node = null;

    private animating: boolean = false;  // 標記是否正在播放動畫

    // protected onLoad(): void {
    //     // EventManager.instance.on(DiscardPileEvent.ShowCards, this.eventShowCards, this);
    // }

    // protected onDestroy(): void {
    //     // EventManager.instance.on(DiscardPileEvent.ShowCards, this.eventShowCards, this);
    // }

    async addCardToDiscardPile(card: Card): Promise<void> {
        if (this.animating) {
            await this.waitForAnimation(); // 如果正在動畫中，則等待動畫完成
        }

        this.animating = true;
        const cardNode = instantiate(this.cardPrefab);
        cardNode.getComponent(CardComponent).setup(card);
        cardNode.parent = this.discardPileContainer;
        cardNode.position = Vec3.ZERO; // 設置起始位置

        await this.animateCard(cardNode);
        this.animating = false;
    }

    private async waitForAnimation(): Promise<boolean> {
        return new Promise(resolve => {
            const check = () => {
                if (!this.animating) {
                    resolve(true);
                } else {
                    setTimeout(check, 100); // 每100毫秒檢查一次
                }
            };
            check();
        });
    }

    private animateCard(cardNode: Node): Promise<boolean> {
        return new Promise(resolve => {
            // 假設動畫終點在某個固定位置
            let targetPosition = new Vec3(200, 100, 0); // 調整棄牌堆的位置
            tween(cardNode)
                .to(1, { position: targetPosition })
                .call(() => {
                    resolve(true); // 動畫完成後解決 Promise
                })
                .start();
        });
    }
}

/**
 * todo 棄牌的流程沒做，覺得起始流程的棄牌可以晚點再做
 */
