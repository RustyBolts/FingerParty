import { _decorator, instantiate, Node } from "cc";
import { Card } from "../cards/Card";
import { BaseCardDisplay } from "../cards/BaseCardDisplay";
import { PlayerHandCardEvent } from "../managers/GameEvents";
import { EventManager } from "../managers/EventManager";
import { CardComponent } from "../cards/CardComponent";
import { CardMover } from "../tools/CardMover";

const { ccclass, property } = _decorator;

@ccclass('PlayerHandCards')
export default class PlayerHandCards extends BaseCardDisplay {

    protected onLoad(): void {
        EventManager.instance.on(PlayerHandCardEvent.DealCards, this.onDealCards, this);
        EventManager.instance.on(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.on(PlayerHandCardEvent.CompareCards, this.onCompareCards, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(PlayerHandCardEvent.DealCards, this.onDealCards, this);
        EventManager.instance.off(PlayerHandCardEvent.ShowCards, this.onShowCards, this);
        EventManager.instance.off(PlayerHandCardEvent.CompareCards, this.onCompareCards, this);
    }

    protected start(): void {
        // this.initPositionNodes(2);
        this.node.active = false;
    }

    /**
     * 顯示卡片
     * @param cards 卡片資料陣列
     * @returns 
     */
    protected showCards(cards: Card[]) {
        const positionNodes = this.positionContainer.children;
        if (positionNodes.length !== cards.length) {
            console.error('卡牌數量與定位節點數量不符');
            return;
        }

        if (this.selectedCardNodes.length > 0) {
            console.error('已經有選取的卡片，請先清除之前的選取');
        }

        this.cardContainer.removeAllChildren();
        cards.forEach((card, index) => {
            const cardNode = instantiate(this.cardPrefab);
            cardNode.name = `Card_${index}`;
            cardNode.getComponent(CardComponent).setup(card);
            cardNode.parent = this.cardContainer;
            // cardNode.setPosition(positionNodes[index].position);  // 初始位置與定位節點相同
        });

        // this.updatePositionLayout();
    }

    /**
     * 比牌
     * @param cardNode 帶入卡牌的 Node 實體
     */
    compareCards(cardsList: Card[][]) {
        const tipCards = cardsList[0];// todo 可以做選擇，但目前預設選第一組

        // 將選取的卡牌移到 selectedCardDisplay，做出卡牌被選取的效果
        this.getCardNodes(tipCards).forEach((cardNode) => {
            // this.moveCardToSelectedDisplay(cardNode);
            this.toggleCardSelection(cardNode);
        });
    }

    dealCard(index: number, cardNode: Node): Promise<void> {
        this.node.active = true;
        const delaySec = 0.15;
        const position = this.positionContainer.children[index].position;
        return CardMover.moveCard(cardNode, this.cardContainer, position, delaySec * 2, (index + 1) * delaySec);
    }

    dealCards(cards: Card[], pile: Node[]): void {
        this.initPositionNodes(cards.length);
        this.followPosition();

        if (cards.length > pile.length) {
            console.error(`卡牌數量(${cards.length})超過堆疊數量(${pile.length})`);
            return;
        }

        cards.forEach(async (card, index) => {
            const cardNode = pile[pile.length - 1];
            cardNode.getComponent(CardComponent).setup(card);
            await this.dealCard(index, cardNode);
        });
    }

    clearCards(): void {
        this.cardContainer.removeAllChildren();
        this.selected = [];
    }

    //#region 接收事件

    async onDealCards(event): Promise<void> {
        this.node.active = true;

        // 取消選取所有卡牌
        await this.unselectAllCards();

        const cards = event;
        // this.dealCards(cards);
    }

    async onShowCards(event): Promise<void> {
        this.node.active = true;

        // 取消選取所有卡牌
        await this.unselectAllCards();

        this.showCards(event);
    }

    onCompareCards(event): void {
        this.compareCards(event);
    }

    //#endregion
}