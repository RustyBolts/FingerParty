export enum Role {
    PLAYER,
    MASTER
};
const PLAYER_INFO = 'YC_GAME_RECORD_INFO';

export enum GameStatus {
    GAMING,
    /** Master question */
    // GAMING->
    ASKING,     // Master 選問題卡
    // ASKING->
    ASKED,      // Master 送出問題，靜置 Player 進入 WAIT_VOTE
    // ASKED->
    REVIEW,     // Master 審閱 Player 的答題組合
    /** Player answer */
    // GAMING->
    ANSWER,
    // ANSWER->
    ANSWERING,  // Player 選答案卡
    // ANSWERING->
    FOLD,       // Player 可棄牌，並進行棄牌
    // ANSWERING | FOLD->
    ANSWERED,   // Player 送出答題，等待其他Player 完成答題
    // WAIT_VOTE,  // Player 送出答題(且可棄牌時棄完牌)，等待其他Player 完成答題
    /** Player choose : 全部玩家皆是 ANSWERED */
    VOTING,     // Player 選最差問答組合
    VOTED,      // Player 選完最差問答組合 (而 Master 是 ASKED 要選最佳問答組合)
    // WAIT_NEXT_ROUND,// Player 等待 Master 選出最佳問題組合
    /** Master choose : 全部玩家皆是 VOTED */
    PICK,       // Master 選最佳問答組合
};

export class YellowCardRecord {

    // 目前輪到作為裁判的玩家ID
    masterID = '';

    _players = {};
    _roundPlayers = [];

    // 牌庫中的問題卡
    questions = [];

    // 牌庫中的答案卡
    answers = [];

    // 正在提問中的問題
    askingQuestion = '';

    add(playerID, nickname, gameStatus) {
        this._players[playerID] = {
            nickname: nickname,
            gameStatus: gameStatus,
            win: 0,                 // 單輪勝利次數，黃牌遊戲中為硬幣
            lose: 0,                // 單輪失敗次數，黃牌遊戲中為黃牌
            answerCards: [],        // 答題時暫存的答案卡
            answerHandCards: [],
            questionHandCards: [],
            voted: 0,               // 獲得被投票的數量
            role: Role.PLAYER,
        };

        this._roundPlayers = Object.keys(this._players);
    }

    del(playerID) {
        delete this._players[playerID];
    }

    get(playerID) {
        return this._players[playerID];
    }

    clear() {
        this._players = {};
        this._roundPlayers = [];

        // 牌庫中的問題卡
        this.questions = [];

        // 牌庫中的答案卡
        this.answers = [];

        // 正在提問中的問題
        this.askingQuestion = '';

        // 清除本地暫存
        localStorage.removeItem(PLAYER_INFO);
    }

    clearAnswerCards() {
        this._roundPlayers.forEach((playerID) => this._players[playerID].answerCards.length = 0);
    }

    clearWorstVote() {
        this._roundPlayers.forEach((playerID) => this._players[playerID].voted = 0);
    }

    readData() {
        const localData = JSON.parse(localStorage.getItem(PLAYER_INFO));

        console.log('YellowCardRecord read localData:',localData);

        this.masterID = localData.masterID;

        this._players = localData.players;
        this._roundPlayers = localData.roundPlayers;

        // 牌庫中的問題卡
        this.questions = localData.questions;

        // 牌庫中的答案卡
        this.answers = localData.answers;

        // 正在提問中的問題
        this.askingQuestion = localData.askingQuestion;
    }

    writeData() {
        const localData = {
            masterID: this.masterID,
            players: this._players,
            roundPlayers: this._roundPlayers,
            questions: this.questions,
            answers: this.answers,
            askingQuestion: this.askingQuestion,
        };

        localStorage.setItem(PLAYER_INFO, JSON.stringify(localData));
    }

    // filterPlayerIdsByRole(role) {
    //     return this._roundPlayers.filter((playerID) => this._players[playerID].role === role);
    // }

    // findMasterRolePlayerId(role) {
    //     return this._roundPlayers.find((playerID) => this._players[playerID].role === role);
    // }

    // getPlayerHandCards(playerID) {
    //     return {
    //         answerHandCards: this._players[playerID].answerHandCards,
    //         questionHandCards: this._players[playerID].questionHandCards
    //     };
    // }

    // filterPlayerIdsByGameStatus(gameStatus) {
    //     return this._roundPlayers.filter((playerID) => this._players[playerID].gameStatus === gameStatus);
    // }

    // getGameStatusPlayers() {
    //     return this._roundPlayers.map((playerID) => this._players[playerID]);
    //     //     const { nickname, gameStatus } = this._players[playerID];
    //     //     return { nickname, gameStatus };
    //     // });
    // }

    // roundClear() {
    //     this._roundPlayers.forEach((playerID) => {
    //         this._players[playerID].answerCards.length = 0;
    //         this._players[playerID].voted.length = 0;
    //     });
    // }

    // filterHoldPlayerIds() {
    //     return this._roundPlayers.filter((playerID) => this._players[playerID].answerCards.length === 0);
    // }

    // addPlayerVoted(playerID) {
    //     this._players[playerID].voted++;
    // }

    // addPlayerCoin(playerID) {
    //     this._players[playerID].win++;
    // }

    // addPlayerYellowCard(playerID) {
    //     this._players[playerID].lose++;
    // }

    dropAnswerHandCards(playerID, cards) {
        this.dropHandCard(this._players[playerID].answerHandCards, cards);
    }

    // dropQuestionHandCards(playerID, cards) {
    //     this.dropHandCard(this._players[playerID].questionHandCards, cards);
    // }

    dropHandCard(handCards, cards) {
        return cards.every((card) => {
            return handCards.find((handCard, i, ary) => {
                if (handCard === card) {
                    ary.splice(i, 1);
                    return true;
                }
            });
        });
    }

    // getHeighestVotedPlayerId() {
    //     return this._roundPlayers.sort((a, b) => this._players[a].voted - this._players[b].voted)[0];
    // }

    // getLosePlayer() {
    //     const getScore = ({ win, lose }) => win - lose;
    //     return this._roundPlayers.sort((a, b) => getScore(this._players[a]) - getScore(this._players[b]))[0];
    // }
}