import { _decorator, Button, CCInteger, Color, Component, instantiate, Layout, Node, Prefab, Sprite, Tween, tween, UITransform, Vec3 } from "cc";
import { Card } from "../cards/Card";
import { CardComponent } from "../cards/CardComponent";

const { ccclass, property } = _decorator;

@ccclass('BaseCardDisplay')
export abstract class BaseCardDisplay extends Component {
    @property(Prefab)
    protected cardPrefab: Prefab = null;

    @property(Node)
    protected positionContainer: Node = null;  // 存放定位節點

    @property(Node)
    protected cardContainer: Node = null;  // 存放所有卡牌節點

    @property(CCInteger)
    protected selectedPositionY: number = 50;
    private oriPositionY: number = 0;

    protected selected: Card[] = [];

    protected selectedCardNodes: Node[] = [];
    private originalIndexMap: Map<Node, number> = new Map();  // 用於保存原始 siblingIndex

    /**
     * 初始化定位節點
     * @param length 定位節點數量
     */
    initPositionNodes(length: number) {
        this.positionContainer.removeAllChildren();

        for (let i = 0; i < length; i++) {
            const positionNode = new Node();  // 創建定位用節點
            positionNode.name = `Position_${i}`;
            positionNode.parent = this.positionContainer;
            positionNode.addComponent(Sprite).color = Color.RED;
            positionNode.getComponent(UITransform).setContentSize(100, 100);
        }

        // this.updatePositionLayout();
    }

    // 讓卡牌位置跟隨定位點
    followPosition() {
        this.node.active = true;
        this.updatePositionLayout();

        const cardNodes = this.cardContainer.children;
        const positionNodes = this.positionContainer.children;
        console.log('followPosition cardNodes.length:', cardNodes.length);
        console.log('followPosition positionNodes.length:', positionNodes.length);
        if (cardNodes.length !== positionNodes.length) {
            console.error('卡牌數量與定位節點數量不符');
            return;
        }
        positionNodes.forEach((positionNode, index) => {
            const cardNode = cardNodes[index];
            cardNode.setPosition(positionNode.position);
            console.log('followPosition positionNode.position:', positionNode.position);
        });
    }

    // /**
    //  * 顯示卡片
    //  * @param cards 卡片資料陣列
    //  * @returns 
    //  */
    // protected showCards(cards: Card[]) {
    //     const positionNodes = this.positionContainer.children;
    //     if (positionNodes.length !== cards.length) {
    //         console.error('卡牌數量與定位節點數量不符');
    //         return;
    //     }

    //     if (this.selectedCardNodes.length > 0) {
    //         console.error('已經有選取的卡片，請先清除之前的選取');
    //     }

    //     this.cardContainer.removeAllChildren();
    //     cards.forEach((card, index) => {
    //         const cardNode = instantiate(this.cardPrefab);
    //         cardNode.name = `Card_${index}`;
    //         cardNode.getComponent(CardComponent).setup(card);
    //         cardNode.parent = this.cardContainer;
    //         // cardNode.setPosition(positionNodes[index].position);  // 初始位置與定位節點相同
    //     });

    //     // this.updatePositionLayout();
    // }

    setToggleSelection(onCompleted: (isSelected: boolean) => void = null) {
        this.cardContainer.children.forEach((cardNode) => {
            cardNode.on('click', () => this.toggleCardSelection(cardNode, onCompleted), this);
        });
    }

    stopToggleSelection() {
        this.cardContainer.children.forEach((cardNode) => {
            cardNode.off('click');
        });
    }

    /**
     * 選取或取消選取卡片
     * @param cardNode 選定卡片的實體
     * @param onCompleted 選取或取消選取完成後的回呼函式
     */
    protected toggleCardSelection(cardNode: Node, onCompleted: (isSelected: boolean) => void = null): void {
        // 檢查是否已選取，根據當前狀態切換
        const isSelected = this.selectedCardNodes.includes(cardNode);
        if (isSelected) {
            this.selectedCardNodes = this.selectedCardNodes.filter(c => c !== cardNode);
            const originalIndex = this.originalIndexMap.get(cardNode) || 0;
            cardNode.setSiblingIndex(originalIndex);  // 恢復原始索引
        } else {
            this.selectedCardNodes.push(cardNode);
            this.originalIndexMap.set(cardNode, cardNode.getSiblingIndex());
            cardNode.setSiblingIndex(this.cardContainer.children.length - 1);  // 提升至最高
        }

        const targetY = isSelected ? 0 : this.selectedPositionY;
        this.animateSelectCardMovement(cardNode, targetY).then(() => {
            onCompleted?.(isSelected);
            console.log('toggleCardSelection selectedCardNodes:', this.selectedCardNodes);
        });
    }

    protected updatePositionLayout() {
        const layout = this.positionContainer.getComponent(Layout);

        // 刷新 Layout 並顯示卡片
        layout.enabled = true;
        layout.updateLayout();

        // 關閉 Layout，避免後續選取卡片後，卡片順序錯亂
        layout.enabled = false;
    }

    /** 取消所有卡牌選取 */
    unselectAllCards(): Promise<void[]> {
        console.log('取消所有共', this.selected.length, '張卡牌選取');

        this.selected.length = 0;
        return Promise.all(
            this.selectedCardNodes.map((cardNode) => {
                return this.animateSelectCardMovement(cardNode, 0).then(() => {
                    this.selectedCardNodes = this.selectedCardNodes.filter(c => c !== cardNode);
                    const originalIndex = this.originalIndexMap.get(cardNode) || 0;
                    cardNode.setSiblingIndex(originalIndex);  // 恢復原始索引
                });
            })
        );
    }

    /**
     * 以卡片資料陣列取得卡片的 Node 實體
     * @param cards 卡片資料陣列
     * @returns 
     */
    getCardNodes(cards: Card[]): Node[] {
        const cardNodes: Node[] = [];
        this.cardContainer.children.forEach((cardNode) => {
            const cardComponent: CardComponent = cardNode.getComponent(CardComponent);
            cards.find((card) => {
                if (cardComponent && cardComponent.card === card) {
                    cardNodes.push(cardNode);
                }
            });
        });
        return cardNodes;
    }

    /**
     * 動畫卡片移動
     * @param cardNode 卡片的 Node 實體 
     * @param deltaY 移動的 y 軸增量
     */
    protected animateSelectCardMovement(cardNode: Node, deltaY: number): Promise<void> {
        const button = cardNode.getComponent(Button);
        button.interactable = false;

        return new Promise(resolve => {
            // 使用現有的 y 位置並加上 deltaY 來計算新位置
            let newY = this.oriPositionY + deltaY;

            // 創建一個新的 Vec3 為目標位置，只改變 y 軸
            let targetPosition = new Vec3(cardNode.position.x, newY, cardNode.position.z);

            // 開始動畫
            tween(cardNode)
                .to(0.25, { position: targetPosition }, { easing: 'quadInOut' })
                .call(() => {
                    button.interactable = true;
                    resolve();
                })
                .start();
        });
    }
}


// @property(Node)
// protected selectedCardDisplay: Node = null;

// /**
//  * 顯示卡牌
//  * @param cards 卡片資料陣列
//  */
// showCards(cards: Card[]) {
//     this.cardContainer.removeAllChildren();

//     if (this.selectedCardDisplay.children.length > 0) {
//         console.error('已經有選取的卡片，請先清除之前的選取');
//         this.selectedCardDisplay.removeAllChildren();
//     }

//     // 建立卡片實體與填入資料，並設定點擊事件
//     cards.forEach((card, index) => {
//         const cardNode = this.createCardNode(card);
//         cardNode.name = `card_${index}`;
//         cardNode.on('click', (event) => this.selectCard(card, event.target), this);//todo 不一定每個都需要點擊，可以想一下要不要改掉
//     });

//     this.updateLayout();
// }

// protected createCardNode(card: Card): Node {
//     const cardNode = instantiate(this.cardPrefab);
//     cardNode.parent = this.cardContainer;
//     cardNode.getComponent(CardComponent).setup(card);
//     return cardNode;
// }

// /**
//  * 選取卡牌
//  * @param cardData 卡片資料
//  * @param cardNode 卡片的 Node 實體
//  */
// abstract selectCard(cardData: Card, cardNode: Node): void;

// /**
//  * 更新顯示卡牌實體的顯示
//  * @param cardNode 卡片的 Node 實體
//  */
// protected updateSelectedCardDisplay(cardNode: Node) {
//     // 檢查是否已選取，根據當前狀態切換
//     let isSelected = cardNode.position.y > 0;

//     let targetY = isSelected ? this.selectedPositionY : 0;
//     this.animateCardMovement(cardNode, targetY).then(() => {
//         // // console.log('動畫完成');
//         // // 進一步的邏輯處理

//         // // 原本是被選取的
//         // if (isSelected) {
//         //     // 恢復到原始的 siblingIndex
//         //     cardNode.setSiblingIndex(this.cardOriginalIndex.get(cardNode));
//         // }
//     });
// }

// /**
//  * 將卡牌移動到 selectedCardDisplay 並顯示
//  * @param cardNode 卡片的 Node 實體
//  */
// protected moveCardToSelectedDisplay(cardNode: Node) {
//     // 獲取卡牌在世界座標系中的位置
//     const worldPosition = this.cardContainer.getComponent(UITransform).convertToWorldSpaceAR(cardNode.position);

//     // 將卡牌從原父節點移除
//     cardNode.removeFromParent();

//     // 添加到新的父節點
//     cardNode.parent = this.selectedCardDisplay;

//     // 將世界座標轉換為新父節點的局部座標
//     const localPosition = this.selectedCardDisplay.getComponent(UITransform).convertToNodeSpaceAR(worldPosition);
//     cardNode.setPosition(localPosition);

//     // 更新顯示卡牌實體的動畫顯示
//     this.updateSelectedCardDisplay(cardNode);
// }

// /**
//  * 將卡牌移動回原本的位置
//  * @param cardNode 卡片的 Node 實體
//  */
// protected moveCardToOriginalContainer(cardNode: Node) {
//     // 獲取卡牌在世界座標系中的位置
//     const worldPosition = this.selectedCardDisplay.getComponent(UITransform).convertToWorldSpaceAR(cardNode.position);

//     // 將卡牌從當前父節點移除
//     cardNode.removeFromParent();

//     // 將卡牌添加回一般卡牌容器
//     cardNode.parent = this.cardContainer;

//     // 將世界座標轉換為一般卡牌容器的局部座標
//     const localPosition = this.cardContainer.getComponent(UITransform).convertToNodeSpaceAR(worldPosition);
//     cardNode.setPosition(localPosition);

//     // 更新顯示卡牌實體的動畫顯示
//     this.updateSelectedCardDisplay(cardNode);
// }


