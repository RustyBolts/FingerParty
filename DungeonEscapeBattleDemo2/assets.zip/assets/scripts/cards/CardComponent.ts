import { Component, Label, _decorator } from "cc";
import { Card } from "./Card";

const { ccclass, property } = _decorator;

@ccclass("CardComponent")
export class CardComponent extends Component {

    @property(Label)
    private cardSuit: Label = null;

    @property(Label)
    private cardRank: Label = null;

    card: Card;

    setup(card: Card) {
        this.card = card;

        this.cardSuit.string = ["♠", "♥", "♦", "♣"][card.suit];//test
        this.cardRank.string = card.rank;
    }
}