import { Card } from './Card';
import { CardSuit } from './ExplorationCard';

export enum CardEvaluations {
    HighCard = 'High Card',
    OnePair = 'One Pair',
    TwoPairs = 'Two Pairs',
    ThreeOfAKind = 'Three of a Kind',
    Straight = 'Straight',
    Flush = 'Flush',
    FullHouse = 'Full House',
    FourOfAKind = 'Four of a Kind',
    StraightFlush = 'Straight Flush',
    RoyalFlush = 'Royal Flush'
}

export class HandEvaluator {
    static evaluateHand(cards: Card[]): CardEvaluations {
        if (cards.length !== 5) throw new Error("Must evaluate exactly 5 cards.");

        const rankCounts = this.countRanks(cards);
        const suits = this.groupBySuit(cards);

        if (this.isRoyalFlush(suits)) return CardEvaluations.RoyalFlush;
        else if (this.isStraightFlush(suits)) return CardEvaluations.StraightFlush;
        else if (this.isFourOfAKind(rankCounts)) return CardEvaluations.FourOfAKind;
        else if (this.isFullHouse(rankCounts)) return CardEvaluations.FullHouse;
        else if (this.isFlush(suits)) return CardEvaluations.Flush;
        else if (this.isStraight(cards)) return CardEvaluations.Straight;
        else if (this.isThreeOfAKind(rankCounts)) return CardEvaluations.ThreeOfAKind;
        else if (this.isTwoPairs(rankCounts)) return CardEvaluations.TwoPairs;
        else if (this.isOnePair(rankCounts)) return CardEvaluations.OnePair;
        else return CardEvaluations.HighCard;
    }

    static countRanks(cards: Card[]) {
        const rankCounts = {};
        cards.forEach(card => {
            rankCounts[card.rank] = (rankCounts[card.rank] || 0) + 1;
        });
        return rankCounts;
    }

    static groupBySuit(cards: Card[]) {
        const suits = { [CardSuit.Prop]: [], [CardSuit.Clue]: [], [CardSuit.Doubt]: [], [CardSuit.Presage]: [] };
        cards.forEach(card => suits[card.suit].push(card));
        return suits;
    }

    static isRoyalFlush(suits) {
        return this.isStraightFlush(suits) && Object.values(suits).some((suit: Card[]) => suit.some(card => card.rank === '10'));
    }

    static isStraightFlush(suits) {
        return Object.values(suits).some((suit: Card[]) => suit.length >= 5 && this.isStraight(suit));
    }

    static isFourOfAKind(rankCounts) {
        return Object.values(rankCounts).some(count => count === 4);
    }

    static isFullHouse(rankCounts) {
        const threes = Object.values(rankCounts).filter(count => count === 3).length;
        const twos = Object.values(rankCounts).filter(count => count === 2).length;
        return threes > 0 && (twos > 0 || threes > 1);
    }

    static isFlush(suits) {
        return Object.values(suits).some((suit: Card[]) => suit.length >= 5);
    }

    static isStraight(cards: Card[]) {
        if (cards.length < 5)
            return false;

        const uniqueRanks = [...new Set(cards.map(card => this.getCardValue(card.rank)))];
        uniqueRanks.sort((a, b) => a - b);
        for (let i = 0; i < uniqueRanks.length - 4; i++) {
            let straight = true;
            for (let j = i; j < i + 4; j++) {
                if (uniqueRanks[j + 1] !== uniqueRanks[j] + 1) {
                    straight = false;
                    break;
                }
            }
            if (straight) return true;
        }
        return false;
    }

    static isThreeOfAKind(rankCounts) {
        return Object.values(rankCounts).some(count => count === 3);
    }

    static isTwoPairs(rankCounts) {
        const pairs = Object.values(rankCounts).filter(count => count === 2).length;
        return pairs >= 2;
    }

    static isOnePair(rankCounts) {
        return Object.values(rankCounts).some(count => count === 2);
    }

    static getCardValue(rank: string): number {
        const values = { '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14 };
        if (values.hasOwnProperty(rank)) {
            return values[rank];
        } else {
            throw new Error("Invalid card rank specified: " + rank);
        }
    }
}
