import { _decorator, Button, Color, Component, EventHandler, instantiate, Label, Node, Sprite, UITransform } from 'cc';
import { DynamicWidthScrollView } from '../tools/DynamicWidthScrollView';
import { TipCard } from './Card';
const { ccclass, property } = _decorator;

@ccclass('HandCards')
export class HandCards extends Component {

    @property(Node)
    cardRoot: Node = null;

    @property(Button)
    sendButton: Button = null;

    @property(DynamicWidthScrollView)
    dwScrollView: DynamicWidthScrollView = null;

    @property(Color)
    selectedColor: Color;

    _selectMax: number = 0;
    _secletedCards: TipCard[] = [];
    _buttonTemps: Button[] = [];
    _eventSendCallback: Function = null;

    _oriColor: Color;
    _oriPositionY: number;

    // protected start(): void {
    // }

    setSendData(selectMax: number, eventSendCallback: Function): void {
        this._selectMax = selectMax;
        this._eventSendCallback = eventSendCallback;
    }

    show(active: boolean): void {
        console.log((active ? '顯示' : '隱藏'), this.node.name);
        this.node.active = active;
        this.sendButton.node.active = false;
    }

    list(cards: TipCard[], clickCallback: Function = null): void {
        const cardChildren = this.cardRoot.children;
        const color = cardChildren[0].getComponentInChildren(Sprite).color;
        this._oriColor = new Color(color.r, color.g, color.b, color.a);

        this._oriPositionY = cardChildren[0].position.y;
        cardChildren.forEach(x => {
            x.setPosition(x.position.x, this._oriPositionY);
            x.active = false;
        });

        this._buttonTemps.length = 0;
        cards.forEach((card, i) => {
            var cardNode = cardChildren[i];
            if (!cardNode) {
                cardNode = instantiate(cardChildren[0]);
                cardNode.parent = this.cardRoot;
            }

            cardNode.active = true;
            cardNode.getComponentInChildren(Label).string = card.string;

            const cardButton: Button = cardNode.getComponentInChildren(Button);
            if (!cardButton) {
                console.error('HandCards: cardButton not found');
                return;
            }

            // cardButton.node.hasEventListener(Button.EventType.CLICK) && cardButton.node.removeEventListener(Button.EventType.CLICK, cardButton.node._eventMap[Button.EventType.CLICK][0].callback);
            cardButton.node.off(Button.EventType.CLICK);
            cardButton.node.on(Button.EventType.CLICK, () => {
                // 選擇重複卡片，做取消
                if (this._secletedCards.indexOf(card) === -1) {
                    this._secletedCards.push(card);
                    cardNode.setPosition(cardNode.position.x, cardNode.position.y + 50);
                    cardNode.getComponentInChildren(Sprite).color = this.selectedColor;
                } else {
                    this._secletedCards.splice(this._secletedCards.findIndex(x => x === card), 1);
                    cardNode.setPosition(cardNode.position.x, this._oriPositionY);
                    cardNode.getComponentInChildren(Sprite).color = this._oriColor;
                }

                clickCallback?.(card, this._secletedCards);

                // 符合選卡數量的上限，讓送出按鈕顯示
                this.sendButton.node.active = this._secletedCards.length === this._selectMax;
            }, this);

            // 暫存後，後續可禁用/啟動調用事件
            this._buttonTemps.push(cardButton);
        });

        // 滑到置中位置
        this.dwScrollView?.scrollView.scrollToPercentHorizontal(0.5, 0.1, true);
    }

    lock(bool: boolean = true): void {
        this._buttonTemps.forEach(button => button.enabled = !bool);
    }

    clear(): void {
        this.unselect();
        this._buttonTemps.length = 0;
        this._selectMax = 0;
        this._eventSendCallback = null;
        this.sendButton.node.active = false;
        // this.lock(false);
    }

    unselect(): void {
        this.cardRoot.children.forEach(cardNode => {
            if (cardNode.active) {
                cardNode.setPosition(cardNode.position.x, this._oriPositionY);
                cardNode.getComponentInChildren(Sprite).color = this._oriColor;
            }
        });
        this._secletedCards.length = 0;
        this.sendButton.node.active = false;
    }

    onSendButtonClicked(): void {
        if (this._selectMax === this._secletedCards.length) {
            // console.log('this._secletedCards:', this._secletedCards);

            this._eventSendCallback?.(this._secletedCards.slice());
            this.unselect();
        }
    }

    private sample(): void {
        const tipCards: TipCard[] = [];
        for (let i = 0; i < 10; i++) {
            const card = new TipCard();
            card.string = 'card' + i;
            card.type = 'ok';
            tipCards.push(card);
        }
        this.list(tipCards, (card) => console.log(card));
        this.sendButton.node.active = false;

        this.lock(false);
    }

}


