import { _decorator, Button, Color, Component, instantiate, Label, Node, Sprite, UITransform } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('FoldCards')
export class FoldCards extends Component {

    @property(Node)
    cardRoot: Node = null;

    @property(Button)
    sendButton: Button = null;

    eventSendCallback: Function = null;

    _secletedCards = [];
    selectMax = 0;

    _oriColor;

    // start() {
    //     this.list(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o'], (card) => console.log(card));
    //     this.sendButton.node.active = false;
    //     this.selectMax = 2;
    // }

    show(boo) {
        this.node.active = boo;
        this.sendButton.node.active = false;
        this._secletedCards.length = 0;
    }

    list(cards, clickCallback?) {
        const cardChildren = this.cardRoot.children;
        cardChildren.forEach(x => x.active = false);

        const color = cardChildren[0].getComponent(Sprite).color;
        this._oriColor = new Color(color.r, color.g, color.b, color.a);

        cards.forEach((card, i) => {
            var cardNode = cardChildren[i];
            if (!cardNode) {
                cardNode = instantiate(cardChildren[0]);
                cardNode.parent = this.cardRoot;
            }

            cardNode.active = true;

            cardNode.getComponentInChildren(Label).string = card;
            cardNode.off('click');
            cardNode.on('click', () => {
                clickCallback?.(card);

                if (this._secletedCards.indexOf(card) === -1) {
                    this._secletedCards.push(card);
                    cardNode.getComponent(Sprite).color = Color.RED;
                } else {
                    // 選擇重複卡片，做取消
                    this._secletedCards.splice(this._secletedCards.findIndex(x => x === card), 1);
                    cardNode.getComponent(Sprite).color = this._oriColor;
                }

                console.log('this._secletedCards:', this._secletedCards);

                // 符合選卡數量的上限，讓送出按鈕顯示
                this.sendButton.node.active = this._secletedCards.length === this.selectMax;
            }, this);

        });
    }

    onSendButtonClicked() {
        console.log('this._secletedCards:', this._secletedCards);

        this.cardRoot.children.forEach(x => x.getComponent(Sprite).color = this._oriColor);

        this.eventSendCallback?.(this._secletedCards.slice());
        this._secletedCards.length = 0;
    }
}


