import { _decorator, Component, Node, Vec3, EventTouch, Prefab, instantiate, UITransform } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('StoryCardStack')
export class StoryCardStack extends Component {
    @property(Prefab)
    cardPrefab: Prefab = null;

    @property(Node)
    stackNode: Node = null;

    @property
    triggerHeight = 300; // 拖動觸發的高度

    private movingCard: Node = null;

    onLoad() {
        this.generateCardStack();
    }

    generateCardStack() {
        for (let i = 0; i < 10; i++) {
            const card = instantiate(this.cardPrefab);
            card.setParent(this.stackNode);
            card.position = new Vec3(0, -i * 5, 0); // 稍微重疊
            card.scale = new Vec3(0.2, 0.2, 0.2); // 初始比例
            this.registerCardEvents(card);
        }
    }

    registerCardEvents(card) {
        card.on(Node.EventType.TOUCH_MOVE, this.onCardMove, this);
        card.on(Node.EventType.TOUCH_END, this.onCardRelease, this);
    }

    onCardMove(event) {
        if (!this.movingCard) {
            this.movingCard = event.currentTarget;
        }
        const touchPoint = event.getUILocation();
        const newPos = this.node.getComponent(UITransform).convertToNodeSpaceAR(new Vec3(touchPoint.x, touchPoint.y, 0));
        this.movingCard.position = newPos;

        // 根據位置變化卡片大小
        let factor = Math.min(1, (newPos.y - this.stackNode.position.y) / this.triggerHeight);
        this.movingCard.scale = new Vec3(0.2 + 0.8 * factor, 0.2 + 0.8 * factor, 1);
    }

    onCardRelease(event) {
        const endPos = event.currentTarget.position;
        if (endPos.y >= this.triggerHeight) {
            this.triggerAction();
        }
        // 返回堆疊或更新位置
        this.movingCard = null;
    }

    triggerAction() {
        console.log("Triggered Action at Height!");
        // 實現回調觸發的具體工作，如更新UI、處理數據等
    }
}
