import { SocketBridge } from "../connection/SocketBridge";
import { GameStatus, Role, YellowCardRecord } from "./YellowCardRecord";

export class YellowCardHandler {
    _isHonster = false;
    _roomID = '';

    _honstCardMax = {
        q: 2,
        a: 13
    };

    /** Honster */

    // Honster 暫存的回合資訊
    _honstRoundPlayers = [];
    _honstRoundIndex = 0;

    // // 暫存裁判提出的問題題目
    // _honstAskingQuestion = '';
    // 改成 player.askingQuestion

    // 暫存玩家回覆的問題答案
    _honstQuestionAnswers = {};
    // 改成 player.answerCards = [];

    // 投出最差的組合
    _honstWorstList = [];

    /** Common */

    // 輪到成為裁判的玩家ID
    _masterID = '';

    // 自己的玩家ID 與資訊
    _playerID = '';
    _myNickname = '';

    // 結束遊戲的黃牌數
    _loseNum = 5;

    /** 介面 */
    _honstGameRecord = null;

    eventUpdateQuestionCards: Function = null;
    eventUpdateAnswerCards: Function = null;
    eventShowQuestion: Function = null;
    eventLockQuestionSelection: Function = null;
    eventLockAnswerSelection: Function = null;
    eventShowQuestionAnswer: Function = null;
    eventShowAllQuestionAnswer: Function = null;
    eventChooseQuestionAnswer: Function = null;
    eventVoted: Function = null;
    eventAnswerCardFold: Function = null;
    eventShowBestAnswer: Function = null;
    eventShowTip: Function = null;
    eventClearPrevRound: Function = null;
    eventRecordLose: Function = null;
    eventGameEnd: Function = null;

    constructor(playerID, nickname) {
        this._playerID = playerID;
        this._myNickname = nickname;
    }

    /**
     * 向 Honster 發出請求
     * @param key 
     * @param value 
     */
    applicate(key, value = '') {
        console.log('===== applicate:', key, value);
        if (!this._isHonster) {
            SocketBridge.Instance.applicate(key, value);
        } else {
            console.log(key, 'Applicate 事件不透過連線發給自己:', value);
            this[`notify_${key}`](this._roomID, key, value);
        }
    }

    /**
     * 廣播時對指定 Client 發送
     * @param key 
     * @param value 
     * @param clientID 不帶指定 client id 時，對全部有紀錄的client 廣播
     */
    _broadcast(key, value = '', clientID?) {
        console.log('===== broadcast:', key, value);
        if (this._isHonster) {
            // console.log(key, value, 'clientID?:', clientID);
            if (clientID === this._playerID) {
                return console.log(key, 'Broadcast 事件不透過連線發給自己:', value);
            }
            SocketBridge.Instance.broadcast(key, value, clientID);
        }
    }

    /**
     * 啟動，開始遊戲的建置流程
     * @param roomID 
     * @param players 
     */
    startGame(roomID, isReconnect, players?) {
        this._roomID = roomID;

        // Honster 管理玩家
        if (players) {
            this._isHonster = true;

            this._honstGameRecord = new YellowCardRecord();

            this._honstRoundPlayers = Object.keys(players);

            // 結束條件會依照人數調整
            const playerNum = this._honstRoundPlayers.length;
            if (playerNum < 6) {
                this._loseNum = 6;
            } else if (playerNum < 8) {
                this._loseNum = 5;
            } else {
                this._loseNum = 4;
            }

            if (isReconnect) {
                this._honstGameRecord.readData();
            } else {
                this._honstRoundPlayers.forEach((playerID) => {
                    this._honstGameRecord.add(playerID, players[playerID], GameStatus.GAMING);
                });
            }
        }

        SocketBridge.Instance.addDispatcher(roomID, this, {
            'update_game_step': this.notify_update_game_step,
            'game_round': this.notify_game_round,
            'draw_question_cards': this.notify_draw_question_cards,
            'draw_answer_cards': this.notify_draw_answer_cards,
            'licensing': this.notify_licensing,
            'fold_answer_card': this.notify_fold_answer_card,
            'question': this.notify_question,
            'answer': this.notify_answer,
            'question_answers_result': this.notify_question_answers_result,
            'choose_best_answer': this.notify_choose_best_answer,
            'vote': this.notify_vote,
            'vote_result': this.notify_vote_result,
            'alert': this.notify_alert,
            'next_round': this.notify_next_round,
            'game_over': this.notify_game_over,
            'reconnect': this.notify_reconnect,
        });

        if (this._isHonster) {
            // Honster 建立連線
            // SocketBridge.Instance.addHonsterConnection(roomID);

            console.log('HONSTER 連線!!');

            if (isReconnect) {
                // 進行重連繼續
                this.applicate('reconnect', this._playerID);
            } else {
                // 下載問題卡牌庫
                this.updateQuestionAsync()
                    .then(() => console.log('已下載問題卡牌庫'))
                    // 下載答案卡牌庫
                    .then(() => this.updateAnswerAsync())
                    .then(() => console.log('已下載答案卡牌庫'))
                    // 開始回合
                    .then(() => this.applicate('game_round'));
            }
        } else {
            console.log('CLIENT 連線!!');

            // Client 建立連線
            // SocketBridge.Instance.addClientConnection(roomID, this._playerID);

            /** 斷線重連 */
            isReconnect && this.applicate('reconnect', this._playerID);
        }
    }

    /**
     * 結束，清除遊戲執行的資訊
     * @param roomID 
     */
    endGame(roomID) {
        SocketBridge.Instance.removeDispatcher(roomID, this);

        if (this._isHonster) {
            this._honstGameRecord.clear();
            this._honstGameRecord = null;

            this._honstRoundPlayers.length = 0;
            this._honstRoundIndex = 0;
        }

        this._masterID = '';

        // 自己的玩家ID 與資訊
        this._playerID = '';
        this._myNickname = '';
    }

    /** 更新問題卡牌庫 */
    updateQuestionAsync() {
        // 資料庫限制3組資料可供下載 todo 之後可能開放，可以抓最大數量
        const dataLength = 3;
        var index = Math.round(Math.random() * dataLength);

        return SocketBridge.Instance.loadAsync('Question', index.toString())
            .then((data: any) => this._honstGameRecord.questions = data.sort(() => Math.random() - 0.5));
    }

    /** 更新答案卡牌庫 */
    updateAnswerAsync() {
        const dataLength = 2;
        var index = Math.round(Math.random() * 1000 % dataLength);

        return SocketBridge.Instance.loadAsync('Answer', index.toString())
            .then((data: any) => this._honstGameRecord.answers = data.sort(() => Math.random() - 0.5));
    }

    tryAllAnswered() {
        // 如果全部玩家都答完題了/或(當需要時)棄完牌
        var allDone = this._honstRoundPlayers.every((playerID) => {
            if (this._masterID === playerID)
                return true;

            // 找出所有還在 ANSWERING 狀態的玩家，並送出 alert
            const player = this._honstGameRecord.get(playerID);
            return player.gameStatus === GameStatus.ANSWERED;
        });

        if (allDone) {
            console.log('全部都答題了，開始投票');

            // 確認全部都答完題了，再一次全員變更遊戲狀態
            this._honstRoundPlayers.forEach((playerID) => {
                if (this._masterID === playerID)
                    return;

                this._honstGameRecord.get(playerID).gameStatus = GameStatus.VOTING;
            });
        }

        // 更新本地暫存資訊
        this._honstGameRecord.writeData();

        return allDone;
    }

    notify_update_game_step(roomID, key, value) {
        var playerID, player;

        /** 主要統一處理 View 的顯示內容 */

        if (this._isHonster) {
            const honsterData = value.split(' ');
            playerID = honsterData[0];
            player = this._honstGameRecord.get(playerID);


            this._masterID = this._honstGameRecord.masterID;
            const master = this._honstGameRecord.get(this._masterID);

            switch (master.gameStatus) {// todo 只服務 master???
                case GameStatus.REVIEW:
                    // 檢查是否已完成答題環節
                    if (this.tryAllAnswered()) {
                        // 通知全員顯示所有答題清單
                        this.applicate('question_answers_result');

                        return;
                    }
                    break;
            }

            value = `${this._masterID} ${playerID} ${JSON.stringify(player)}`;
            this._broadcast(key, value, playerID);

            if (this._playerID != playerID)
                return;//指定玩家執行，honster 不動
        }

        /** CLIENT */

        const clientData = value.split(' ');
        this._masterID = clientData[0];
        playerID = clientData[1];
        player = JSON.parse(clientData[2]);

        console.log(key, 'GAME STATUS:', player.gameStatus);

        const { gameStatus, nickname } = player;
        switch (gameStatus) {
            case GameStatus.ASKING:
                console.log(`我是${nickname}, 正在擔任裁判並發問`, player);

                // 更新問題卡手牌
                this.eventUpdateQuestionCards(player.questionHandCards);

                // 解鎖問題卡的選擇功能
                this.eventLockQuestionSelection(false);

                // 提示
                // this.eventShowTip('選擇題目並送出[ASKING]');
                this.eventShowTip('選擇題目並送出');
                break;

            case GameStatus.ASKED:
                console.log(`UI 禁止選擇問題卡`);

                // 裁判完成出牌，鎖定點擊
                this.eventLockQuestionSelection(true);

                // 提示
                // this.eventShowTip('等待答案中...[ASKED]');
                this.eventShowTip('等待答案中...');
                break;

            case GameStatus.ANSWER:
                console.log(`我是${nickname}, 是一般玩家`, player);

                // 更新答案卡手牌
                this.eventUpdateAnswerCards(player.answerHandCards);

                // 解鎖答案卡的選擇功能
                // ===> 等裁判送 notify_question 後，再進行 eventLockAnswerSelection

                // 提示
                // this.eventShowTip('等待裁判出題[ANSWER]');
                this.eventShowTip('等待裁判出題');
                break;

            case GameStatus.ANSWERING:
                console.log(`UI 進行選擇答案卡`);

                // 解鎖答案卡的選牌功能，輪到玩家動作
                this.eventLockAnswerSelection(false);

                // 提示
                // this.eventShowTip('填空並送出[ANSWERING]');
                this.eventShowTip('填空並送出');
                break;

            case GameStatus.FOLD:
                // 玩家出完牌了，讓玩家進行棄牌流程
                let num = player.answerCards.length - 1; // 出3張牌就棄2張，出2張牌就棄張 todo: 卡片上會說棄幾張，再處理
                let { answerHandCards } = player;
                this.eventAnswerCardFold(answerHandCards, num);

                // 提示
                // this.eventShowTip(`請棄掉牌${num}張牌[FOLD]`);
                this.eventShowTip(`請棄掉牌${num}張牌`);
                break;

            case GameStatus.ANSWERED:
                // 提示
                // this.eventShowTip('等待其他人…[ANSWERED]');
                this.eventShowTip('等待其他人…');
                break;

            // case GameStatus.VOTED:
        }

    }

    // h->h - draw_question_cards: [PlayerID]
    // h->h - draw_answer_cards: [PlayerID]
    // h->c: [MasterID]
    notify_game_round(roomID, key, value) {
        /** 遊戲進行一輪時，要先選出裁判，並設定 _honsterGameRecord 狀態 */

        if (this._isHonster) {
            // 輪到誰當裁判
            const masterID = this._honstRoundPlayers[this._honstRoundIndex];

            this._honstGameRecord.masterID = masterID;

            // 裁判 設定 角色定位 與 遊戲狀態
            const master = this._honstGameRecord.get(masterID);
            master.role = Role.MASTER;
            master.gameStatus = GameStatus.ASKING;

            console.log('裁判人選:', masterID, 'master:', master);

            this.applicate('draw_question_cards', masterID);

            // 玩家 設定 角色定位 與 遊戲狀態
            this._honstRoundPlayers.forEach((playerID) => {
                if (masterID === playerID) {
                    // 裁判已有設定，不再設
                    return;
                }

                const player = this._honstGameRecord.get(playerID);
                player.role = Role.PLAYER;
                player.gameStatus = GameStatus.ANSWER;

                this.applicate('draw_answer_cards', playerID);
            });

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            value = `${masterID}`;
            this._broadcast(key, value);
        }

        /** CLIENT */

        const clientData = value.split(' ');
        this._masterID = clientData[0];
    }

    // h->h: [PlayerID]
    // h->h licensing: [PlayerID]
    notify_draw_question_cards(roomID, key, value) {
        if (this._isHonster) {
            const honsterData = value.split(' ');
            const masterID = honsterData[0];

            const questions = this._honstGameRecord.questions;

            const { questionHandCards } = this._honstGameRecord.get(masterID);
            const drawCardsNum = this._honstCardMax.q - questionHandCards.length;

            console.log('抽', drawCardsNum, '張');
            console.log(`問題卡牌庫張數(應有${this._honstCardMax.q}), Honster 目前張數::`, questions.length);

            // 觸發 licensing 的同步手牌請求
            const applicateLicensing = () => {

                // 問題卡牌堆中，取出 drawCardsNum 張卡片
                this._honstGameRecord.questions.splice(0, drawCardsNum).forEach((card) => questionHandCards.push(card));
                console.log('獲得手牌:', questionHandCards);

                // 更新本地暫存資訊
                this._honstGameRecord.writeData();

                // 請求同步手牌
                this.applicate('licensing', masterID);
            }

            if (drawCardsNum > questions.length) {
                // 卡片庫不足時先重刷再同步
                this.updateQuestionAsync()
                    .then(() => applicateLicensing());
            } else {
                // 同步手牌
                applicateLicensing();
            }
        }
    }

    // h->h: [PlayerID]
    // h->h licensing: [PlayerID]
    notify_draw_answer_cards(roomID, key, value) {
        if (this._isHonster) {
            const honsterData = value.split(' ');
            const playerID = honsterData[0];

            const answers = this._honstGameRecord.answers;

            const { answerHandCards } = this._honstGameRecord.get(playerID);
            const drawCardsNum = this._honstCardMax.a - answerHandCards.length;

            console.log('抽', drawCardsNum, '張');
            console.log(`答案卡牌庫張數(應有${this._honstCardMax.a}), Honster 目前張數:`, answers.length);

            // 觸發 licensing 的同步手牌請求
            const applicateLicensing = () => {

                // 答案卡牌堆中，取出 drawCardsNum 張卡片
                this._honstGameRecord.answers.splice(0, drawCardsNum).forEach((card) => answerHandCards.push(card));
                console.log('獲得手牌:', answerHandCards);

                // 更新本地暫存資訊
                this._honstGameRecord.writeData();

                // 請求同步手牌
                this.applicate('licensing', playerID);
            }

            if (drawCardsNum > answers.length) {
                // 卡片庫不足時先重刷再同步
                this.updateAnswerAsync()
                    .then(() => applicateLicensing());
            } else {
                // 同步手牌
                applicateLicensing();
            }
        }
    }

    // c->h: [PlayerID]
    // h->c: [PlayerID] [PlayerInfo]
    // h->c: [PlayerID] [PlayerInfo] [QuestionAnswers]
    notify_licensing(roomID, key, value) {
        var playerID, player;

        /** 玩家同步更新手牌 (請求同步手牌，可能在斷線後重連需要把手牌拿回來) */

        if (this._isHonster) {
            const honsterData = value.split(' ');
            playerID = honsterData[0];
            player = this._honstGameRecord.get(playerID);

            // client 可能需要更新手牌的現況，這邊收到請求就直接送
            value = `${playerID} ${JSON.stringify(player)}`;
            this._broadcast(key, value, playerID);

            if (this._playerID != playerID)
                return;//指定玩家執行，honster 不動
        }

        /** CLIENT */

        const clientData = value.split(' ');
        playerID = clientData[0];

        if (this._playerID != playerID) {
            return console.error('playerID 不符合', playerID, '應該在honster 階段return');
        }

        console.log('clientData[1]::::::', clientData[1]);
        player = JSON.parse(clientData[1]);

        // const { gameStatus, role, nickname, questionHandCards, answerHandCards } = player;
        // if (role === Role.MASTER) {
        //     // 更新問題卡手牌
        //     this.eventUpdateQuestionCards(questionHandCards);
        // }
        // else if (role === Role.PLAYER) {
        //     // 更新答案卡手牌
        //     this.eventUpdateAnswerCards(answerHandCards);
        // }

        // 發完牌後，請 Honster 指引下一步該做的事
        this.applicate('update_game_step', `${playerID} ${Math.random()}`);
    }

    // c->h: [QuestionCard]
    // h->c: [QuestionCard]
    // c->h - update_game_step: [PlayerID]
    notify_question(roomID, key, value) {
        var askingQuestion;

        if (this._isHonster) {
            askingQuestion = value;

            this._honstGameRecord.askingQuestion = value;

            console.log('裁判送出的問題卡:', askingQuestion);

            const master = this._honstGameRecord.get(this._masterID);

            if (master.role !== Role.MASTER) {
                this._broadcast('alert', '自己不是裁判，不應該問問題', this._masterID);
                return console.log(this._masterID, '不是裁判，不應該問問題');
            }

            if (master.gameStatus !== GameStatus.ASKING) {
                this._broadcast('alert', '自己還不是問問題的狀態', this._masterID);
                return console.log(this._masterID, '還不是問問題的狀態:', master.gameStatus);
            }

            // 裁判送出問題後，改變他的狀態
            master.gameStatus = GameStatus.ASKED;

            // 裁判在送出問題後，自己把剩下的牌棄掉
            var { questionHandCards } = this._honstGameRecord.get(this._masterID);
            questionHandCards.length = 0;

            // 裁判出完題後，玩家可以進行回答
            this._honstRoundPlayers.forEach(pid => {
                if (pid === this._masterID) {
                    return;
                }

                const player = this._honstGameRecord.get(pid);
                if (player.gameStatus === GameStatus.ANSWER) {
                    player.gameStatus = GameStatus.ANSWERING;
                    console.log(`玩家${pid}改為${GameStatus.ANSWERING}狀態`);
                } else {
                    console.error(`玩家應該是${GameStatus.ANSWER}狀態，但現在卻是${player.gameStatus}`);
                }
            });

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            // 廣播給全體，進行題目的顯示
            value = `${askingQuestion}`;
            this._broadcast(key, value);
        }

        /** CLIENT */

        const clientData = value.split(' ');
        askingQuestion = clientData[0];

        // UI 顯示題目
        this.eventShowQuestion(askingQuestion);//重連要自己再call

        // 題目顯示後，請 Honster 指引下一步該做的事
        console.log('題目顯示後，請 Honster 指引下一步該做的事', this._playerID);
        this.applicate('update_game_step', `${this._playerID} ${Math.random()}`);
    }

    // c->h: [AnswerPlayerID] [AnswerCards]
    // h->c: [AnswerPlayerID] [AnswerCards]
    notify_answer(roomID, key, value) {
        var answerPlayerID, answerCards, allDone;

        /** 玩家進行問題的回答，送出答案卡 */

        if (this._isHonster) {
            const hostnerData = value.split(' ');
            answerPlayerID = hostnerData[0];
            answerCards = JSON.parse(hostnerData[1]);

            console.log('玩家送出的答案卡:', answerCards);

            const player = this._honstGameRecord.get(answerPlayerID);

            if (player.role !== Role.PLAYER) {
                this._broadcast('alert', '自己不是玩家，不應該回答問題', answerPlayerID);
                return console.log(answerPlayerID, '不是玩家，不應該回答問題');
            }

            if (player.gameStatus !== GameStatus.ANSWERING) {
                this._broadcast('alert', '自己還不是回答問題的狀態', answerPlayerID);
                return console.log(answerPlayerID, '還不是回答問題的狀態:', player.gameStatus);
            }

            // 玩家送出答案後，改變他的狀態, 用來紀錄誰還沒有出牌, 之後執行 alert 能準確通知未出牌玩家
            player.gameStatus = answerCards.length > 1 ? GameStatus.FOLD : GameStatus.ANSWERED;

            // 更新暫存的玩家回答
            this._honstQuestionAnswers[answerPlayerID] = answerCards;
            player.answerCards = answerCards;

            console.log('this._honstQuestionAnswers:', this._honstQuestionAnswers);

            // 整理玩家手牌
            const { answerHandCards } = player;
            console.log('手牌整理前:', answerHandCards);
            answerCards.forEach((card) => {
                let cardIndex = answerHandCards.findIndex(ans => ans === card);
                if (cardIndex > -1)
                    answerHandCards.splice(cardIndex, 1);
                else
                    console.log('玩家手牌無此張卡片:', card);
            });
            console.log('手牌整理後:', answerHandCards);

            // 檢查
            // allDone = this.tryAllAnswered();//

            // 玩家答題，讓裁判保持在審閱狀態
            const master = this._honstGameRecord.get(this._masterID);
            if (master.gameStatus === GameStatus.ASKED) {
                master.gameStatus = GameStatus.REVIEW;
            }

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            // 廣播給全體，進行題目的顯示/手牌的更新
            value = `${answerPlayerID} ${JSON.stringify(answerCards)}`;
            this._broadcast(key, value, answerPlayerID);    // 回覆指定玩家已送出卡片成功
            this._broadcast(key, value, this._masterID);    // 同步給裁判接收到的答案卡

            // todo  試試哦~
            console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! this._playerID != answerPlayerID', (this._playerID != answerPlayerID), '&& this._masterID != this._playerID', (this._masterID != this._playerID));
            if (this._playerID != answerPlayerID && this._masterID != this._playerID)
                return;//指定玩家執行，honster 不動
        }

        /** CLIENT */

        const clientData = value.split(' ');
        answerPlayerID = clientData[0];
        answerCards = JSON.parse(clientData[1]);

        if (this._playerID === this._masterID) {
            // 給裁判 UI 顯示 playerID 送出的答案卡，選最佳的
            this.eventShowQuestionAnswer(answerPlayerID, answerCards);//重連自己跑 eventShowAllQuestionAnswer
            this.eventShowTip('收到玩家的答案');
        } else {
            this.eventShowTip('已送出你的答案');
        }

        this.applicate('update_game_step', this._playerID);
    }

    // c->h: [PlayerID] [FoldCards]
    // h->c: [PlayerID] [FoldCards]
    notify_fold_answer_card(roomID, key, value) {
        var playerID, foldCards;

        /** 棄掉答案卡手牌 */

        if (this._isHonster) {
            const honsterData = value.split(' ');
            playerID = honsterData[0];
            foldCards = JSON.parse(honsterData[1]);

            console.log('玩家', playerID, '進行棄牌:', foldCards);

            // 找出玩家手中牌組進行棄牌的剔除
            const player = this._honstGameRecord.get(playerID);
            const { answerHandCards } = player;
            foldCards.forEach(foldCard => {
                answerHandCards.splice(answerHandCards.findIndex((card) => card === foldCard), 1);
            });
            console.log('棄完牌後:', answerHandCards);

            if (player.gameStatus === GameStatus.FOLD) {
                player.gameStatus = GameStatus.ANSWERED;
            } else {
                console.error(player.gameStatus, '狀態不是', GameStatus.FOLD, '，但正在進行棄牌');
            }

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            this.applicate('update_game_step', playerID);
            this.applicate('update_game_step', this._masterID);
        }
    }

    notify_question_answers_result(roomID, key, value) {
        if (this._isHonster) {

            value = `${JSON.stringify(this._honstQuestionAnswers)}`;
            this._broadcast(key, value);
        }

        /** CLIENT */

        const clientData = value.split(' ');
        const questionAnswers = JSON.parse(clientData[0]);
        const isMaster = this._playerID === this._masterID;

        // 更新全員的答題清單
        if (!isMaster) {// 如果重連時 gameStatus 是 voting | voted 就直接呼叫question_answers_result
            console.log('全員的答題清單:', questionAnswers);
            this.eventShowAllQuestionAnswer(questionAnswers);
        }

        // 全員答完題: 裁判要選出最佳的組合/其他玩家要投票選出最差的組合
        this.eventChooseQuestionAnswer(isMaster);
    }

    // c->h: [PlayerID] [WorstPlayerID]
    // h->c: [PlayerID] [needWait0|1]
    notify_vote(roomID, key, value) {
        var playerID;

        /** 投出最差的卡片組合 */

        if (this._isHonster) {
            const honsterData = value.split(' ');
            playerID = honsterData[0];

            // 把投票的id 紀錄起來
            var worstPlayerID = honsterData[1];
            this._honstWorstList.push(worstPlayerID);

            // 暫存被投票的玩家獲得的票數
            const worstPlayer = this._honstGameRecord.get(worstPlayerID);
            worstPlayer.voted++;

            // 此玩家已投票，標記已投
            const player = this._honstGameRecord.get(playerID);
            if (player.gameStatus === GameStatus.VOTING) {
                console.log(`玩家${player.nickname}已完成投票，並修改標記`);
                player.gameStatus = GameStatus.VOTED;
            } else {
                console.error(`玩家${player.nickname}再次完成投票，標記為${GameStatus.VOTED.toString()}`);
            }

            console.log('糟糕清單:', this._honstWorstList);

            // 如果全部玩家都已經投票 (裁判決定最佳就好，不用投最差)
            var needWait = 1;
            if (this._honstWorstList.length === this._honstRoundPlayers.length - 1) {
                needWait = 0;

                //最後一位投票玩家才請求結算投票
                this.applicate('vote_result');
            }

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            value = `${playerID} ${needWait}`;
            this._broadcast(key, value, playerID);

            if (this._playerID != playerID)
                return;//指定玩家執行，honster 不動
        }

        /** CLIENT */

        const clientData = value.split(' ');
        // playerID = clientData[0];
        const isWaiting = clientData[1] === '1';

        // if (this._playerID != playerID) {
        //     return;
        // }

        // 已投，不能再投
        this.eventVoted(!isWaiting);

        // 提示
        if (isWaiting)
            this.eventShowTip('完成投票，請等候其他人投完票');
    }

    // h->c: [WorstPlayerIDs] [YellowCards]
    notify_vote_result(roomID, key, value) {
        var worstPlayerIDs = [], yellowCards = {};

        if (this._isHonster) {
            // 計算票數，標上黃牌
            var voteResult = {};
            this._honstWorstList.forEach((pid) => {
                voteResult[pid] = voteResult[pid] || 0;
                console.log(pid, ':', voteResult[pid]);
                voteResult[pid]++;
            });
            var voteMax = Math.max(...Object.keys(voteResult).map(pid => voteResult[pid]));
            console.log('voteResult:', voteResult, voteMax);
            Object.keys(voteResult).forEach((pid) => {
                if (voteResult[pid] === voteMax) {
                    worstPlayerIDs.push(pid);

                    // 紀錄輸一回，標上黃牌
                    let player = this._honstGameRecord.get(pid);
                    player.lose++;
                }
            });
            console.log('最糟的幾個人:', worstPlayerIDs);

            // 結算紀錄完，把暫存的最差組合清單清空
            this._honstWorstList.length = 0;

            this._honstRoundPlayers.forEach(pid => {
                let player = this._honstGameRecord.get(pid);
                yellowCards[pid] = player.lose;
            });

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            // 通知
            value = `${JSON.stringify(worstPlayerIDs)} ${JSON.stringify(yellowCards)}`;
            this._broadcast(key, value);
        }

        /** CLIENT */

        const clientData = value.split(' ');
        worstPlayerIDs = JSON.parse(clientData[0]);
        yellowCards = JSON.parse(clientData[1]);

        // todo 先試做提示
        if (worstPlayerIDs.some(id => this._playerID === id)) {
            this.eventShowTip('恭喜，大家覺得你的問答組合是最爛的！');

            this.eventRecordLose(yellowCards[this._playerID]);
        }
        else if (this._playerID != this._masterID) {
            this.eventShowTip('很遺憾你的答案未獲選為最爛的問答組合…');
        }

        // 投完票不管重連應該沒差
    }


    // c->h: [BestPlayerID]
    // h->c: [IsAllVoted0] [BestAnswer]
    // h->c: [IsAllVoted1] [VotingPlayers]
    notify_choose_best_answer(roomID, key, value) {
        var bestPlayerID, bestPlayer, bestAnswers, isAllVoted = true;

        if (this._isHonster) {
            const honsterData = value.split(' ');
            bestPlayerID = honsterData[0];
            console.log('bestPlayerID:', bestPlayerID);

            let votingPlayers = [];

            // 檢查全員是否都投完票
            this._honstRoundPlayers.forEach((playerID) => {
                if (this._masterID === playerID) {
                    // 裁判不需要投票
                    return;
                }

                const player = this._honstGameRecord.get(playerID);

                // 檢查是否全員都投完票 (如果還沒的話，裁判不能選最佳組合，要等玩家全員投完票)
                if (player.gameStatus === GameStatus.VOTING) {
                    votingPlayers.push(playerID);
                    isAllVoted = false;
                }

                // 檢查全員選出最差的等待，用 VOTED 來檢查是不是全員都投完票
                if (player.gameStatus === GameStatus.VOTED) {
                    player.gameStatus = GameStatus.GAMING;
                    // player.gameStatus = GameStatus.WAIT_NEXT_ROUND;
                }
            });

            if (isAllVoted) {
                console.log('全員完成投票');

                // 最佳組合的贏一次
                bestPlayer = this._honstGameRecord.get(bestPlayerID);
                bestPlayer.win++;

                // 抓出最佳的答案
                bestAnswers = this._honstQuestionAnswers[bestPlayerID];

                // // 調整裁判狀態
                // const master = this._honstGameRecord.get(this._masterID);
                // if (master.gameStatus === GameStatus.REVIEW) {
                //     master.gameStatus = GameStatus.PICK;
                // }

                // 通知全員選出最佳的組合
                value = `1 ${JSON.stringify(bestAnswers)}`;
            } else {
                console.log('提醒未投票玩家進行投票');

                // 通知未投票的玩家趕快投票
                value = `0 ${JSON.stringify(votingPlayers)}`;
            }

            // 更新本地暫存資訊
            this._honstGameRecord.writeData();

            this._broadcast(key, value);
        }

        /** CLIENT */

        const clientData = value.split(' ');
        isAllVoted = clientData[0] === '1';

        // 顯示裁判選擇的結果。先投完票，才讓裁判選出最佳的問答組合
        if (isAllVoted) {
            // 全體已投票，顯示最佳組合
            bestAnswers = JSON.parse(clientData[1]);
            this.eventShowBestAnswer(bestAnswers, this._playerID === this._masterID);

            this.eventShowTip('裁判選出的最佳組合：');
        } else {
            let votingPlayers = JSON.parse(clientData[1]);

            // 催促未投票的
            if (votingPlayers.some(pid => this._playerID === pid))
                this.eventShowTip('快投票哦!!!大家都在等你!!!');
            // 提示裁判尚有玩家未投票
            else if (this._masterID === this._playerID)
                this.eventShowTip('等待玩家完成最差組合投票');
        }

        // 處理的是裁判選擇，client不管重連應該沒差。
    }

    // 進行下一輪
    notify_next_round(roomID, key, value) {
        var isFinish = false;

        if (this._isHonster) {
            // 用於紀錄輪數 (但不會超過玩家人數)
            this._honstRoundIndex = (this._honstRoundIndex + 1) % this._honstRoundPlayers.length;

            this._honstQuestionAnswers = {};
            this._honstGameRecord.clearAnswerCards();
            this._honstGameRecord.clearWorstVote();

            // 先檢查是否結束遊戲
            this._honstRoundPlayers.forEach(pid => {
                let player = this._honstGameRecord.get(pid);

                // 記完成計算是否有人達到結束的低分
                let score = -player.lose;
                if (score <= -this._loseNum) {
                    isFinish = true;
                }
                console.log(player.nickname, 'score:', score);
            });

            console.log('檢查，還沒結束就下一輪');

            // 檢查就可以直接跳開了
            if (isFinish) {
                this.applicate('game_over');
                return;
            }

            this._broadcast(key, value);
        }

        /** CLIENT */

        const isMaster = this._playerID === this._masterID;

        // 下一輪前，清除該輪暫存的介面資料與狀態
        this.eventClearPrevRound();

        // 沒有結果就繼續遊戲, 由裁判代表發出
        isMaster && this.applicate('game_round');
    }

    // h->c: [Winners]
    notify_game_over(roomID, key, value) {
        var winnerNames = [];

        if (this._isHonster) {
            var winMax = Math.max(...this._honstRoundPlayers.map(pid => this._honstGameRecord.get(pid).win));
            this._honstRoundPlayers.forEach(pid => {
                if (winMax === this._honstGameRecord.get(pid).win) {
                    winnerNames.push(this._honstGameRecord.get(pid).nickname);
                }
            });

            value = `${JSON.stringify(winnerNames)}`;
            this._broadcast(key, value);
        }

        /** CLIENT */

        const clientData = value.split(' ');
        winnerNames = JSON.parse(clientData[0]);

        this.eventShowTip(`遊戲結束，最終大贏家是${winnerNames.join('、')}`);

        // 結束遊戲
        this.eventGameEnd();

        // 清除紀錄
        this.eventRecordLose(0);
    }

    notify_alert(roomID, key, value) {
        this.eventShowTip(value);
    }

    notify_reconnect(roomID, key, value) {
        var playerID, askingQuestion, questionAnswers, answerHandCards, answerCards;

        if (this._isHonster) {
            const honsterData = value.split(' ');
            playerID = honsterData[0];

            this._masterID = this._honstGameRecord.masterID;

            // 把暫存資料轉為較容易使用的
            this._honstRoundPlayers.forEach((pid) => {
                let answerCards = this._honstGameRecord.get(pid).answerCards;
                if (answerCards.length) {
                    this._honstQuestionAnswers[pid] = answerCards;
                }

                for (let i = 0; i < this._honstGameRecord.get(pid).voted; i++) {
                    this._honstWorstList.push(pid);
                }
            });
            console.log('notify_reconnect 答題:', this._honstQuestionAnswers);
            console.log('notify_reconnect 最糟投票:', this._honstWorstList);

            questionAnswers = this._honstQuestionAnswers;

            const player = this._honstGameRecord.get(playerID);
            const { gameStatus } = player;
            switch (gameStatus) {
                case GameStatus.GAMING:
                    this.applicate('licensing', playerID);
                    return;

                case GameStatus.ASKING:
                    this.applicate('update_game_step', playerID);
                    return;

                case GameStatus.ASKED:
                    // this.applicate('update_game_step', playerID);
                    // return;
                    askingQuestion = this._honstGameRecord.askingQuestion;

                    value = `${gameStatus} ${this._masterID} ${askingQuestion}`;
                    this._broadcast(key, value, playerID);
                    break;

                case GameStatus.REVIEW:
                    if (this._masterID === playerID) {
                        askingQuestion = this._honstGameRecord.askingQuestion;

                        value = `${gameStatus} ${this._masterID} ${askingQuestion} ${JSON.stringify(questionAnswers)}`;
                        this._broadcast(key, value, playerID);
                    }
                    break;

                case GameStatus.ANSWER:
                    this.applicate('update_game_step', playerID);
                    return;

                case GameStatus.ANSWERING:
                    // this.applicate('update_game_step', playerID);
                    // return;
                    answerHandCards = player.answerHandCards;
                    askingQuestion = this._honstGameRecord.askingQuestion;

                    value = `${gameStatus} ${this._masterID} ${JSON.stringify(answerHandCards)} ${askingQuestion}`;
                    this._broadcast(key, value, playerID);
                    break;

                case GameStatus.FOLD:
                    // this.applicate('update_game_step', playerID);
                    // return;
                    answerHandCards = player.answerHandCards;
                    answerCards = player.answerCards;
                    askingQuestion = this._honstGameRecord.askingQuestion;

                    value = `${gameStatus} ${this._masterID} ${JSON.stringify(answerHandCards)} ${JSON.stringify(answerCards)} ${askingQuestion}`;
                    this._broadcast(key, value, playerID);
                    break;

                case GameStatus.ANSWERED:
                    this.applicate('update_game_step', playerID);
                    return;

                case GameStatus.VOTING:
                    askingQuestion = this._honstGameRecord.askingQuestion;

                    value = `${gameStatus} ${this._masterID} ${askingQuestion} ${JSON.stringify(questionAnswers)}`;
                    this._broadcast(key, value, playerID);
                    break;

                case GameStatus.VOTED:
                    value = `${gameStatus} ${this._masterID} ${JSON.stringify(questionAnswers)}`;
                    this._broadcast(key, value, playerID);
                    break;
            }
            console.log('gameStatusgameStatusgameStatusgameStatus:', gameStatus);

            if (this._playerID != playerID)
                return;//指定玩家執行，honster 不動
        }

        /** CLIENT */

        const clientData = value.split(' ');
        const gameStatus = parseInt(clientData[0]);
        this._masterID = clientData[1];

        // console.log('notify_reconnect clientData:', clientData);

        switch (gameStatus) {
            case GameStatus.ASKED:
                console.log('GameStatus.ASKED');
                {
                    askingQuestion = clientData[2];

                    console.log(`UI 禁止選擇問題卡`);

                    // 裁判完成出牌，鎖定點擊
                    this.eventLockQuestionSelection(true);

                    // 確保出題區顯示
                    this.eventShowQuestion(askingQuestion);

                    // 提示
                    // this.eventShowTip('等待答案中...[ASKED]');
                    this.eventShowTip('等待答案中...');
                }
                break;

            case GameStatus.ANSWERING:
                console.log('GameStatus.ANSWERING');
                {
                    answerHandCards = JSON.parse(clientData[2]);
                    askingQuestion = clientData[3];

                    // 更新答案卡手牌
                    this.eventUpdateAnswerCards(answerHandCards);

                    this.eventShowQuestion(askingQuestion);

                    console.log(`UI 進行選擇答案卡`);

                    // 解鎖答案卡的選牌功能，輪到玩家動作
                    this.eventLockAnswerSelection(false);

                    // 提示
                    // this.eventShowTip('填空並送出[ANSWERING]');
                    this.eventShowTip('填空並送出');
                }
                break;

            case GameStatus.FOLD:
                {
                    answerHandCards = JSON.parse(clientData[2]);
                    answerCards = JSON.parse(clientData[3]);
                    askingQuestion = clientData[4];

                    // 確保出題區顯示
                    this.eventShowQuestion(askingQuestion);

                    // 玩家出完牌了，讓玩家進行棄牌流程
                    let num = answerCards.length - 1; // 出3張牌就棄2張，出2張牌就棄張 todo: 卡片上會說棄幾張，再處理
                    this.eventAnswerCardFold(answerHandCards, num);

                    // 提示
                    // this.eventShowTip(`請棄掉牌${num}張牌[FOLD]`);
                    this.eventShowTip(`請棄掉牌${num}張牌`);
                }
                break;

            case GameStatus.ANSWERED:
                // 提示
                // this.eventShowTip('等待其他人…[ANSWERED]');
                this.eventShowTip('等待其他人…');
                break;

            case GameStatus.REVIEW:
                console.log('GameStatus.REVIEW');
                {
                    // 輸入問題暫存
                    askingQuestion = clientData[2];
                    this.eventShowQuestion(askingQuestion);

                    questionAnswers = JSON.parse(clientData[3]);
                    this.eventShowAllQuestionAnswer(questionAnswers);
                }
                break;

            case GameStatus.VOTING:
                console.log('GameStatus.VOTING');
                {
                    // 輸入問題暫存
                    askingQuestion = clientData[2];
                    this.eventShowQuestion(askingQuestion);

                    // 顯示全部的問答
                    questionAnswers = JSON.parse(clientData[3]);
                    this.eventShowAllQuestionAnswer(questionAnswers);

                    const isMaster = this._playerID === this._masterID;
                    this.eventChooseQuestionAnswer(isMaster);
                }
                break;

            case GameStatus.VOTED:
                console.log('GameStatus.VOTED');
                {
                    questionAnswers = JSON.parse(clientData[2]);
                    this.eventShowAllQuestionAnswer(questionAnswers);

                    const isMaster = this._playerID === this._masterID;
                    this.eventChooseQuestionAnswer(isMaster);
                }
                break;
            default:
                console.log('未設定 reconnet 該做的事');
                break;
        }
    }
}