import { _decorator, Button, Component, instantiate, Label, Node, RichText, Vec2, Vec3 } from 'cc';
import { YellowCardHandler } from './YellowCardHandler';
import { HandCards } from './HandCards';
import { FoldCards } from './FoldCards';
const { ccclass, property } = _decorator;

@ccclass('YellowCardPanel')
export class YellowCardPanel extends Component {

    /** 問題卡手牌牌庫 */
    @property(HandCards)
    questionHandCards: HandCards = null;

    /** 答案卡手牌牌庫 */
    @property(HandCards)
    answerHandCards: HandCards = null;

    /** 問題顯示區 */
    @property(Node)
    questionBoard: Node = null;

    /** 棄牌 */
    @property(FoldCards)
    foldCards: FoldCards = null;

    /** 問答組合顯示區 */
    @property(Node)
    answerQuestionListView: Node = null;

    @property(Node)
    answerQuestionViewContent: Node = null;

    @property(Button)
    nextRoundButton: Button = null;

    @property(Label)
    infoLabel: Label = null;

    @property(Label)
    tipLabel: Label = null;

    @property(Node)
    yellowCardLayout: Node = null;

    /** 事件 */
    eventMainSceneGameEnd: Function = null;

    _playerID = '';
    _roomID = '';
    _gameHandler: YellowCardHandler = null;

    // 佈局完可用的卡片後暫存，並先取消觸發功能，觸發時機由Handler 控制
    _questionCardButtons = [];
    _answerCardButtons = [];

    // 問題進來後，從填空處找出需要的答案上限
    _answerMax = 0;

    // 已選擇的卡片
    _selectedQuestion = '';
    _selectedAnswers = [];

    // 紀錄問答組合
    _questionAnswers = {};

    // 棄牌
    _isFolding = false;
    _selectFoldMax = 0;
    _selectFoldNum = 0;
    _selectedFloadCards = [];

    protected start(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.setPosition(Vec3.ZERO);

        this.foldCards.node.setPosition(Vec3.ZERO);

        this.close();
    }

    close() {
        this.node.active = false;

        /** HandCards */
        this.questionHandCards.show(false);
        this.answerHandCards.show(false);

        this.questionBoard.active = false;
        this.answerQuestionListView.active = false;

        this.nextRoundButton.node.active = false;

        if (this._roomID) {
            this._gameHandler.endGame(this._roomID);
            this._gameHandler = null;
        }

        this.tipLabel.string = '';

        /** 清資料 */
        this._roomID = '';
        this._playerID = '';

        this._questionAnswers = {};
        this._questionCardButtons.length = 0;
        this._answerCardButtons.length = 0;
        this._selectedAnswers.length = 0;
        this._selectedQuestion = '';
        this._answerMax = 0;
        this._isFolding = false;
        this._selectFoldMax = 0;
        this._selectFoldNum = 0;
        this._selectedFloadCards.length = 0;
    }

    init(roomID, playerID, nickname, isReconnect, players?) {
        this.node.active = true;

        this._gameHandler = new YellowCardHandler(playerID, nickname);

        this._gameHandler.eventUpdateQuestionCards = this.onUpdateQuestionCards.bind(this);
        this._gameHandler.eventLockQuestionSelection = this.onLockQuestionSelection.bind(this);

        this._gameHandler.eventUpdateAnswerCards = this.onUpdateAnswerCards.bind(this);
        this._gameHandler.eventLockAnswerSelection = this.onLockAnswerSelection.bind(this);

        this._gameHandler.eventShowQuestion = this.onShowQuestion.bind(this);
        this._gameHandler.eventShowAllQuestionAnswer = this.onShowAllQuestionAnswer.bind(this);
        this._gameHandler.eventShowQuestionAnswer = this.onShowQuestionAnswer.bind(this);
        this._gameHandler.eventChooseQuestionAnswer = this.onChooseQuestionAnswer.bind(this);

        this._gameHandler.eventAnswerCardFold = this.onAnswerCardFold.bind(this);
        this._gameHandler.eventShowBestAnswer = this.onShowBestAnswer.bind(this);

        this._gameHandler.eventVoted = this.onVoted.bind(this);

        this._gameHandler.eventShowTip = this.onShowTip.bind(this);
        this._gameHandler.eventClearPrevRound = this.onClearPrevRound.bind(this);
        this._gameHandler.eventRecordLose = this.onRecordLose.bind(this);
        this._gameHandler.eventGameEnd = this.onGameEnd.bind(this);

        // 開始遊戲的連線
        this._gameHandler.startGame(roomID, isReconnect, players);
        this._roomID = roomID;

        this.infoLabel.string = `${roomID}\n${nickname}\n(${playerID})`;
        // this.infoLabel.string = nickname;

        this._playerID = playerID;

        // this.questionHandCards.eventSendCallback = this.onSendQuestionClicked.bind(this);
        // this.answerHandCards.eventSendCallback = this.onSendAnswerClicked.bind(this);
    }

    /**
     * 處理填入空格的問題卡，顯示問答組合
     * @param question 
     * @param answers 
     * @returns 
     */
    fillBlanks(question, answers) {
        var answerList = answers.slice();

        console.log('fill question:', question, answers);

        // 使用正则表达式替换字符串中的占位符
        return question.replace(/_/g, function (match) {
            // 依次从数组中取出单词填充占位符
            return `<color=#FFFF00><u>${answerList.shift() || '_'}</u></c>`;
        });
    }

    /** 問題卡手牌 */

    // 更新手上的問題卡
    onUpdateQuestionCards(cards) {

        this.questionHandCards.setSendData(cards.length, this.onSendQuestionClicked.bind(this));
        // this.questionHandCards.selectMax = 1;
        this.questionHandCards.show(true);
        this.questionHandCards.list(cards, (selectedCard, selectedCards) => {//todo cards 我改用 TipCard 不再用string
            // const isShowBoard = selectedCards.length > 0;

            // // 在设置富文本的时候不要把富文本设置为active，否则要出问题，就是在给富文本的string复制时，要确保active是true
            // this.questionBoard.active = selectedCards.length > 0;

            // if (isShowBoard) {
            //     /** 問題手牌的選擇 */
            //     this.questionBoard.getComponentInChildren(RichText).string = selectedCard;
            // }

            this._selectedQuestion = selectedCard;
        });
    }

    onLockQuestionSelection(isLock) {
        this.questionHandCards.lock(isLock);

        // this.questionHandCards.show(true);
        this.answerHandCards.show(false);
    }

    onSendQuestionClicked(secletedCards) {
        // 把問題卡手牌庫隱藏起來
        this.questionHandCards.show(false);
        this.questionHandCards.lock(true);

        // 裁判送出問題卡
        this._gameHandler.applicate('question', secletedCards[0]);
    }

    /** 答案卡手牌 */

    // 更新手上的答案卡
    onUpdateAnswerCards(cards) {
        this.answerHandCards.show(true);
        this.answerHandCards.list(cards, (selectedCard, selectedCards) => {
            // 在设置富文本的时候不要把富文本设置为active，否则要出问题，就是在给富文本的string复制时，要确保active是true
            this.questionBoard.active = true;

            // 顯示在畫面上，已填入的問題與答案
            const content = this.fillBlanks(this._selectedQuestion, selectedCards);
            this.questionBoard.getComponentInChildren(RichText).string = content;
        });
    }

    onLockAnswerSelection(isLock) {
        this.answerHandCards.lock(isLock);

        this.questionHandCards.show(false);
        // this.answerHandCards.show(true);
    }

    onSendAnswerClicked(secletedCards) {
        // 把答案卡手牌庫隱藏起來
        this.answerHandCards.show(false);

        // 玩家送出回答
        this._gameHandler.applicate('answer', `${this._playerID} ${JSON.stringify(secletedCards)}`);
    }

    /**
     * 顯示裁判選擇的出題卡
     * @param question 
     */
    onShowQuestion(question) {
        console.log('UI 顯示問題:', question);

        const strSplit = question.split('_');
        this._answerMax = Math.max(1, strSplit.length - 1);

        // 設定選擇答案卡片的數量，符合才顯示送出按鈕
        // this.answerHandCards.selectMax = this._answerMax;
        this.answerHandCards.setSendData(this._answerMax, this.onSendAnswerClicked.bind(this));

        // console.log('問題中需要填入答案數量上限:', this._answerMax);

        // 暫存問題卡內容
        this._selectedQuestion = question;

        // 在设置富文本的时候不要把富文本设置为active，否则要出问题，就是在给富文本的string复制时，要确保active是true
        this.questionBoard.active = true;
        this.questionBoard.getComponentInChildren(RichText).string = question;
    }

    /**
     * 顯示 玩家(playerID) 送出的答題卡
     * @param playerID 
     * @param answerCards 
     */
    onShowQuestionAnswer(playerID, answerCards) {
        console.log(`玩家${playerID}送入答案:`, answerCards, typeof answerCards);

        // 哪個玩家送的，後續選擇最佳/差時回傳選定的對象
        this._questionAnswers[playerID] = answerCards;

        this.onShowAllQuestionAnswer(this._questionAnswers);
    }

    /**
     * 顯示全部玩家送出的答題卡
     * @param questionAnswers 
     */
    onShowAllQuestionAnswer(questionAnswers) {
        this._questionAnswers = questionAnswers;
        console.log('顯示所有的答案卡片:', this._questionAnswers);

        // 顯示卡片
        this.answerQuestionListView.active = true;
        const qaChildren = this.answerQuestionViewContent.children;
        qaChildren.forEach(x => x.active = false);

        Object.keys(questionAnswers).forEach((playerID, i) => {
            var cardNode = qaChildren[i];
            if (!cardNode) {
                cardNode = instantiate(qaChildren[0]);
                cardNode.parent = this.answerQuestionViewContent;
            }
            cardNode.active = true;

            const content = this.fillBlanks(this._selectedQuestion, questionAnswers[playerID]);
            console.log('content:', content);
            cardNode.getComponentInChildren(RichText).string = content;
            console.log('\t', cardNode.getComponentInChildren(RichText).string);

            var cardButtonNode = cardNode.getComponent(Button).node;
            cardButtonNode.off('click');
        });
        console.log('顯示答案送出內容，移除 answerQuestionViewContent 的按鈕事件');
    }

    /**
     * 選擇問答組合
     * @param isMaster 
     */
    onChooseQuestionAnswer(isMaster) {
        const aqChildren = this.answerQuestionViewContent.children;

        /** 裁判需要選出最佳的組合 | 玩家選出最差的組合 */
        const callback = isMaster ? this.sendBestQuestionAnswer.bind(this) : this.sendWorstQuestionAnswer.bind(this);

        Object.keys(this._questionAnswers).forEach((playerID, i) => {
            var cardNode = aqChildren[i];
            var cardButtonNode = cardNode.getComponent(Button).node;
            cardButtonNode.on('click', () => callback(playerID), this);
        });
        console.log('設定選擇問答組合，設定觸發 answerQuestionViewContent 的按鈕事件');

        this.answerQuestionListView.active = !this._isFolding;

        if (this._isFolding) {
            if (isMaster) {
                this.onShowTip('選擇最符合你提出條件的組合');
            } else {
                this.onShowTip('選擇不符裁判要求的組合(請先棄完牌)');
                this.foldCards.show(true);
            }
        } else {
            this.onShowTip(isMaster ? '選擇最符合你提出條件的組合' : '選擇不符裁判要求的組合');
        }
    }

    /** 已投票，進等待狀態 */
    onVoted(needTip) {
        const qaChildren = this.answerQuestionViewContent.children;
        qaChildren.forEach(x => x.off('click'));
        console.log('已投票，移除 answerQuestionViewContent 的按鈕事件');

        // 投票完流程自動做隱藏
        this.answerQuestionListView.active = false;
    }

    /**
     * 顯示最佳的問答組合
     * @param answers 
     * @param isMaster 裁判可以點擊下一輪的按鈕
     */
    onShowBestAnswer(answers, isMaster) {
        // 在设置富文本的时候不要把富文本设置为active，否则要出问题，就是在给富文本的string复制时，要确保active是true
        this.questionBoard.active = true;

        // 最後的顯示
        const content = this.fillBlanks(this._selectedQuestion, answers);
        this.questionBoard.getComponentInChildren(RichText).string = content;

        // 隱藏問答清單
        this.answerQuestionListView.active = false;

        // 清掉
        this._questionAnswers = {};
        this._answerMax = 0;
        this._selectedQuestion = '';

        this.nextRoundButton.node.active = isMaster;
    }

    /**
     * 送出最佳組合，裁判專用
     * @param playerID 
     */
    sendBestQuestionAnswer(playerID) {
        console.log('最佳組合的玩家:', playerID);

        // 裁判選出符合要求的問答組合 (送出會有兩種情況:玩家未完成投票，提醒未投玩家; 玩家皆完成投票，顯示最佳組合)
        this._gameHandler.applicate('choose_best_answer', `${playerID} ${Math.round(Math.random() * 1000000)}`);
    }

    /**
     * 送出最差組合，玩家專用
     * @param worstPlayerID 
     */
    sendWorstQuestionAnswer(worstPlayerID) {
        console.log('最差組合的玩家:', worstPlayerID);

        // 玩家們投票找出最差的問答組合
        this._gameHandler.applicate('vote', `${this._playerID} ${worstPlayerID}`);
    }

    /**
     * 處理棄牌
     * @param cards 帶現有的答案手牌 
     * @param num 要棄幾張牌
     */
    onAnswerCardFold(cards, num) {
        this._isFolding = true;
        console.log('進入棄牌流程');

        this.foldCards.show(true);
        this.foldCards.selectMax = num;
        this.foldCards.list(cards);
        this.foldCards.eventSendCallback = this.onSendFoldAnswerClicked.bind(this);
    }

    onSendFoldAnswerClicked(selectedCards) {
        this.answerHandCards.show(false);

        this.foldCards.show(false);
        // this.answerQuestionListView.active = true;//應該是不需要現在馬上出來，暫時先不顯示其他玩家的題

        this._isFolding = false;

        // 答案卡手牌棄牌
        this._gameHandler.applicate('fold_answer_card', `${this._playerID} ${JSON.stringify(selectedCards)}`);
    }

    onShowTip(txt) {
        this.tipLabel.string = txt;
    }

    /**
     * 紀錄玩家獲得黃牌並顯示
     * @param num 
     */
    onRecordLose(num) {
        const cardChildren = this.yellowCardLayout.children;
        cardChildren.forEach(x => x.active = false);

        for (let i = 0; i < num; i++) {
            let cardNode = cardChildren[i];
            if (!cardNode) {
                cardNode = instantiate(cardChildren[0]);
                cardNode.parent = this.yellowCardLayout;
            }
            cardNode.active = true;
        }
    }

    /** 清掉前輪的操作，以利進行下一輪 */
    onClearPrevRound() {
        this.questionHandCards.show(false);
        this.answerHandCards.show(false);

        this.questionBoard.active = false;
        this.answerQuestionListView.active = false;
        this.nextRoundButton.node.active = false;

        // 清掉
        this._questionAnswers = {};
        this._answerMax = 0;
        this._selectedQuestion = '';
    }

    onGameEnd() {
        // 讓MainScene 處理遊戲結束後要做的事
        this.eventMainSceneGameEnd?.();

        this.nextRoundButton.node.active = false;

        this.infoLabel.string = '';
    }

    /** 進行下一輪 */
    onNextRoundClicked() {
        this._gameHandler.applicate('next_round');

    }
}