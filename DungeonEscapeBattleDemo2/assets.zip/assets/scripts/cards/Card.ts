import { CombatActionType } from "../dungeon/combat/CombatEntity";

export class Card {
    suit: number;
    rank: string;
    conditions: string[];//todo 改ExplorationCard?
}

export class CombatCard {
    // name: string;
    // description: string;
    // effect: Effect;
    // skillType: string;
    // hits: string;
    // damage: string;

    // serialId: string;
    // level: number;
    name: string;
    description: string;
    cost: {
        type: string;
        fee: number;
    };
    modifiers: Modifier[];
    target: "self" | "ally" | "enemy" | "allAllies" | "allEnemies";
    // range: "Melee" | "Ranged" | "Reach";
    // type: CombatActionType;
    // animation: "attack" | "spell" | "item" | "other";
}

export interface Modifier {
    // name: string;
    attribute: CombatActionType;
    bonus: string;
    description: string;
    conditions: ModifierCondition[];
}

export type ModifierCondition = 'MainHand' | 'OffHand'
    | 'Unarmed' | 'Bludgeoning' | 'Piercing' | 'Slashing'
    | 'Light' | 'Finesse' | 'Thrown' | 'Two-Handed' | 'Reach' | 'Heavy' | 'Ammunition' | 'Loading' | 'Special' | 'Versatile'
    | 'Melee' | 'Ranged'
    | 'strength' | 'dexterity' | 'intelligence' | 'wisdom' | 'charisma' | 'resilience'
    | 'Defense' | 'Hitpoints' | 'Advantage'
    | 'UnderDamage' | 'Dodge'
    | 'CasterArmor' | 'LightArmor';
// MainHand OffHand Versatile 可取代 NeedWeapon

// const directions: { [key: string]: string } = {
//     'MainHand': '主手動作，消耗行動進行一次攻擊。',
//     'OffHand': '副手動作，消耗附贈動作進行一次攻擊。',
//     'Unarmed': '徒手動作，配合主手/副手動作，若有裝備武器時無法執行。',
//     'Bludgeoning': '猛擊，武器有鈍擊屬性時額外+1傷害。',
//     'Bludgeoning1': '猛擊+1，武器有鈍擊屬性時額外+2傷害。',
//     'Bludgeoning2': '猛擊+2，武器有鈍擊屬性時額外+3傷害。',
//     'Bludgeoning3': '強力猛擊，武器有鈍擊屬性時額外1d4+1傷害。',
//     'Piercing': '突刺，武器有穿刺屬性時額外+1傷害。',
//     'Piercing1': '突刺+1，武器有穿刺屬性時額外+2傷害。',
//     'Piercing2': '突刺+2，武器有穿刺屬性時額外+3傷害。',
//     'Piercing3': '強力突刺，武器有穿刺屬性時額外1d4+1傷害。',
//     'Slashing': '揮砍，武器有揮砍屬性時額外+1傷害。',
//     'Slashing1': '揮砍+1，武器有揮砍屬性時額外+2傷害。',
//     'Slashing2': '揮砍+2，武器有揮砍屬性時額外+3傷害。',
//     'Slashing3': '強力揮砍，武器有揮砍屬性時額外1d4+1傷害。',

//     // 物品互動，消耗附贈動作與物品互動，以觸發相應功能。

//     // 撤離動作，消耗行動進行撤退而不被藉機攻擊。

//     // 盾牌裝備，需要裝備盾牌。

//     // 稱手武器，有武器熟練時獲得熟練命中加值。

//     // 'Light': '輕功',
//     // 'Finesse': '精通',
//     // 'Thrown': '投擲武器',
//     // 'Two-Handed': '雙手武器',
//     // 'Reach': '遠程武器',
//     // 'Heavy': '重武器',
//     // 'Ammunition': '彈藥武器',
//     // 'Loading': '裝填',
//     // 'Special': '特殊武器',
//     // 'Versatile': '多功能武器',
//     // 'Melee': '近戰武器',
//     // 'Ranged': '遠程武器',
//     // 'strength': '力量',
//     // 'dexterity': '敏捷',
//     // 'intelligence': '智力',
//     // 'wisdom': '智力',
//     // 'charisma': '魅力',
//     // 'resilience': '體質',
//     // 'Defense': '防禦',
//     // 'Hitpoints': '體力',
//     // 'Advantage': '優勢',
//     // 'UnderDamage': '受傷時',
//     // 'Dodge': '閃避',
// }
// const UnarmedModifier: Modifier = {
//     attribute: "DamageBonus",
//     bonus: "+1",
//     description: '徒手動作，未空手狀態則無法執行。',
//     conditions: ['Unarmed'],
// };

// const BludgeoningModifier: Modifier = {
//     attribute: "DamageBonus",
//     bonus: "+1",
//     description: '揮砍，武器有揮砍屬性時額外+1傷害。',
//     conditions: ['Melee', 'Bludgeoning'],
// };

export class TipCard {
    string: string;
    type?: string;
    description?: string;//帶有說明的解釋內容，用id來對應Card
    behavior?: string;// 行為，用id來對應下一段內容
    action?: string;
    conditions?: string[];// todo 'cost:1000.gold'??=> 不過物品我都會有價格在裡面，不會用cost來表示才對
    coping?: string;//觸發應對，使用冒險技能來進行檢定
    response?: string;//在應對後可進行的回應，用id來對應下一段內容
    dc?: string;// 有檢定行為時做處理。"(進行DC13[韌性檢定 | dc:13-resilience | success:igpek532 | failure:combat]，失敗進入戰鬥)"
    success?: string;// 對應dc，用用id來對應下一段內容
    failure?: string;// 對應dc，用用id來對應下一段內容
    link?: string;// 新的對話內容，重置scrollview，用id來對應下一段內容
    value?: string;// 包含的數量，用字串表示，如果有需要取得變成實值道具時可以自行轉換
    pic?:string;
}