import { SocketBridge } from "../connection/SocketBridge";

export class NotifyHandler {
    private static _instance: NotifyHandler;

    _isHonster = false;
    _masterID;
    _playerID;

    constructor() {
    }

    public static get Instance() {
        return this._instance || (this._instance = new this());
    }

    public static destroy() {
        this._instance = null;
    }

    set isHonster(value) {
        this._isHonster = value;
    }

    set master(id) {
        if (!this._masterID)
            this._masterID = id;
        else
            console.error('重複設定 master id:', id, '，請置 NotifyHandler');
    }

    set player(id) {
        if (this._playerID)
            this._playerID = id;
        else
            console.error('重複設定 player id:', id, '，請置 NotifyHandler');
    }

    notify(request, targetID = '', response?) {
        var key, value;

        if (this._isHonster) {
            value = request();

            // 指定對象時，不是 Honster 自己就可以跳了
            if (targetID && targetID != this._playerID)
                return;
        }

        response?.(key, value);
    }
}