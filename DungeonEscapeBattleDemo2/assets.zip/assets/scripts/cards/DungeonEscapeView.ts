import { _decorator, Button, Component, instantiate, Label, Node, RichText, Vec2, Vec3 } from 'cc';
import { HandCards } from './HandCards';
import { FoldCards } from './FoldCards';
import { EventManager } from '../managers/EventManager';
import { TipType } from '../tools/TipText';
const { ccclass, property } = _decorator;

@ccclass('DungeonEscapeView')
export class DungeonEscapeView extends Component {

    /** 問題卡手牌牌庫 */
    @property(HandCards)
    questionHandCards: HandCards = null;

    /** 答案卡手牌牌庫 */
    @property(HandCards)
    answerHandCards: HandCards = null;

    @property(Label)
    infoLabel: Label = null;

    @property(Node)
    blockNode: Node = null;

    protected onLoad(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.setPosition(Vec3.ZERO);
    }

    private sendMessage(text: string): void {
        EventManager.instance.emit(TipType.Normal, text);
    }
}