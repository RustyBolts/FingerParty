import { randomRangeInt } from "cc";
import { SocketBridge } from "../connection/SocketBridge";
import { DungeonEscapeRecord } from "./DungeonEscapeRecord";

export class DungeonEscapeHandler {

    _honstGameRecord: DungeonEscapeRecord;

    _roomID;
    _isHonster = false;
    _masterID = '';
    _playerID = '';

    _myNickname = '';

    _players;

    _gameView;

    // 暫存公牌
    _communityCards = [];


    constructor(view, isHonster, roomID, playerID, nickname, isReconnect, players?) {
        this._gameView = view;
        this._gameView.requestApplicate = this._applicate.bind(this);

        this._isHonster = isHonster;
        if (isHonster) {
            this._players = players;
        }

        this._gameView.init(roomID, playerID, nickname);

        this.startGame(roomID, isReconnect, players);
    }

    /**
     * 向 Honster 發出請求
     * @param key 
     * @param value 
     */
    _applicate(key, value = '') {
        if (!this._isHonster) {
            SocketBridge.Instance.applicate(key, value);
        } else {
            console.log(`====== Applicate ${key} 事件不透過連線發給自己:`, value);
            this[`notify_${key}`](this._roomID, key, value);
        }
    }

    /**
     * 廣播時對指定 Client 發送
     * @param key 
     * @param value 
     * @param clientID 不帶指定 client id 時，對全部有紀錄的client 廣播
     */
    _broadcast(key, value = '', clientID?) {
        if (this._isHonster) {
            if (clientID === this._playerID) {
                return console.log(`====== Broadcast ${key} 事件不透過連線發給自己:\n`, value);
            }
            SocketBridge.Instance.broadcast(key, value, clientID);
        }
    }

    /**
     * 啟動，開始遊戲的建置流程
     * @param roomID 
     * @param players 
     */
    startGame(roomID, isReconnect, players?) {
        this._roomID = roomID;

        // Honster 管理玩家
        if (players) {
            this._isHonster = true;

            this._honstGameRecord = new DungeonEscapeRecord();

            if (isReconnect) {
                this._honstGameRecord.readData();
            } else {
                this._honstGameRecord.players = players;
            }
        }

        SocketBridge.Instance.addDispatcher(roomID, this, {
            'alert': this.notify_alert,
            'update_game_step': this.notify_update_game_step,
            // 'game_round': this.notify_game_round,
            'exploration': this.notify_exploration,
            // 'licensing': this.notify_licensing,
            // 'next_round': this.notify_next_round,
            // 'game_over': this.notify_game_over,
            'reconnect': this.notify_reconnect,
        });

        if (this._isHonster) {
            if (isReconnect) {
                // 進行重連繼續
                this._applicate('reconnect', this._playerID);
            } else {
            }
        } else {
            /** 斷線重連 */
            if (isReconnect) {
                this._applicate('reconnect', this._playerID);
            }
        }
    }

    /**
     * 結束，清除遊戲執行的資訊
     * @param roomID 
     */
    endGame(roomID) {
        SocketBridge.Instance.removeDispatcher(roomID, this);

        if (this._isHonster) {
            this._honstGameRecord.clearData();
            this._honstGameRecord = null;

        }

        this._masterID = '';

        // 自己的玩家ID 與資訊
        this._playerID = '';
        this._myNickname = '';
    }

    onExploration(explorationPlayerID, duration) {
        // 抓 ExplorationPlayer 的能力值出來進行檢定
        // var explorationPlayer = this._honstGameRecord.selectPlayer(explorationPlayerID);
        // 調查技能
        let investigationSkill = 5;
        var checkPoint = randomRangeInt(1, 20) + investigationSkill;

        // 調整玩家時間

        // 取區塊資訊

        // 新增的公牌
        var newCommunityCards = [];

        return newCommunityCards;
    }

    /** NOTIFY */

    notify_alert(roomID, key, value) {
        this._gameView.onShowTip(value);
    }

    notify_update_game_step(roomID, key, value) {
    }

    notify_quick_view(roomID, key, value) {
        var explorationPlayerID, communityCards;

        /** 進行快速檢視 */

        if (this._isHonster) {
            const honsterData = value.split(' ');
            explorationPlayerID = honsterData[0];

            const duration = 6;
            this.onExploration(explorationPlayerID, duration);

            // 廣播所有人更新公牌
            value = `${explorationPlayerID} ${this._communityCards}`;
            this._broadcast(key, value);
        }


        const clientData = value.split(' ');
        explorationPlayerID = clientData[0];
        communityCards = clientData[1];

        this._gameView.onExplorationEvent(explorationPlayerID, communityCards);
    }

    // c->h: [ExplorationPlayerID] [AreaID]
    // h->c: [ExplorationPlayerID] [NewCommunityCards] [CommunityCards]
    notify_exploration(roomID, key, value) {
        var explorationPlayerID, newCommunityCards, communityCards;

        /** 進行探索 */

        if (this._isHonster) {
            const honsterData = value.split(' ');
            explorationPlayerID = honsterData[0];

            const duration = 60;
            newCommunityCards = this.onExploration(explorationPlayerID, duration);

            // 廣播所有人更新公牌
            value = `${explorationPlayerID} ${newCommunityCards} ${this._communityCards}`;
            this._broadcast(key, value);
        }

        const clientData = value.split(' ');
        explorationPlayerID = clientData[0];
        newCommunityCards = clientData[1];
        communityCards = clientData[2];

        this._gameView.onExplorationEvent(explorationPlayerID, communityCards, newCommunityCards);
    }

    notify_reconnect(roomID, key, value) {
        this._gameView.onShowTip('重連' + roomID);
    }
}
