import { RandomString } from "../tools/RandomString";

const PLAYER_INFO = 'DE_GAME_RECORD_INFO';

export enum Role {
    PLAYER,
    MASTER
};

export enum GameStatus {
    GAMING,
};

export enum AreaDirection {
    UP, LEFT, DOWN, RIGHT
}

export class DungeonEscapeRecord {

    // 目前輪到作為裁判的玩家ID
    masterID = '';

    _players = {};
    _roundPlayers = [];
    _roundIndex = 0;

    _areaInfos = {};

    set players(value) {
        this._roundPlayers = Object.keys(value);
        this._roundPlayers.forEach(playerID => {
            this.addPlayer(playerID, value[playerID], GameStatus.GAMING);
        });
    }

    addPlayer(playerID, nickname, gameStatus) {
        this._players[playerID] = {
            nickname: nickname,
            gameStatus: gameStatus,
            role: Role.PLAYER,
        };

        this._roundPlayers = Object.keys(this._players);
    }

    delPlayer(playerID) {
        delete this._players[playerID];
    }

    selectPlayer(playerID) {
        return this._players[playerID];
    }

    nextPlayer() {
        this._roundIndex = (this._roundIndex + 1) % this._roundPlayers.length;
    }

    clearData() {
        this._players = {};
        this._roundPlayers.length = 0;
        this._roundIndex = 0;

        // 清除本地暫存
        localStorage.removeItem(PLAYER_INFO);
    }

    readData() {
        const localData = JSON.parse(localStorage.getItem(PLAYER_INFO));

        console.log('Read data:', localData);
        if (!localData)
            return;

        this.masterID = localData.masterID;

        this._players = localData.players;
        this._roundPlayers = localData.roundPlayers;

    }

    writeData() {
        const localData = {
            masterID: this.masterID,
            players: this._players,
            roundPlayers: this._roundPlayers,
        };

        localStorage.setItem(PLAYER_INFO, JSON.stringify(localData));
    }

    get roundPlayers() {
        return this._roundPlayers;
    }

    // getPlayerHandCards(playerID) {
    //     return {
    //         answerHandCards: this._players[playerID].answerHandCards,
    //         questionHandCards: this._players[playerID].questionHandCards
    //     };
    // }

    dropAnswerHandCards(playerID, cards) {
        this.dropHandCard(this._players[playerID].answerHandCards, cards);
    }

    dropHandCard(handCards, cards) {
        return cards.every((card) => {
            return handCards.find((handCard, i, ary) => {
                if (handCard === card) {
                    ary.splice(i, 1);
                    return true;
                }
            });
        });
    }

    // 建立區塊資料
    createArea(id) {
        this._areaInfos[id] = {
            doors: {
                [AreaDirection.UP]: '',
                [AreaDirection.LEFT]: '',
                [AreaDirection.DOWN]: '',
                [AreaDirection.RIGHT]: '',
            }
        };
    }

    /**
     * 
     * @param direction 從哪個方向進行連接
     * @param from 從哪個區塊進行連接
     * @param to 如果知道會連接到哪個區塊，直接設定
     */
    linkDoor(direction, from, to?) {
        var currID, nextID, currArea, nextArea;

        const gridPos = from.split('-');
        var x = parseInt(gridPos[0]), y = parseInt(gridPos[1]);

        currID = `${x}-${y}`;
        currArea = this._areaInfos[currID];

        switch (direction) {
            case AreaDirection.UP: y++; break;
            case AreaDirection.LEFT: x--; break;
            case AreaDirection.DOWN: y--; break;
            case AreaDirection.RIGHT: x++; break;
        }
        nextID = `${x}-${y}`;

        var doorID = RandomString.generate();

        if (to) {
            nextArea = this._areaInfos[nextID];

            currArea.doors[direction] = doorID;
            nextArea.doors[(direction + 2) % 4] = doorID;
        } else {
            this.createArea(nextID);
            this._areaInfos[nextID].doors[direction] = doorID;
        }

        this._doors[doorID] = {
            // 以此門為連通的兩個房間
            rooms: [currID, nextID],
            // todo: type、lock(check, dc)
        }
    }
    _doors = {};
}