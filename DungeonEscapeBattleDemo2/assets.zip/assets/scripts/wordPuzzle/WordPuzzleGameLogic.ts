import { _decorator, Component, Vec3 } from "cc";
import { EventManager } from "../managers/EventManager";
import { GameLogicEvent, WordPuzzleGameLogicEvent } from "../managers/GameEvents";
import { FillBlanks, ReplacedText } from "../tools/FillBlanks";
import { ExplorationCard } from "../cards/ExplorationCard";
import WordPuzzleGameUI from "./WordPuzzleGameUI";
import { TipCard } from "../cards/Card";

const { ccclass, property } = _decorator;

@ccclass('WordPuzzleGameLogic')
export default class WordPuzzleGameLogic extends Component {

    @property(WordPuzzleGameUI)
    private gameUI: WordPuzzleGameUI = null;

    protected onLoad(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.setPosition(Vec3.ZERO);

        EventManager.instance.on(WordPuzzleGameLogicEvent.WordPuzzleGameStart, this.startWordPuzzleGame, this);
        EventManager.instance.on(WordPuzzleGameLogicEvent.WordPuzzleGameEnd, this.endWordPuzzleGame, this);
        // EventManager.instance.on(WordPuzzleGameLogicEvent.ShowQuestion, this.eventShowQuestion, this);
        EventManager.instance.on(WordPuzzleGameLogicEvent.ShowAnswer, this.onShowAnswer, this);
        EventManager.instance.on(WordPuzzleGameLogicEvent.ShowHint, this.onShowHint, this);
        EventManager.instance.on(WordPuzzleGameLogicEvent.TexasGameStart, this.onTexasGameStart, this);
        EventManager.instance.on(WordPuzzleGameLogicEvent.TexasGameResume, this.onTexasGameResume, this);
    }

    protected onDestroy(): void {
        EventManager.instance.off(WordPuzzleGameLogicEvent.WordPuzzleGameStart, this.startWordPuzzleGame, this);
        EventManager.instance.off(WordPuzzleGameLogicEvent.WordPuzzleGameEnd, this.endWordPuzzleGame, this);
        // EventManager.instance.off(WordPuzzleGameLogicEvent.ShowQuestion, this.eventShowQuestion, this);
        EventManager.instance.off(WordPuzzleGameLogicEvent.ShowAnswer, this.onShowAnswer, this);
        EventManager.instance.off(WordPuzzleGameLogicEvent.ShowHint, this.onShowHint, this);
        EventManager.instance.off(WordPuzzleGameLogicEvent.TexasGameStart, this.onTexasGameStart, this);
        EventManager.instance.off(WordPuzzleGameLogicEvent.TexasGameResume, this.onTexasGameResume, this);
    }

    protected start(): void {
        // 把編輯階段便利的排版，執行時拉回畫面正中間
        this.node.position = Vec3.ZERO;
        this.node.active = false;

        // test
        this.gameUI.onrReasoningTest();
    }

    _data;

    private startWordPuzzleGame(data: any) {
        this.node.active = true;

        this._data = data;

        let intros = data.cards;
        intros.sort(() => Math.random() - 0.5);

        const questions: string[] = [data.question];
        this.onShowQuestion(questions);
    }

    private endWordPuzzleGame(): void {
        this.node.active = false;
    }

    private showQuestion(question: string, answers: string[]): void {
        console.log(`Question: ${question}, Answer: ${answers}`);

        // 將問題和答案傳給 UI
        this.gameUI.showQuestion(question, answers);
    }

    private showAnswer(answers: TipCard[]): void {

        // 將答案傳給 UI
        // this.gameUI.showAnswer(answers.map(card => card.string));
        this.gameUI.showAnswer(answers);
    }

    //#region Event Handlers

    private onShowQuestion(event: any): void {
        // const { replacedTexts, storedTexts } = FillBlanks.replaceKeywordsWidthBlanks(event);

        const replacedTexts: ReplacedText[] = FillBlanks.replaceKeywordsWidthBlanks(event);

        const question: string = replacedTexts[0].text;
        const answers: string[] = replacedTexts[0].keywords;
        this.showQuestion(question, answers);
    }

    private onShowAnswer(event: any): void {
        const answers: TipCard[] = event.answers;
        console.log(`Answer: ${answers.map(card => card.string)}`);

        this.showAnswer(answers);
    }

    private onShowHint(event: { active: boolean }): void {
        this.node.active = event.active;
    }

    private onTexasGameStart(event: any): void {
        EventManager.instance.emit(GameLogicEvent.GameStart, { plyaerInfo: null, intros: this._data.cards });

        this.node.active = false;
    }

    private onTexasGameResume(event: any): void {
        EventManager.instance.emit(GameLogicEvent.GameResume);

        this.node.active = false;
    }

    //#endregion
}