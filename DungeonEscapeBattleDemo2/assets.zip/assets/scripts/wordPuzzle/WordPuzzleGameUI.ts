import { _decorator, Component, Node, RichText } from "cc";
import { EventManager } from "../managers/EventManager";
import { GameLogicEvent, WordPuzzleGameLogicEvent } from "../managers/GameEvents";
import { HandCards } from "../cards/HandCards";
import { FillBlanks } from "../tools/FillBlanks";
import { TipType } from "../tools/TipText";
import { ExplorationCard } from "../cards/ExplorationCard";
import { TipCard } from "../cards/Card";

const { ccclass, property } = _decorator;

@ccclass('WordPuzzleGameUI')
export default class WordPuzzleGameUI extends Component {

    @property(RichText)
    private questionLabel: RichText = null!;

    @property(HandCards)
    private answerHandCards: HandCards = null;

    @property(Node)
    private restartBtn: Node = null!;

    @property(Node)
    private startBtn: Node = null!;

    @property(Node)
    private resumeBtn: Node = null!;

    private question: string = '';
    private solutions: string[] = [];

    private isFirstRound: boolean = true;

    showQuestion(question: string, solutions: string[]): void {
        this.questionLabel.string = this.question = question;
        this.solutions = solutions;
        // this.answerHandCards.selectMax = solutions.length;
        // this.answerHandCards.eventSendCallback = this.sendAnswer.bind(this);
        this.answerHandCards.setSendData(this.solutions.length, this.sendAnswer.bind(this));
        this.answerHandCards.show(false);
        this.answerHandCards.lock(true);

        this.restartBtn.active = false;
        this.startBtn.active = this.isFirstRound;
        this.resumeBtn.active = !this.isFirstRound;

        this.isFirstRound = false;
    }

    showAnswer(answers: TipCard[]): void {
        this.answerHandCards.show(true);
        this.answerHandCards.list(answers, (selectedCard, selectedCards) => {
            // 顯示在畫面上，已填入的問題與答案
            this.questionLabel.string = FillBlanks.answerQuestion(this.question, selectedCards);
        });
        this.answerHandCards.lock(false);
    }

    sendAnswer(secletedCards: string[]): void {
        const success = this.checkQuestionAnswer(secletedCards);
        if (success) {
            EventManager.instance.emit(TipType.Normal, '回答正確！');

            this.questionLabel.string = '';
            this.answerHandCards.show(false);
            this.answerHandCards.clear();

            this.restartBtn.active = true;
            this.startBtn.active = false;
            this.resumeBtn.active = false;
        } else {
            EventManager.instance.emit(TipType.Error, '回答錯誤！');
        }
    }

    // 確認填入的答案正確與否
    private checkQuestionAnswer(answer: string[]): boolean {
        return this.solutions.every((item, index) => item === answer[index]);
    }

    //#region 點擊事件處理

    onTexasGameStartClicked() {
        this.restartBtn.active = false;
        this.startBtn.active = false;
        this.resumeBtn.active = true;

        this.isFirstRound = false;

        EventManager.instance.emit(WordPuzzleGameLogicEvent.TexasGameStart);
    }

    onTexasGameResumeClicked() {
        EventManager.instance.emit(WordPuzzleGameLogicEvent.TexasGameResume);
    }

    onTexasGameRestartClicked() {
        this.questionLabel.string = '';

        this.restartBtn.active = false;
        this.startBtn.active = false;
        this.resumeBtn.active = false;

        this.isFirstRound = true;

        this.node.parent.active = true;

        EventManager.instance.emit(TipType.Hide);
        EventManager.instance.emit(GameLogicEvent.GameEnd);// 結束德撲遊戲

        // 測推理
        // this.onrReasoningTest();
    }

    private index: number = -1;
    onrReasoningTest() {
        const explorationCard = new ExplorationCard();
        const data = explorationCard.getReasoning(++this.index);
        EventManager.instance.emit(WordPuzzleGameLogicEvent.WordPuzzleGameStart, data);
    }

    //#endregion
}