import { size } from "cc";
import { CardSuit } from "../cards/ExplorationCard";

export class StoryData {
    chapters: string[][] = [];
    dungeons: any;
    // dungeons: string[][] = [];
    // locations: string[][] = [];
    // items: string[][] = [];
    monsters: any;
    // npcs: string[][] = [];
    quests: any;
    skills: string[][] = [];
    // spells: string[][] = [];
    // weapons: string[][] = [];
    // armors: string[][] = [];
    // potions: string[][] = [];
    // scrolls: string[][] = [];
    // keys: string[][] = [];
    dramas: any;
    options: any;

    constructor() {
        this.options = {
            'ethnicity': {
                descriptions: [
                    '歡迎你的加入，這是一個充滿劍與魔法的[奇幻世界 | pic:fantasyworld]。',
                    '在這個世界裡有著不同的種族，彼此之間互相競爭，並且有著各自的文化特色。',
                    '在大部分世界的創世史裡，[人類 | type:ethnicity | pic:humanrace]都是最年輕的常見種族，姍姍來遲兼且比矮人、精靈、巨龍都要短壽。',
                    '也許是因為他們的有限歲月，他們會盡力燃燒僅存的有限年日。',
                    '又或者也許他們覺得需要證明自己給宗祖種族看，為此用搶掠和貿易建立強大的王國。不論是甚麼原因，人類是眾世界的革新者、登峰者、先驅者。',
                    '[精靈 | type:ethnicity | pic:elfrace]是帶超凡氣質的魔法民族，活在世上但又不完全屬世。他們居於飄逸之地，在古代森林之中或在閃耀妖火的銀色尖塔之中，柔和音樂乘風而轉，輕柔芳香隨風飄盪。',
                    '精靈喜歡自然與魔法、美術與藝術、詩詞與歌賦、及世上一切美好之事。',
                    '[半精靈 | type:ethnicity | pic:halfelfrace]行走在兩個世界的交界之處，但無論在那一邊都無法找到自己真正的歸宿。',
                    '有人說半精靈身上集中了人類和精靈兩族的優點：從精靈處繼承來的的敏銳感覺、藝術修養和熱愛自然的天性，調和了人類血統中的的好奇心、創造力和野心。',
                    '有些半精靈與人類一起生活，卻因為情感和體質上的差別而和人類產生隔閡，雖然青春依舊但卻不得不看著自己的朋友與戀人逐漸老去；',
                    '其他半精靈則是在精靈社會中生活，他們在永恆不變的精靈國度中成長著，愈發感到不安，因為他們逐漸長大成人，可是與他們同時出生的精靈孩童卻依然還是孩子。',
                    // '[獸人 | type:ethnicity]是這個世界的敵人，他們的存在使得這個世界充滿了戰鬥。',
                    '[半獸人 | type:ethnicity | pic:orcrace]將因為戰斗而獲得的傷痕作為自豪和裝飾自身勇武的完美飾物。',
                    '而其他的疤痕，標記著獸人或者半獸人曾經身為奴隸或是羞恥的被放逐者。',
                    '生活在獸人之中的半獸人所擁有的傷痕，無論是標志著榮耀或是恥辱，都記敘著他們曾經的英勇事跡和受到的傷害。',
                    '生活在人類社會中的半獸人，則可能會自豪地將自己的傷痕展示出來，或者羞愧地隱藏起來。',
                    '[半身人 | type:ethnicity | pic:halfingrace]友善樂天。他們享受親情和友情，也享受溫暖的家，很少幻想飛黃騰達。',
                    '即使是他們當中的冒險者也主要是為了同鄉、朋友、遊歷、或好奇心而闖盪世界。他們熱愛發掘新事物，即使是簡單的小事，例如一度異國食品或者一套未曾遇見過的衣著。',
                    '半身人有強烈的同情心，受不住看見他人受苦。他們很慷慨，即使是艱難的時候也願意分甘同味。',
                    '[地侏 | type:ethnicity | pic:gnomerace]的生活熱情和精力滲透著他那細小身體的每一寸地方。地侏的平均身高略高於3英尺，重約40~45磅。',
                    '他們棕黃或褐色的臉龐通常掛著大大的笑臉（在他們巨大的鼻子下面），而他們明亮的眼睛閃爍著興奮的光芒。',
                    '他們美麗的頭發趨向於各個方向伸展，像是表達地侏那種對周圍事物永不知足的興趣似的。',
                    '地侏具有顯而易見的外表特征。相對於男性地侏自然生長的頭發來說，他們的胡子被仔細打理著，不過卻會經常變換風格，如剪成奇怪的分叉或是整齊的尖端。',
                    '地侏的服裝，盡管經常做成溫和的泥土色調，但卻精心的裝飾著刺繡、壓花或是閃亮的珠寶。',
                    '[矮人 | type:ethnicity | pic:dwarfrace]勇敢頑強，矮人以熟練的戰士、礦工、石匠鐵匠而聞名。雖然身高不過 5 尺，矮人很壯碩，致使他們可以跟比自已高 2 尺的人類一樣重。',
                    '他們的勇氣和耐力也輕易比得上任何比矮人高的人。',
                    '矮人的膚色由深啡到白裡透紅，最常見是淺啡或深古銅，跟某些泥土一樣。',
                    '他們留簡約的長髮，髮色一般為黑、灰、啡，但白膚的矮人可能有紅色的毛髮。',
                    '男性矮人極之重視自己的鬍子，會細心梳理它。',
                    '歡迎來到這個充滿戰鬥、奇幻、冒險、怪奇的世界。(你可以[選擇 | type:ethnicity | behavior:choice | response:chooseEthnicity]其中一個種族來進行冒險。)',
                ],
                chance: 1,
                behavior: {
                    choice: {
                        'chooseEthnicity': '你作為一名[_ | type:ethnicity]來到這個世界，你會發現這個世界充滿了各種戰鬥、奇幻、冒險、怪奇的元素。',
                    },
                    response: {
                        'chooseEthnicity': [
                            '[人類 | type:ethnicity | response:human1]的屬性值為力量+1; 敏捷+1; 體質+1; 智力+1; 睿知+1; 魅力+1。',
                            '[精靈 | type:ethnicity | response:elf1]的屬性值為敏捷+2; 體質+1。',
                            '[半精靈 | type:ethnicity | response:halfElf1]的屬性值為魅力+2; 選擇任意其他二項+1。',
                            // '[獸人 | type:ethnicity | response:orc1]的屬性值為力量+2; 體質+1; 智力-2。',
                            '[半獸人 | type:ethnicity | response:halfOrc1]的屬性值為力量+2; 體質+1。',
                            '[半身人 | type:ethnicity | response:halfing1]的屬性值為 敏捷+2; 體質+1。',
                            '[地侏 | type:ethnicity | response:gnome1]的屬性值為體質+1; 智力+2。',
                            '[矮人 | type:ethnicity | response:dwarf1]的屬性值為體質+2; 睿知+1。',
                            ''
                        ],
                        'human1': this.ethnicityHumanIntro1,
                        'elf1': this.ethnicityElfIntro1,
                        'halfElf1': this.ethnicityHalfElfIntro1,
                        'orc1': this.ethnicityOrcIntro1,
                        'halfOrc1': this.ethnicityHalfOrcIntro1,
                        'halfing1': this.ethnicityHalfingIntro1,
                        'gnome1': this.ethnicityGnomeIntro1,
                        'dwarf1': this.ethnicityDwarfIntro1,
                    }
                }
            },
            'ability': {
                descriptions: [
                    '在這個世界裡，你必須要面對一個充滿挑戰的世界，並且要展現你的才能。',
                    '因此你需要為角色添加符合你需求的能力，才能夠在這個世界中盡情地冒險。',
                    '其中能力的基礎是：',
                    '[力量 | type:ability | coping:strength]，力量代表肌肉力量、運動訓練及所能發揮的肉體潛能。',
                    '[敏捷 | type:ability | coping:dexterity]，敏捷檢定可以對應進行靈巧、迅速、安靜的移動，或在不穩定的地方保持平衡。',
                    '體操、巧手、隱匿等技能分別反映了某幾類敏捷檢定可以表示的能力。',
                    '[智力 | type:ability | coping:intelligence]，智力代表思維能力、記憶能力、邏輯能力。',
                    '[睿知 | type:ability | coping:wisdom]，睿知代表你與周圍環境的協和度，反映你的觀察力和洞察力。',
                    '[魅力 | type:ability | coping:charisma]，魅力量化了你跟他人有效地交流的能力。',
                    '它代表了信心、口才，也能代表迷人或有凝聚力的個性。',
                    '[韌性 | type:ability | coping:resilience]，韌性代表身心的抗壓能力，以及對抗外在變化的能力。',
                    '建立角色的屬性表，你可以決定依序決定這些能力值的[分配 | type:ability | behavior:choice | response:setAbility]：',
                ],
                chance: 1,
                behavior: {
                    choice: {
                        'setAbility': '[_ | type:ability]分配15點、[_ | type:ability]分配14點、[_ | type:ability]分配13點、[_ | type:ability]分配12點、[_ | type:ability]分配10點、[_ | type:ability]分配8點。',
                    }
                }
            },
            'classFeature': {
                descriptions: [
                    '你選擇一個職業來進行冒險，並且展現你的才能。',
                    '你將會在這個世界中展現你的才能，並且與其他角色一起共同冒險。',
                    '你可以選擇以下職業：',
                    '[戰士 | type:classFeature | coping:warrior]，戰士擁有強大的力量，並且擅長使用武器。',
                    '[法師 | type:classFeature | coping:wizard]，法師擁有超過一般人所能想像的能力，並且擅長使用魔法。',
                    '[牧師 | type:classFeature | coping:cleric]，僧侶擁有超過一般人所能想像的智慧，並且擅長使用神祕法術。',
                    '[盜賊 | type:classFeature | coping:rogue]，盜賊擁有強大的力量，並且擅長使用手槍、槍枝、或其他武器。',
                    '[德魯依 | type:classFeature | coping:druidic]，德魯依擁有超過一般人所能想像的力量，並且擅長使用弓箭、槍枝、或其他武器。',
                    '[武僧 | type:classFeature | coping:monk]，武僧擁有強大的力量，並且擅長使用武器。',
                    '[吟遊詩人 | type:classFeature | coping:bard]，吟遊詩人擁有超過一般人所能想像的智慧，並且擅長使用歌劇。',
                    '[契術師 | type:classFeature | coping:warlock]，契術師擁有超過一般人所能想像的力量，並且擅長使用魔法。',
                    '[聖騎士 | type:classFeature | coping:paladin]，聖騎士擁有超過一般人所能想像的力量，並且擅長使用武器。',
                    '[術士 | type:classFeature | coping:sorcerer]，術士擁有強大的力量，並且擅長使用武器。',
                    '[遊俠 | type:classFeature | coping:ranger]，遊俠擁有超過一般人所能想像的力量，並且擅長使用弓箭、槍枝、或其他武器。',
                    '[野蠻人 | type:classFeature | coping:barbarian]，野蠻人擁有強大的力量，並且擅長使用手槍、槍枝、或其他武器。',
                    '(你可以[選擇 | type:classFeature | behavior:choice | response:chooseClass]其中一個職業來進行冒險。)',
                ],
                chance: 1,
                behavior: {
                    choice: {
                        'chooseClass': '你決定成為一名[_ | type:classFeature]，在這個世界進行冒險。',
                        'chooseArmor': '你選擇了[_ | type:armor]作為初始的獲甲。',
                        'chooseWeapon': '你選擇了[_ | type:weapon]作為初始的武器。',
                        'fightingStyle': '。',
                    },
                    response: {
                        'chooseClass': [
                            '[戰士 | type:classFeature | response:warrior1]，戰士擁有強大的力量，並且擅長使用武器。',
                            '[法師 | type:classFeature | response:wizard]，法師擁有超過一般人所能想像的能力，並且擅長使用魔法。',
                            '[牧師 | type:classFeature | response:cleric]，牧師擁有超過一般人所能想像的智慧，並且擅長使用禪修。',
                            '[盜賊 | type:classFeature | response:rogue]，盜賊擁有強大的力量，並且擅長使用手槍、槍枝、或其他武器。',
                            '[德魯依 | type:classFeature | coping:druidic]，德魯依擁有超過一般人所能想像的力量，並且擅長使用弓箭、槍枝、或其他武器。',
                            '[武僧 | type:classFeature | coping:monk]，武僧擁有強大的力量，並且擅長使用武器。',
                            '[吟遊詩人 | type:classFeature | coping:bard]，吟遊詩人擁有超過一般人所能想像的智慧，並且擅長使用歌劇。',
                            '[契術師 | type:classFeature | coping:warlock]，契術師擁有超過一般人所能想像的力量，並且擅長使用魔法。',
                            '[聖騎士 | type:classFeature | coping:paladin]，聖騎士擁有超過一般人所能想像的力量，並且擅長使用武器。',
                            '[術士 | type:classFeature | coping:sorcerer]，術士擁有強大的力量，並且擅長使用武器。',
                            '[遊俠 | type:classFeature | coping:ranger]，遊俠擁有超過一般人所能想像的力量，並且擅長使用弓箭、槍枝、或其他武器。',
                            '[野蠻人 | type:classFeature | coping:barbarian]，野蠻人擁有強大的力量，並且擅長使用手槍、槍枝、或其他武器。',

                        ],
                        // 選擇護甲，進 choose 流程
                        'chooseArmor': [
                            '你獲得[鎖子甲 | type:armor | action:collect | coping:chainmail | response:warrior2]，鎖子甲可以抵禦敵人的攻擊，並且可以防止傷害。',
                            // '你獲得[皮甲 | type:armor | action:collect | coping:rawhide | response:warrior2]',//與[鎖子甲 | type:armor | action:collect | coping:chainmail]',
                            // //，還有一把[長弓 | type:weapon | action:collect]與20支[箭矢 | type:ammo | action:collect | value:20]。',
                            '你獲得[皮甲 | type:armor | action:collect | coping:rawhide | response:warrior2]，皮甲除了抵禦攻擊，也能保持你的靈活度。',
                        ],
                        'chooseWeapon': [
                            '你獲得一把[長劍 | type:weapon | action:collect | coping:longswood | response:finish](1d8)。',
                        ],
                        'warrior1': [
                            // '作為戰士你可以從基本裝備中獲得一件[鎖子甲 | type:armor]，或是一件[皮甲 | type:armor]以及一把長弓與20支箭矢。',
                            '作為戰士你可以從基本裝備中獲得一件[鎖子甲 | type:armor](AC16)，或是一件[皮甲 | type:armor](AC14+敏捷調整值或2)。',
                            '(你的[選擇 | type:armor | behavior:choice | response:chooseArmor]是什麼呢？)'
                        ],
                        'warrior2': [
                            '可以再選擇一把[長劍 | type:weapon](1d8傷害)',
                            '(你的[選擇 | type:weapon | behavior:choice | response:chooseWeapon]是什麼呢？)'
                            // '當你成為戰士時，你能決定自己的戰鬥風格。',
                            // '獲得一件[綿甲 | type:armor | action:collect | coping:padded]',// 沒有"與[鎖子甲 | type:armor | action:collect | coping:chainmail]',"的話這邊可以領到綿甲
                        ],
                        'finish': [
                            '恭喜你已完成了初步的創角，其他細節的設定可以在冒險的過程中繼續完成。',
                        ]
                    }
                },
                // 'armor': {
                //     descriptions: [
                //     ],
                //     chance: 1,
                //     behavior: {
                //         choice: {
                //             'chooseArmor': '你選擇了[_ | type:armor]作為初始的獲甲。',
                //         },
                //         response: {
                //             'chooseArmor': [
                //                 '恭喜你已完成了初步的創角，其他細節的設定可以在冒險的過程中繼續完成。',
                //             ]
                //         }
                //     }
                // },
                // 'weapon': {
                //     descriptions: [
                //     ],
                //     chance: 1,
                //     behavior: {
                //         choice: {
                //             'chooseWeapon': '你選擇了[_ | type:weapon]作為初始的武器。',
                //         },
                //         response: {
                //             'chooseWeapon': [
                //                 '恭喜你已完成了初步的創角，其他細節的設定可以在冒險的過程中繼續完成。',
                //             ]
                //         }
                //     }
                // }
            },
        };
        this.quests = {
            'kuai_kuai_cat1': {
                descriptions: [
                    '一如往常的星期一，你經過了快快貓貨運公司的正門口。',
                    '拐個彎繞進旁邊的小巷，那才是你要進入的後門工作區。',
                    '與櫃檯的艾萊尼小姐接洽今天的工作，在集合的過程中艾萊尼小姐請你稍待一會兒。',

                ],
                options: ['今天的[主要任務 | link:kuai_kuai_cat1]是陪同溫德先生將木雕送到卡布拉。'],
                // options: ['今天的[主要任務 | link:adf6322]是陪同溫德先生將木雕送到卡布拉。'],
                location: {
                    name: 'kuikuicompany-000:00',
                    bg: 'mytwon',
                    // connect: ['rawhide-000:00(230,60)', 'chainmail-000:00(-90,330)', 'dagger(-150,200)']// dagger 沒有時間軸是因為是通用的，不會有劇情
                    connect: ['carriage-000:00(180,20)']
                },
            }
        };
        // todo 做一個陣列是可以給故事卡片讀取的
        this.dramas = {
            'kuikuicompany-000:00': {
                descriptions: [
                    '「路上小心，溫德先生~」艾萊尼小姐的在[快快貓 | pic:kuikuicat]的櫃台向你們揮著手。',
                    '你們今天要陪同溫德先生將木雕送到卡布拉。'
                ],
                chance: 0,
                options: ['[知道了 | behavior:end]'],//因為chance是0的關係所以會直接跑 showResponseContentOrFinish
            },
            'dagger': {
                descriptions: [
                    '一間匕首店，可以購買[匕首 | type:commodity | coping:dagger]。]',
                ],
                options: ['離開店舖'],
            },
            'kuai_kuai_cat1': {
                descriptions: [
                    '[快快貓 | type:thing | pic:kuikuicat]貨運公司',
                    '「各位親愛的工作夥伴，早安。我知道今天是星期一，但也請不要看起來如此的軟爛嘛~',
                    '跟大家說個好消息，最近我們的生意挺好的，所以你們今天要陪同溫德先生將旁邊那批木雕都送到隔壁的城鎮卡布拉。',
                    '你們也知道路上頂多有些[綠皮小鬼 | type:monster]，除此之外就沒什麼值得注意了。',
                    '好啦~快點幫溫德先生把貨物搬上驢車吧，不然老闆可能要找理由扣錢囉~」',
                    '溫德先生此時從門外進入室內，請你也幫忙搬運這些箱子。這些[木箱 | type:thing]的[蓋子 | type:thing]都用[釘子 | type:thing]封好了。',
                ],
                chance: 3,
                options: ['「快點[搬箱子 | response:dii32]上車吧。」溫德先生催促著。'],
                behavior: {
                    coping: {
                        'observation': [
                            // [1, '木箱跟平常送貨的木箱略有不同，這批箱子是新的。', 'describe'],
                            // [13,'而且尺寸和公司原本的大小不同，很明顯是來自其他地方的貨物。', 'describe'],
                            [1, '你仔細觀察了[_ | type:thing | behavior:coping | coping:observation]。', 'action to target', 'observation1'],
                            [13, '你仔細觀察了[_ | type:thing | behavior:coping | coping:observation]。', 'action to target', 'observation2'],
                        ],
                        'nature': [
                            [1, '你看著[_ | type:thing | behavior:coping | coping:nature]的材質，思考著。', 'action to target', 'nature1'],
                            [13, '你看著[_ | type:thing | behavior:coping | coping:nature]的材質，思考著。', 'action to target', 'nature2'],
                        ],
                        'experience': [
                            [1, '你對[_ | type:thing | behavior:coping | coping:experience]有些印象…', 'action to target', 'thing1'],
                            [12, '你對[_ | type:thing | behavior:coping | coping:experience]有些印象…', 'action to target', 'thing12'],
                            [1, '你記得綠皮小鬼是…', 'response', 'goblin13'],
                            // [13, '你記得綠皮小鬼是…', 'response', 'goblin13'],
                        ],
                        'dexterity': [
                            [1, '你對鬆掉的釘子有些想法，便動手拆開來看看。', 'response', 'haha'],
                            [12, '你趁沒人注意時，拆開一個木箱來看看。', 'response', 'hagws82'],
                        ],
                        'knowledge': [
                            // [1, '你想知道有關[_ | type:monster | behavior:coping | coping:knowledge]的知識。', 'action to target', 'goblin4'],
                            // [1, '你想知道有關綠皮小鬼的知識。', 'response', 'goblin01'],
                            [1, '你想知道有關綠皮小鬼的知識。', 'response', 'goblin13'],
                            // [13, '你想知道有關綠皮小鬼的知識。', 'response', 'goblin13']//會跟1重複，response 並沒有處理重複 todo 先暫時用一個就好，之後再改成覆蓋重複的
                        ]
                    },
                    response: {
                        'observation1': [
                            '[快快貓 | type:thing]的櫃台小姐是非常的可愛。',
                            '[木箱 | type:thing]跟平常送貨的木箱略有不同，這批箱子是新的。',
                            '[蓋子 | type:thing]用釘子釘死，裡面的東西被保護得很好。',
                            '[釘子 | type:thing]十分嶄新，沒有一絲鐵銹。',
                            '可惜[木雕 | type:thing]被封回箱子了，你沒辦法觀察。'
                        ],
                        'observation2': [
                            '[快快貓 | type:thing]的建立多年，內裝已有些老舊，幾名冒險者也會前來接護送貨物的工作。',
                            '[木箱 | type:thing]跟平常送貨的木箱略有不同，這批箱子是新的。',
                            '[蓋子 | type:thing]用釘子釘死，從打造到封箱的方式來看應該是品質不錯的箱子，裡面的東西被保護得很好。',
                            '有些木箱的[釘子 | type:thing]也不是那麼牢靠地釘住，有些地方還有黏著的痕跡。',
                            '可惜[木雕 | type:thing]被封回箱子了，你沒辦法觀察。'
                        ],
                        'nature1': [
                            '[木箱 | type:thing]跟平常送貨的木箱略有不同，這批箱子是新的。',
                            '[蓋子 | type:thing]用釘子釘死，從打造到封箱的方式來看應該是品質不錯的箱子，裡面的東西被保護得很好。',
                            '有些木箱的[釘子 | type:thing]也不是那麼牢靠地釘住，有些地方還有黏著的痕跡。',
                            '你看見[木雕 | type:thing]時有注意到它的材質是用紅木雕成的。'
                        ],
                        'nature2': [
                            // '[快快貓 | type:thing]的建立多年，內裝已有些老舊，幾名冒險者也會前來接護送貨物的工作。',
                            '[木箱 | type:thing]跟平常送貨的木箱略有不同，這批箱子是新的。',
                            '[蓋子 | type:thing]用釘子釘死，從打造到封箱的方式來看應該是品質不錯的箱子，裡面的東西被保護得很好。',
                            '有些木箱的[釘子 | type:thing]也不是那麼牢靠地釘住，有些地方還有黏著的痕跡。',
                            '你看見[木雕 | type:thing]時有注意到上面留有施法過的魔法粉末。'
                        ],
                        'thing1': [
                            '[快快貓 | type:thing]的設立已有多年，且有其他同名品牌的貨運公司，像是快快狗等。',
                            '[木箱 | type:thing]的品質跟平常裝貨用的木箱略有不同。',
                            '[蓋子 | type:thing]沒什麼特別的。',
                            '平常送貨時很少用上[釘子 | type:thing]封死箱子的。',
                            '你對[木雕 | type:thing]上的造型有點印象，曾經在其他鎮子看過。'
                        ],
                        'thing12': [
                            '[快快貓 | type:thing]的設立已有許多年，除了快快貓、快快狗，在沙漠中還有快快鴨，北方寒土山丘還有快快獅。',
                            '[木箱 | type:thing]跟平常裝貨用的木箱略有不同，這批箱子是新的。而且尺寸和公司原本的大小不同，很明顯是來自其他地方的貨物。',
                            '[蓋子 | type:thing]沒什麼特別的，但木箱本身從打造到封箱的方式來看，都用上有品質的處理來保護裡面的東西。',
                            '平常送貨時很少用上[釘子 | type:thing]封死箱子，但這批箱子似乎才剛打上釘子，釘子還散發著油光，與以往的銹跡斑斑不同。',
                            '你對[木雕 | type:thing]的造型與花紋有印象，那是一種召喚魔物時使用的道具，要小心對待。'
                        ],
                        'dii32': [
                            '搬完東西後，[去找溫德 | behavior:end]先生，就能搭上他的驢車準備出發這趟護送任務了。',
                        ],
                        'haha': [
                            '「嘿！那可是重要的貨物，你動手拆開可是要被老闆扣錢的啊！」溫德先生發現你正在拆著木箱便朝你喊道。',
                            '溫德先生對你的行為鬼祟感到在意。'
                        ],
                        'hagws82': [
                            '你看到裡面裝著一個平凡的[木雕 | type:thing]。',
                            '「嘿，釘子怎麼是鬆掉的？」溫德先生指著你拆過的木箱問道，便吩咐艾萊尼小姐拿來鎚子補釘。',
                            '似乎沒注意到就是你打開箱子的。'
                        ],
                        'goblin1': [
                            // '[綠皮小鬼 | type:monster]，也就是哥布林，是典型的中立邪惡，它們只在乎它們自己的需要，在黑暗或昏暗情況下有超人的視覺。。',
                            '哥布林，俗稱綠皮小鬼，是典型的中立邪惡，它們只在乎它們自己的需要，在黑暗或昏暗情況下有超人的視覺。。',
                        ],
                        'goblin13': [
                            // '當[綠皮小鬼 | type:monster](哥布林)對比它大型的生物使用攻擊或魔法，並造成傷害時，可以對其造成額外傷害。',
                            // '[綠皮小鬼 | type:monster](哥布林)可在自己的回合，以一個附贈動作進行撤離或躲藏'
                            '當綠皮小鬼(哥布林)對比它大型的生物使用攻擊或魔法，並造成傷害時，可以對其造成額外傷害。',
                            '綠皮小鬼可在自己的回合，以一個附贈動作進行撤離或躲藏。'
                        ],
                        'goblin01': [
                            // '[綠皮小鬼 | type:monster]…哥布林？是綠皮的小型怪物嘛…是個邪惡的威脅。',
                            '綠皮小鬼…哥布林？是綠皮的小型怪物嘛…是個邪惡的威脅。',
                        ]
                    },
                }
            },
            'carriage-000:00': {
                descriptions: [
                    '裝完貨物後溫德先生感謝大家的幫忙並準備出發。',
                    '這個時間可以準備好裝備，驢車大約需要花費四個小時才會抵達卡布拉。',
                    '驢車裝載大量的木雕，最多只能再乘載兩位中等體型的人型生物。',
                    '「那麼，都準備好我們就出發了！快上車吧~」溫德先生朝你喊道，他已經坐上馬車等待了。',
                ],
                chance: 0,//0就直接跑response
                options: ['快點[上車 | link:adf6322]吧！。'],
            },
            'adf6322': {
                descriptions: [
                    '在前往卡布拉的小徑上，可能是因為天氣炎熱，路上沒有太多的旅人或商隊。',
                    // '你在路途上搭乘驢車或在一旁徒步隨行。',
                    '驢車在路上緩慢地行駛，路上沒有太多的風，斗大的汗水不斷從驢子的身上流出，溫德先生看起來也十分煩燥。',
                    '當行進到一半的路途，較為偏僻但林木較為茂密的小路，你們穿進一座蔭涼的[樹林 | type:thing | pic:forestpath]中。',
                    '而小路上有一團褐灰色的東西，像個小丘一般，並從一側垂著毫無氣息的驢頭，令你們立刻注意到前方有一頭死掉的[驢子 | type:thing]擋在道路中央。',
                    // '溫德先生會依照角色個性作出合理行動，當角色造近調查死驢時，哥布林會發動[攻擊 | response:attack]，以掠奪驢車。'
                ],
                chance: 3,
                options: ['「這樣可過不去，必須要有人[搬開死驢子 | response:underattack]清空道路。」溫德先生對你說。'],
                behavior: {
                    coping: {
                        'observation': [
                            [1, '你看向[_ | type:thing | behavior:coping | coping:observation]。', 'action to target', 'observation1'],
                            // [1, '你看向死掉的驢子。', 'response', 'observation0'],//這是可以混用的測試
                            [12, '你看向[_ | type:thing | behavior:coping | coping:observation]。', 'action to target', 'observation2'],
                        ],
                        'awareness': [
                            [1, '空氣中只有淡淡的腐敗氣味，在這種炎熱的天氣下，驢子的死亡時間大約在兩小時內。', 'describe'],
                            [12, '當你環顧四周時，似乎感覺驢子的體內有什麼蠕動著。', 'describe'],
                            // [18, '你幾乎能肯定有什麼東西正躲在驢子裡，像是在[埋伏 | type:action]準備偷襲！', 'describe'],//ambush
                            [18, '你幾乎能肯定有什麼東西正躲在驢子裡，像是在埋伏準備偷襲！', 'describe'],
                            [18, '你瞬間警戒起來！', 'response', 'combat2'],
                            [12, '但也許可能只是眼花...', 'response', 'look'],
                        ],
                        'explore': [
                            [1, '你走向驢子屍體以調查死因。', 'response', 'underattack']
                        ]
                    },
                    response: {
                        'combat': [
                            '你退了兩步，準備好[迎戰 | action:combat | coping:goblinLv1 | response:edhsd319]。'
                        ],
                        'combat2': [
                            '「我注意到你們了，出來吧！」你大喊著。',
                            '兩邊的林間走出數隻哥布林，對你發起[戰鬥 | action:combat | coping:goblinLv1 | response:edhsd319]。'
                        ],
                        // 'observation0': ['你看著死掉的驢子，似乎有些害怕。'],
                        'underattack': [
                            // '你靠近驢子並蹲下身子察看，但沒想到從一旁的樹林中跳出一隻哥布林朝你一斧劈來。',
                            '你靠近驢子並蹲下身子察看，同時驢子的肚子突然破開，從裡面跳出一隻哥布林朝你一斧劈來。',
                            '(進行DC15[敏捷檢定 | dc:15-dexterity | success:combat | failure:damage5], 失敗則受到5點傷害)',
                        ],
                        'damage5': [
                            '因為閃躲不及，你受到[5點傷害 | action:damage | value:5 | response:combat]。',
                        ],
                        'observation1': [
                            '死去的[驢子 | type:thing]看起來骨瘦嶙峋，但肚子有些腫大。',
                            '你看著茂密的樹林，心想幸好因為有這片[樹林 | type:thing]，此時你感覺到悶熱一下涼爽了不少。'
                        ],
                        'observation2': [
                            '死去的[驢子 | type:thing]看起來骨瘦嶙峋，也許活著的時候就受到不少虐待，但肚子卻有些異常的腫大。',
                            '[樹林 | type:thing]隨風晃動著，但你感覺似乎有綠皮的人影[隱藏 | response:combat2]在林木之後…',
                        ],
                        'look': [
                            '你仍然盯著驢子，小心翼翼地認為自己需要再觀察一下。'
                        ],
                        'edhsd319': [
                            '戰鬥結束後，你和溫德先生便繼續[前行 | link:oepq94722]。'
                        ]
                    }
                }
            },

            'oepq94722': {
                descriptions: [
                    '在炎熱的陽光下，你們慢慢搭乘著驢車穿過一條條馬路。',
                    '驢車終於抵達了[卡布拉 | pic:cabula]，溫德先生駕駛著驢車來到倉庫區，並且請你幫忙搬貨物至倉庫內。而收件人蘇珊正在裡面等待著。',
                    '完成簽收後，於門外聽到蘇珊正在清點著貨物，溫德先生整理好驢車的貨斗後也準備返回快快貓貨運公司。',
                    '「你要搭順風車回公司領今天的薪水，還是先留在卡布拉辦完事再回去？」溫德先生問著。',

                ],
                chance: 3,
                options: [
                    '你[上車 | response:backhome]後，與溫德先生一起向蘇珊打聲招呼道別。',
                    '你打算[逗留 | response:stay]在卡布拉一會兒，於是向溫德致謝後向他道別。'
                ],
                behavior: {
                    // coping: {
                    // },
                    response: {
                        'backhome': [
                            '「祝你們一路順風，聽說最近綠皮小鬼常常在半路打劫，你們在路上要[小心 | dc:8-wisdom | success:someone | failure:homesweethome]一點呀。」',
                            '蘇珊一臉認真地對你們說。'
                        ],
                        'stay': [
                            '在你看溫德先生的驢車走遠後，『碰』地一聲倉庫的大門似乎被人惡狠狠地關上。',
                            '隨即傳來蘇珊的呼救聲，以及另一個男人的威嚇。悄悄[聽對話 | link:ifow1395]的內容似乎是有個盜賊想打劫倉庫。'
                        ],
                        'homesweethome': ['你心想已經碰到過了，但也懶得跟她吐嘈。四小時的車程回到公司後，領了薪水便回家了。[(END) | behavior:end]'],
                        'someone': [
                            '正當你們和蘇珊說話時，身為冒險者的你感覺倉庫的更深處有[人影晃動 | link:bwpfj2941]。',
                        ]
                    },
                },
            },
            'ifow1395': {
                descriptions: [
                    '「誰來救救我，你別過來~」蘇珊在裡頭哭喊著。',
                    '「閉嘴！妳最好乖乖把鑰匙交出來，妳不用受傷，我也可以拿完需要的東西就走！」',
                ],
                chance: 0,
                options: [
                    '無助的蘇珊需要你的幫助，於是你決定[伸出援手 | response:helpher]。',
                    // '無助的蘇珊需要你的幫助，於是你決定[伸出援手 | link:dibow824]。',
                    '也許蘇珊能聽他的話乖乖交出鑰匙就沒事，你還是[別多管閒事 | response:leavehere]了。'
                ],
                behavior: {
                    response: {
                        'helpher': [
                            '你思索著如何進入倉庫的[方法 | link:dibow824]。'
                        ],
                        'leavehere': [
                            '於是你決定忘了這件事，只要蘇珊交出鑰匙就是雙贏局面，根本無須你的插手。',
                            '你漫走走向卡布拉的繁華之處，準備好好享受這個城鎮的美景。[(END) | behavior:end]'
                        ]
                    }
                }
            },
            'dibow824': {
                descriptions: [
                    '倉庫[大門 | type:thing]被鎖上且十分牢固，但據你所知這不是唯一的出入口。',
                    '如果有時間的話，也許應該探索一下倉位的建築結構再決定下一步。',
                    '但蘇珊的哭喊聲也不時傳入你的耳中。'
                ],
                chance: 5,
                options: [
                    '救人心切的你決定直接[破門而入 | response:dgrdb48]。',
                ],
                behavior: {
                    coping: {
                        'explore': [
                            [1, '你探索周遭，發現[後門 | type:thing]也被鎖上了。', 'describe'],
                            [4, '除此之外的[窗戶 | type:thing]也被鎖上，你沒有辦法直接進入。', 'describe'],
                        ],
                        'dexterity': [
                            [1, '你試著嘗試解開[_ | type:thing]的鎖。', 'action to target', 'unlockfail'],
                            [13, '你試著嘗試解開[_ | type:thing]的鎖。', 'action to target', 'unlickbackdoor'],
                            // [16, '你試著嘗試解開[_ | type:thing]的鎖。', 'action to target', 'unlickdoor'],
                        ]
                    },
                    response: {
                        'unlockfail': [
                            '[後門 | type:thing]的鎖明明看起來不是那麼難解，但卻難倒了你。',
                            '[大門 | type:thing]的鎖複雜到讓你感到頭疼。',
                            '[窗戶 | type:thing]設有防盜的裝置，你碰觸窗戶導致觸發陷阱。(進行DC15[敏捷檢定 | dc:15-dexterity | success:combat | failure:damage5], 失敗則受到5點傷害)'
                        ],
                        'unlickbackdoor': [
                            '你成功解開[後門 | type:thing]的鎖，並且看見一名[盜賊 | response:fistfight]正拿著匕首威脅著蘇珊。',
                            '[大門 | type:thing]的鎖過於複雜，你試了許久仍未成功。',
                            '[窗戶 | type:thing]設有防盜的裝置，即使你小心翼翼地避開但仍觸發了陷阱。(進行DC15[敏捷檢定 | dc:15-dexterity | success:combat | failure:damage5], 失敗則受到5點傷害)'
                        ],
                        'unlickdoor': [
                            '你成功解開[後門 | type:thing]的鎖，並且看見一名[盜賊 | response:fistfight]正拿著匕首威脅著蘇珊。',
                            '你成功解開[大門 | type:thing]的鎖，並且看見一名[盜賊 | response:fistfight]正拿著匕首威脅著蘇珊。',
                            '你成功解開[窗戶 | type:thing]的鎖，並且看見一名[盜賊 | response:fistfight]正拿著匕首威脅著蘇珊。',
                        ],
                        'damage5': [
                            '因為閃躲不及，你受到[5點傷害 | action:damage | value:5]。',
                        ],
                        'fistfight': ['那名盜賊看見你闖了進來，將[戰鬥 | action:combat | coping:thiefLv1 | response:secondfight]的目標轉向了你。'],
                        'dgrdb48': [
                            '你試著使用蠻力破開倉庫大門。(進行DC16[力量檢定 | dc:16-strength | success:brokendoor | failure:brokenfailure]，失敗時受到輕微的反彈傷害)'
                        ],
                        'brokendoor': ['你蓄力用身子一撞，巨大的倉庫門被你轟地一聲[撞開 | link:dgrdb48]。'],
                        'brokenfailure': [
                            '作為保護重要財物的倉庫，大門十分堅固。',
                            '你奮力地想破開大門，不但沒有成功，反而還讓自己受傷了。(受到1點[傷害 | action:damage | value:1])',
                            '但大門卻還是在半秒後傾斜歪曲，你仍然可以[破門 | link:dgrdb48]而入。'//todo 這邊有點問題，它沒有正確改link，而是把舊的response按鈕重複一次然後跑完才出現link 的連結
                        ],
                        'secondfight': [
                            '這個盜賊被你打倒後，伸手探入身旁因為戰鬥而波及的破木箱，並拿出木雕並[唸唸有詞 | link:bispe1335]著。',
                        ],
                    }
                }
            },
            'dgrdb48': {
                descriptions: [
                    '破門而入的你讓蘇珊與那名盜賊都大吃一驚。',
                    '「那個…大門的修理費要賠哦…」蘇珊小姐似乎忘記害怕了。',
                    '而那名盜賊瞪大雙眼並張大嘴驚慌地看著你。'
                ],
                chance: 3,
                options: [
                    '那名盜賊很快就回神，並將武器上手，[準備戰鬥 | response:fistfight]。'
                ],
                behavior: {
                    response: {
                        'fistfight': ['同時，你也做好準備與他[戰鬥 | action:combat | coping:thiefLv1 | response:secondfight]。'],
                        'secondfight': [
                            '這個盜賊被你打倒後，伸手探入身旁因為戰鬥而波及的破木箱，並拿出木雕並[唸唸有詞 | link:bispe1335]著。',
                        ],
                    },
                }
            },
            'bwpfj2941': {
                descriptions: [
                    '「蘇珊小姐，今天不是妳一個人嗎？」',
                    '「今天只有我值班，你想幹嘛？」'
                ],
                chance: 3,
                options: [
                    // '你心想蘇珊是不是以為我想約她，於是你[轉頭就走 | response:backhome]。',
                    '你[提醒 | response:someone]蘇珊，倉庫裡面似乎有其他人。'
                ],
                behavior: {
                    // coping: {
                    // },
                    response: {
                        // 'backhome': [
                        //     '走人回家。'
                        // ],
                        'someone': [
                            '蘇珊此時一臉緊張，立刻回頭張望，並大驚失色：',
                            '「有賊呀！救命！」蘇珊大喊並丟下手上的東西，立刻朝你跑過來。',
                            '「真是多管閒事的伙傢啊…」一個賊頭鼠腦的傢伙突然從暗處現身，並朝蘇珊走去，似乎要挾持她。',
                            '你讓溫德先生先走，自己留下來保護蘇珊而衝上前[迎戰 | action:combat | coping:thiefLv1 | response:secondfight]。'
                        ],
                        'secondfight': [
                            '這個盜賊被你打倒後，伸手探入身旁因為戰鬥而波及的破木箱，並拿出木雕並[唸唸有詞 | link:bispe1335]著。',

                        ],
                    },
                }
            },
            'bispe1335': {
                descriptions: [
                    '「可…可惡…我怎麼能就此落敗…明明是這麼容易的工作啊！」',
                    '你看見落敗的盜賊，拿起一旁的木雕唸起咒語。',
                    '「這個…難道是召喚火魔蝠的木雕像嗎？」',
                    '蘇珊驚訝地看著一團火柱從融化的木雕像之中升起，召喚的盜賊此時卻哀嚎著，他被火焰包圍後不一會就再無聲息…',
                    '而一隻火魔蝠從逐漸消散的火柱中間成形，散發著如融岩般的暗紅紋路。',
                    '牠注意到距離最近的你，並衝鋒過來！'
                ],
                chance: 3,
                options: [
                    '你[閃避 | dc:12-dexterity | success:dogesuccess | failure:dogefail]著如迅雷一般的攻擊。'
                ],
                behavior: {
                    response: {
                        'dogesuccess': [
                            '你及時閃避了攻擊，但火魔蝠在空中盤旋一陣子後，很快地再次鎖定你為目標，但你早已準備好[再次迎戰 | action:combat | coping:firebatLv1 | response:finalfight]。'
                        ],
                        'dogefail': [
                            '你閃避不及，對你造成了3點[傷害 | action:damage | value:3]。',
                            '逼得你不得不[再次迎戰 | action:combat | coping:firebatLv1 | response:finalfight]。'
                        ],
                        'finalfight': [
                            '你成功消滅了火蝙輻，獲得了[獎勵 | link:biuwpa73]。'
                        ]
                    }
                }

            },
            'biuwpa73': {
                descriptions: [
                    '蘇珊十分感謝你擊退了這次的襲擊，並且向公會提出追加的獎勵給你。'
                ],
                chance: 3,
                options: [
                    '對這額外的獎勵，你開心地[領取 | response:finish]1枚金幣。',
                ],
                behavior: {
                    response: {
                        'finish': ['開心地結束了。[(END) | behavior:end]']
                    }
                }
            },

            // 'hoepq1842': {
            //     descriptions: [
            //         '「蘇珊小姐，今天不是妳一個人嗎？」',
            //         '「今天只有我值班，你想幹嘛？」'
            //     ],
            //     chance: 3,
            //     options: [
            //         '你心想蘇珊是不是以為我想約她，於是你[轉頭就走 | response:backhome]。',
            //         '你[提醒 | response:someone]蘇珊，倉庫裡面似乎有其他人。'
            //     ],
            //     behavior: {
            //         response: {

            //         }
            //     }
            // },

            'hdse11589': {
                descriptions: [
                    '當夕陽的餘暉逐漸縮小，直至沒入地平線下，天空也從滿天的紅霞漸漸被上滿是星光的暗藍色薄幕。',
                    '一隻枯瘦墨黑的手破開黃砂緩緩伸出，隨之掩藏在砂土下的深黑色身軀爬起。',
                    '隨著砂子的滑落，如同枯枝般的[黑死屍 | type:monster]，一下就發現你的位置。',
                    '彷彿是刻意潛伏在地下等待身為獵物的你。',
                    '但你明白，那是白天時砂漠的炎熱，才讓枯乾的黑死屍動彈不得，這種時候如果能趁機解決它們就省事多了。',
                    '漸漸地，一具具從砂土中爬出的黑死屍也越來越多。',
                    '很顯然，安穩地躲在塔城裡的人們，根本不在乎外頭聚集多少黑死屍。',
                    '黑死屍們一個個轉身向你緩步走來，體力用盡就快虛脫的你只能咬牙拖著腳步離開。',
                    '「喂！這還能再用個幾發火球，之後再好好地感謝我吧！」',
                    '[貴婦 | type:npc]的聲音從上面傳來，你抬頭看著她扔下一個[袋子 | type:thing]，落在屍群的後方。',
                    '「這用來對付黑死屍，也實在是太浪費了…」',
                    '一旁的[守衛 | type:npc]抱怨著，即使在三層樓高，他的婉惜仍然傳入你的耳裡。',
                    '(你瞧了一眼掉落在附近的袋子)',
                    // action: 要跳出選擇，並檢查 type
                    // [撿東西 | action:collect | type:thing]
                    // behavior: 檢查 behavior 下有沒有對應的指令，如 [behavior:coping] 就要找 coping 這個 behavior 下的指令
                    // 你想[怎麼做 | behavior:coping]？
                ],
                chance: 3,
                // question: '(你瞧了一眼掉落在附近的袋子)',
                // chance 次數用完/直接跳過時：[描述,linkid]
                options: ['面對黑死屍的來襲，手足無措的你在本能的驅動下而[逃跑 | response:ddac112]了。'],
                // npcs: ['守衛', '貴婦'],
                // monsters: ['黑死屍'],
                // things: ['袋子'],
                behavior: {
                    coping: {
                        'observation': [
                            // todo 目前是可以在捲到最底來觸發按鈕，不過目前新增對應按鈕的部份還沒有實作
                            // [1, '[逃跑 | coping:survival]吧！不斷有更多的黑死屍緩緩地爬起，思緒混亂的你心裡這麼想著。', 'describe'],
                            // [5, '但你感覺袋子中的東西能幫助你應付眼前的情況。只要有機會能[推開 | coping:shove]眼前那具黑死屍，便能很輕易地拾取袋子。', 'describe']
                            [1, '[逃跑]吧！不斷有更多的黑死屍緩緩地爬起，思緒混亂的你心裡這麼想著。(生存技能)', 'describe'],
                            [5, '但你感覺袋子中的東西能幫助你應付眼前的情況。只要有機會能[推開]眼前那具黑死屍，便能很輕易地拾取袋子。(推撞技能)', 'describe']
                        ],
                        // **「給我滾開！」你威嚇著[_ | type:npc|monster]**
                        'intimidation': [
                            [1, '「給我滾開！」你威嚇著[_ | type:monster]。', 'action to target', 'abc123'],
                            [20, '你做出浮誇的攻擊姿勢想嚇退[_ | type:monster]', 'action to target', 'abb223'],
                            [5, '「快讓我進城！否則我就把戒指扔了！」你對[_ | type:npc]吼著。', 'action to target', 'bbd11']
                        ],
                        'survival': [
                            [1, '轉身就直接逃離屍群。', 'response', 'dii32'],
                            [12, '在逃走前注意著屍群的動向。', 'response', 'abnopd31']
                        ],
                        'shove': [
                            [1, '[推撞]不顧一切地用盡全力推撞眼前的黑死屍', 'response', 'diwen1290'],
                            // [12, '你掌握到黑死屍的移動重心，發力推撞它。', 'response', 'beju8942']
                            [12, '[絆摔]你掌握敵人的重心後發力推倒它。', 'response', 'bnidk3623']
                        ]
                    },
                    response: {
                        'combat': ['你失敗了，因而被迫[戰鬥 | action:combat | coping:monster | response:edh03sd9]'],
                        'abc123': ['[_ | type:monster]並沒有停下腳步, 仍然朝你走來。'],
                        'abb223': ['眼前的[_ | type:monster]安靜下來並凝視著你一會兒，但還是繼續朝你走來。'],
                        'bbd11': ['但是你的威脅沒有得到[_ | type:npc]的回應。等你注意到時，塔城上早已沒有任何人影。'],
                        'dii32': [
                            '你慌亂地逃跑，但讓更多的黑死屍注意到你。',
                            '有如無頭蒼蠅一般不斷地在尋找安全的地點，但屍群們卻沒有放棄跟著你。',
                            '無數個枯瘦的黑影開始追了上來，因為氣喘噓噓的你幾乎快要累倒了。',
                            '你知道如果不想成為它們的一份子，就不能停下腳步。',
                            '你試著穩定呼吸讓自己堅持下去。(進行DC13[韌性檢定 | dc:13-resilience | success:igpek532 | failure:combat]，失敗進入戰鬥)'
                        ],
                        // 'aaa2341': [],
                        // 'djei1293': ['你轉身就直接逃離屍群。'],
                        'abnopd31': [
                            '你一邊注意著屍群的動向，一邊向後奔跑，直到找到安全的藏匿處。',
                            '直到天亮，你才[返回 | link:gkddd1234]塔城。'
                        ],
                        'igpek532': [
                            '你成功地遠離了屍群，直到有個暫時的躲藏之處才停下來休息。',
                            '直到天亮，你才[返回 | link:gkddd1234]塔城。'
                        ],
                        'diwen1290': [
                            '你用力推撞黑死屍，卻一時失去準頭跌倒在屍群之中。',
                            '你慌亂起身並打算遠離它們。(進行DC15[敏捷檢定 | dc:15-dexterity | success:igpek532 | failure:combat]，失敗進入戰鬥)'
                        ],
                        // 'beju8942': [
                        //     '你成功推開黑死屍，並撿拾到袋子',
                        //     '翻開袋子後發現裡面有個[火球項鍊 | type:thing | action:collect]，你可以用它來對付黑死屍。'
                        // ],
                        'bnidk3623': [// todo 獲得道具，進入戰鬥，火球項鍊可以作為戰鬥武器使用，先攻做優勢骰
                            '你使勁推開擋在眼前的黑死屍，並避開它們的啃咬，快速撿起袋子並遠離原地。',
                            '如果炎熱能夠讓黑死屍動彈不得，那火炎就能有效制止它們的行動。',
                            '往袋子裡看一眼，你立刻知道袋子裡裝的是火球項鍊。',
                            '即使項鍊上只剩3顆珠子。',
                            '你可以用一個動作取下一顆珠子並投擲到至多 60 尺遠的地方。它將在移動軌跡的終點爆炸，效果等同於 3 環的火球術。',
                            '火球術的有效範圍為20 尺，以爆炸中心球體內的每一名生物都要進行一次敏捷豁免。失敗的生物受到8d6火焰傷害，成功的話受到一半傷害。',
                            '這時候只要能好好地將黑死屍聚集起來，也許這個數量真的能夠一次解決。',
                            '伴著深沉的嗚響爆出火焰，緩慢的黑死屍根本無法閃避。',
                            '「總算全解決了…」',
                            '你成功清除了所有的黑死屍，但塔城上並沒有任何歡呼，甚至連對你的作為毫無回應。',
                            '再怎麼喊也沒有回應，你只能到附近的安全點休息，就這樣等到天亮。',
                            '你直到天亮才[返回塔城 | link:gkddd1234]'
                        ],
                        'ddac112': [
                            '你覺得不值得為了一個袋子裡的東西冒險，轉身便逃離屍群。',
                            '耳邊傳來自己的腳步聲，每一步踏在鬆軟的砂土上，都會不斷消耗你的體力，但對那些追著你的屍群來說，卻幾乎沒什麼影響。',
                            '無數個枯瘦的黑影開始追了上來，而氣喘噓噓的你卻幾乎要累倒了。',
                            '你知道如果不想成為它們的一份子，就不能停下腳步。',
                            '你被絆了一下，有一具你沒發現的黑死屍，突然從你的腳下爬出撲上了你。',
                            '你必須在屍群追上你之前，[擺脫 | dc:12-dexterity | success:igpek532 | failure:combat]這名阻礙你移動的敵人(進行DC12敏捷檢定，失敗進入戰鬥)。',
                        ],
                        'edh03sd9': [
                            '砸碎這具黑死屍的頭後，你起身繼續逃跑。',
                            '你不斷地向前奔跑，但屍群卻越來越多，你越來越難以前進。',
                            '你逐漸被追上，只能試著加快速度[擺脫 | dc:8-dexterity | success:igpek532 | failure:combat]它們(進行DC8敏捷檢定，失敗進入戰鬥)。'
                        ]
                    },
                },


            },

            'gkddd1234': {
                descriptions: [
                    '天亮後，你在塔城下還沒開口，守衛便已拋下一個帶著細繩的小竹簍。',
                    '「能讓我進城了嗎？」',
                    '你問著，其實只撇了一眼你就已經明白，這樣的細繩絕對不會有歡迎你攀上去的意思。',
                    '事實上，你連怎麼進城都不知道。',
                    '無論你繞著塔城走了無數次，仍舊沒辦法找到進城的方法。',
                    '「把戒指放進竹簍，我們有好消息告訴你。」',
                    '從守衛的戲謔的語氣，你覺得會是個壞消息。',
                    '「你們還是沒打算讓我進去吧？」',
                    '「別這麼說嘛，我們是能讓你進來，但要進來塔城是必須有條件的。」',
                    '「你們…明明做了承諾，只要我去找那條狗，就讓我進城的！」',
                    '「噢不不不…你說錯了，我們是要你找到那條狗並帶回來，但你不是連根狗毛都沒找到嗎？」',
                    '「但是…」',
                    '你咬了咬牙。',
                    '事實上，你在前一天已經找到婦人她那化為黑死屍的丈夫、還有她叨唸著的家傳寶戒。',
                    '因為她不斷抱怨著丈夫拿走家傳的紅寶石戒指去找小三，連她的愛犬都追隨著丈夫與小三而去。',
                    '在她的故事裡，她留戀著戒指的價值，以及對狗的愛。你忍受到天氣的炎熱，只為了聽她不斷抱怨著無關緊要的事。',
                    '你原以為，沒有找到狗，就算把家傳寶戒帶回來也能交差。',
                    '但是並沒有。',
                    '而且，你也不能說他們反悔。',
                    '「說吧，你們還有什麼條件？」'
                ],
                chance: 0,
                options: ['[確認 | behavior:end]'],
                behavior: {
                    // coping: {
                    //     'observation': [
                    //         [1, '「給我滾開！」你威嚇著[_ | type:monster]。', 'action to target', 'abc123'],
                    //     ]
                    // },
                    response: {

                    }
                }
            }
        };

        let chapterIndex = 0;
        this.chapters[chapterIndex] = [];
        // this.chapters[chapterIndex].push('在遙遠的奇幻世界中，有一片被古老魔法和神秘生物統治的大陸。');
        // this.chapters[chapterIndex].push('受到神的祝福，因而命名為[埃瑟隆]。');
        // this.chapters[chapterIndex].push('大陸由五大王國組成，每個王國都有其獨特的文化和魔法學派。');
        // this.chapters[chapterIndex].push('然而，和平的時光不再，一個[古老預言]應驗了…');
        // this.chapters[chapterIndex].push('一條恐怖的龍，名為[卡札特]，從千年的封印中甦醒，帶來了[毀滅]與[死亡]。');
        // this.chapters[chapterIndex].push('卡札特擁有焚燒一切的火焰呼吸和堅不可摧的鱗片，牠在暗夜中飛翔，籠罩大地於無盡的恐懼之中。');
        // this.chapters[chapterIndex].push('各國的領袖們從古老的文書中發現，只有將五個[古老的神器]集齊，才能封印卡札特，重新帶來和平。');
        // this.chapters[chapterIndex].push('這五個神器散落於[蠻獸荒野]、[幽深地城]和[遺忘聖殿]中。');
        this.chapters[chapterIndex] = [
            '滾燙的黑色血液順著你的手臂緩緩流下來，滴落在砂土之前就已經凝結成一小片黑鐵。',
            '你在灼熱的砂漠裡不斷前行，過往同伴的請託讓你無法停下腳步，而心中狂燥的慾望卻又讓你渴求戰鬥。',
            '狂風肆虐的砂丘下，無數被砂土掩埋的漆黑屍骨。砂土隨意地覆蓋著它們，露出像是枯乾木乃伊的外表，卻又泛著金屬質感的黑鐵外殼。',
            '黑死屍，你和你的同伴是這麼稱呼這些早就死了，卻又沒死透的傢伙們。',
            '呢喃的聲音隨著黑死屍的掙扎而不斷傳來，你巴不得停下腳步殺光它們，但使命感讓你持續前行，直到遠離這場災難。',
            '這一場災難的開頭，在一座名為馬里布的大城市裡，是一場飛空艇墜落意外之後。',
            '從墜毀的飛空艇中湧出了無數的黑死屍，它們幾乎殺光所有馬里布的生命，在付出一切後你與你的同伴們僥倖地逃離那座城市。',
            '強大的城防與經驗豐富的冒險者都無法抵抗它們，反抗的結果也只是增加它們的數量。',
            '無人對付過這種像是殭屍，卻無法以神聖魔法驅散的不死生物；亦無人對付過這種外殼比魔偶更加堅硬，卻不存在魔核的殺人機器。',
            '更無人對付過這種只需要透過傷害其他生物，就能夠不斷製造伙伴的怪物。',
            '你們最後只能不斷地從這群怪物的威脅下逃離，不知不覺間變為沒有盡頭的旅程。',
            '「我走不動了啦…」',
            '你頭也不回，無視一路跟隨在你身後的小女孩的請求。',
            '直到她開始哀求著你停下來休息。',
            '「再堅持一下，我們就快到塔城了。」',
            '其實你並不知道塔城究竟還有多遠，但你知道天黑之前你必須找到一個安全的地方。',
            '因為你無法肯定在黑死屍的圍攻之下，這個女孩還能夠再撐過下一個夜晚。'
        ];
        // this.chapters[chapterIndex].push('');

        this.monsters = {
            'goblinLv1': {
                icon: 'goblin',
                ac: 12,
                dex: 14,
                constitution: 5,
                spirit: 2,
                willpower: 5,
            },
            'thiefLv1': {
                icon: 'thief',
                ac: 12,
                dex: 16,
                constitution: 8,
                spirit: 2,
                willpower: 5
            },
            'firebatLv1': {
                icon: 'firebat',
                ac: 15,
                dex: 16,
                constitution: 10,
                spirit: 2,
                willpower: 5
            },
            'brainLv1': {
                icon: 'wisdom_brain',
                ac: 14,
                dex: 12,
                constitution: 5,
                spirit: 20,
                willpower: 15
            },
            'ironWarriorLv1': {
                icon: 'iron_warrior',
                ac: 16,
                dex: 8,
                constitution: 25,
                spirit: 10,
                willpower: 15
            },

        };
        this.dungeons = {
            'abcd234': {
                "roomType": "Dungeon",
                "icon": "creation2",
                "name": "幽深地城",
                // "descriptions": ["這個深藏在圖書館之下的地下城，充滿了神秘的魔法。", "這裡有一份紀錄著神器位置的文件，如果沒有它就無法找到幽深地城中的神器所在。"],
                'descriptions': this.chapters[chapterIndex],
                "connectIn": ["def765"],
                "locations": [
                    {
                        // "roomType": "DungeonRoom",
                        // "icon": "creation",
                        // "name": "入口",
                        // "descriptions": ["一個充滿了神秘力量的地下城，充滿了神秘的魔法。"],
                        // "connectOut": ["def765"],
                        // "out": [
                        //     {
                        //     }
                        // ],
                        "position": [2, 0],
                        "size": [5, 5],
                        "rooms": [
                            {
                                name: "入口",
                                icon: "creation2",
                                descriptions: ["剛進入地下城，充滿了著霉味與腐朽的氣味，令人鼻子不禁癢了起來。"],
                                question: "輸入[三碼數字]的密碼解鎖[密碼鎖]後，順利打開[盒子]後從裡面取出一把精美的<color=#ffcc00>寶石匕首</color>。",
                                cards: [
                                    {
                                        [CardSuit.Prop]: "牆角邊有一個普通的木桶。",
                                        [CardSuit.Presage]: "木桶似乎有些新的小洞口。",
                                        [CardSuit.Clue]: "木桶的裡面有一個小小的洞，透過洞望進去可以看到一張寫著[三碼數字]的小紙條。",
                                        [CardSuit.Doubt]: "木桶的洞似乎被不斷挖開過，也許有些人想從中掏出什麼？"
                                    }, {
                                        [CardSuit.Prop]: "[盒子]用[密碼鎖]上鎖了。",
                                        [CardSuit.Presage]: "[盒子]有些沉重，裡面裝著什麼。",
                                        [CardSuit.Clue]: "[盒子]上的鎖，是個三位數的[密碼鎖]。",
                                        [CardSuit.Doubt]: "[盒子]有個鎖，裡面的東西似乎很重要？"
                                    }, {
                                        [CardSuit.Prop]: "一扇被破壞過的窗戶。",
                                        [CardSuit.Presage]: "窗戶上的窗簾看起來很破舊。",
                                        [CardSuit.Clue]: "窗簾似乎被巨大的爪子抓過…",
                                        [CardSuit.Doubt]: "窗戶的玻璃全被敲破，因此釘上許多木板，也許曾經有人想突破進來？"
                                    }
                                ]
                            }, {
                                name: "某個房間",
                                icon: "creation2",
                                descriptions: [],
                                question: "有<color=#ffcc00>寶石匕首</color>。",
                                cards: [
                                    {
                                        [CardSuit.Prop]: "牆角邊有一個普通的木桶。",
                                        [CardSuit.Presage]: "木桶似乎有些新的小洞口。",
                                        [CardSuit.Clue]: "木桶的裡面有一個小小的洞，透過洞望進去可以看到一張寫著[三碼數字]的小紙條。",
                                        [CardSuit.Doubt]: "木桶的洞似乎被不斷挖開過，也許有些人想從中掏出什麼？"
                                    }
                                ]
                            }, {
                                name: "出口",
                                icon: "creation2",
                                descriptions: [],
                                question: "透過寫在[照片]背面的開啟方法，打開[密封罐]後從中掏出一卷<color=#ffcc00>紅印文件</color>。",
                                cards: [
                                    {
                                        [CardSuit.Prop]: "展示櫃內部陳列著各式各樣的收藏品。",
                                        [CardSuit.Presage]: "當靠近展示櫃時，可以聽到微弱的機械運作聲。",
                                        [CardSuit.Clue]: "展示櫃的一個[密封罐]的位置發現了被頻繁觸碰或移動的磨損痕跡。",
                                        [CardSuit.Doubt]: "展示櫃中一件展品標籤與其他似乎略有不同"
                                    }, {
                                        [CardSuit.Prop]: "展示櫃的[密封罐]中裝有一卷羊皮紙。",
                                        [CardSuit.Presage]: "[密封罐]外觀與它應有的重量還來得輕。",
                                        [CardSuit.Clue]: "[密封罐]的蓋子有特殊的旋轉機制，需按照特定順序旋轉才能打開。",
                                        [CardSuit.Doubt]: "罐內的物品看起來與展示櫃中其它展示物毫無關聯。"
                                    }, {
                                        [CardSuit.Prop]: "[文書匣]內部分類細緻，但其中一個隔層異常緊固。",
                                        [CardSuit.Presage]: "打開[文書匣]時，一股陳年的紙張氣味撲面而來，中間卻夾帶著一絲[新墨水]的氣味。",
                                        [CardSuit.Clue]: "文書匣中一份文件因[紅色印記]而十分顯眼，但明顯是偽造的，用來掩蓋真實文件的存在。",
                                        [CardSuit.Doubt]: "[文書匣]中某些文件顯示出被重新放置的痕跡，似乎有人試圖隱藏或更改某些信息。"
                                    }, {
                                        [CardSuit.Prop]: "相框是普通的裝飾品，背板可以拆卸取出[照片]",
                                        [CardSuit.Presage]: "觀察相框時，可以發現框架的某部分略有色差。",
                                        [CardSuit.Clue]: "相框中的[照片]的背面寫上如何開啟[密封罐]的方法。",
                                        [CardSuit.Doubt]: "照片中的人物與房間內其他照片的人物不同"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
        };
    }

    ethnicityHumanIntro1: string[] = [
        '人類在近二十歲時成年，且可活不到一世紀。',
        '人類並不傾向特定陣營。你可以在他們之中找到最好以及最壞的個體。',
        '人類身高體格之間的差距很大，從勉強5呎高到遠超過6呎都有。不論你在這範圍內的位置為何，你的體型為中型。',
        '你可以說、讀、寫通用語和另一種你所選擇的語言。',
        '人類通常會學習那些與他們打交道的其他族類的語言，包括那些晦澀難解的方言。',
        '他們喜歡借用來自其他方言的字詞去點綴他們的言詞，像是獸人的咒罵、精靈音樂般的措辭、矮人的軍事片語、諸如此類。'
    ];

    ethnicityElfIntro1: string[] = [
        '儘管精靈和人類會在差不多的年齡達到生理成熟，但精靈對成年的見解並不只是生理成熟，還包括世俗的經驗。',
        '精靈通常在100歲前後宣告成年並得到成年名稱，且其壽命可達750歲。',
        '精靈熱愛自由、多元、和自我表現，因此他們強烈傾向於較溫和的混亂。',
        '他們將他人的自由當作自己的來重視與保護。他們通常都是善良的。',
        '精靈的身高範圍從不到五呎到超過六呎，且有著苗條的體格。你的體型為中型。',
        '習慣了微光森林與夜空，你在黑暗與微光環境下仍能保持卓越視覺。',
        '你在看距離你60呎範圍內的事物時，微光的照明程度對你而言視作明亮，黑暗則視作微光。',
        '你無法辨別黑暗中的顏色，而只能看到灰黑的輪廓。',
        '你熟練於感知技能。',
        '你在對抗魅惑的豁免檢定中具有優勢，且魔法無法讓你入睡。',
        '精靈並不需要睡眠。取而代之，他們一天會進行4小時保留潛意識的深度冥想。',
        '（通用語將這種冥想稱為"傳思"）在冥想時，你勉強算是會作夢；這些夢境實際上是在多年訓練下產生的反射性心靈鍛鍊。',
        '在以這種方式休息後，你得到與人類8小時睡眠後相同的益處。',
        '如果你在長休期間冥想，你可以在花費4小時完成冥想後，在剩下的4小時中保持清醒，並進行輕省活動。',
        '你仍然需要花費8小時來完成長休。',
        '你能夠說、讀、寫通用語和精靈語。精靈語如流體般流暢，有著精妙的語調變化和複雜的語法結構。',
        '精靈文學豐富而多元，他們的詩歌在其他種族之間也很受歡迎。',
        '許多吟遊詩人都會學習精靈語，並將其韻律運用在他們自己的詩作中。',
        '你具有對死靈傷害的抗性。',
        '"鴉后的祝福" 以一個附贈動作，你可以魔法性的傳送最多30呎距離到一處未被佔據的可見空間。',
        '一旦你使用此特性，直到你完成一次長休之前都無法再使用它。',
        '從3級開始，當你使用此特性傳送時，你也獲得對所有傷害的抗性。',
        '這個抗性持續到你的下個回合開始。在這段期間，你變得朦朧且半透明。'
    ];

    ethnicityHalfElfIntro1: string[] = [
        '半精靈的成熟速度和人類相同，並在20歲左右成年。',
        '然而，他們的壽命遠長於人類，經常能活超過180歲。',
        '半精靈分享了來自他們精靈血統的混亂天性。他們重視個人自由和創造性表達，既不展現出對領導者的喜愛、也不渴望受人追隨。',
        '他們厭惡規則、討厭被別人命令、且有時會顯得不太可靠——或至少難以預測。',
        '半精靈有著和人類相近的體型，身高介於5呎至6呎之間。你的體型為中型。',
        '多虧於你的精靈血統，你在黑暗與微光環境下仍能保持卓越視覺。',
        '你在看距離你60呎範圍內的事物時，微光的照明程度對你而言視作明亮，黑暗則視作微光。',
        '你無法辨別黑暗中的顏色，而只能看到灰黑的輪廓。',
        '你在對抗魅惑的豁免檢定中具有優勢，且魔法無法讓你入睡。',
        '你熟練於二個你所選擇的技能。',
        '你能夠說、讀、寫通用語、精靈語、和另一種你所選擇的語言。'
    ];

    ethnicityOrcIntro1: string[] = [
        '獸人在12歲時成年，並可以活到最多50歲。',
        '獸人是惡毒的掠奪者，他們相信這個世界應該屬於他們。',
        '他們崇敬力量高於一切，並相信強者必須欺凌弱者以確保軟弱不會像疾病一樣傳播。他們通常是混亂邪惡。',
        '獸人通常超過6呎高，且體重介於230到280磅之間。你的體型為中型。',
        '你在看距離你60呎範圍內的事物時，微光的照明程度對你而言視作明亮，黑暗則視作微光。',
        '你無法辨別黑暗中的顏色，而只能看到灰黑的輪廓。',
        '以一個附贈動作，你可以向一個你所能看見或聽見的敵意生物移動最多等同你移動速度的距離。',
        '你必須在比你開始移動時距離該敵人更近的位置結束此移動。',
        '你熟練於威嚇技能。',
        '當決定你的負重以及你可以拖曳、推動、或提舉的重量時，你將你的體型視作比原本大一級。',
        '你可以說、讀、寫通用語和獸人語。'
    ];

    ethnicityHalfOrcIntro1: string[] = [
        '半獸人的成熟速度比人類略快一些，並在14歲左右便成年。他們的衰老速度明顯更快，且很少能活超過75歲。',
        '陣營. 半獸人從他們的獸人親代繼承了容易傾向於混亂的血統，且因此不會有善良陣營的強烈傾向。在獸人中成長並願意在其中生活的半獸人通常是邪惡的。',
        '體型. 半獸人比人類更大而魁梧，他們的身高範圍從不到5呎到遠超過6呎都有。你的體型為中型。',
        '黑暗視覺. 多虧於你的獸人血統，你在黑暗與微光環境下仍能保持卓越視覺。你在看距離你60呎範圍內的事物時，微光的照明程度對你而言視作明亮，黑暗則視作微光。你無法辨別黑暗中的顏色，而只能看到灰黑的輪廓。',
        '兇惡. 你熟練於威嚇技能。',
        '頑強耐性. 當你的生命值被歸零但沒有當場被殺死時，你可以改為使生命值減少至1。直到完成一次長休之前，你都不能再使用這個特性。',
        '野蠻攻擊. 當你以一次近戰武器攻擊造成重擊時，你可以額外骰一次該武器的其中一顆傷害骰，並將之加入重擊的額外傷害中。',
        '語言. 你可以說、讀、寫通用語和獸人語。獸人語是一種使用硬輔音的粗糙、刺耳的語言。它沒有自己的文字，而是使用矮人文字進行書寫。'
    ];
    ethnicityHalfingIntro1: string[] = [
        '半身人在20歲時成年，且通常可以活到150歲。',
        '陣營. 大部分的半身人都是守序善良。一般來說，他們心地善良、和藹可親，厭惡看見他人受苦，且完全不能容忍壓迫。他們也很守秩序、助重傳統、無比倚重他們社群的支持以及老套生活所帶來的舒適。',
        '體型. 半身人平均大約3呎高，且體重約莫40磅。你的體型為小型。',
        '幸運. 當你在攻擊檢定、屬性檢定、或豁免檢定中骰出了1，你可以重骰該檢定且必須使用新的擲骰結果。',
        '勇敢. 你在對抗恐懼的豁免檢定中具有優勢。',
        '半身人靈巧. 你可以移動穿過任何體型大於你的生物所在的空間。',
        '語言. 你能夠說、讀、寫通用語和半身人語。半身人的語言並不是秘密，但他們並不怎麼情願與他人分享它。他們很少書寫，因此並沒有豐富的文學作品。然而，他們的口說傳統相當強勢。幾乎所有半身人都會說通用語，以跟他所居住或旅經地區的人們交談。',
        '強魄韌性. 你在對抗毒素的豁免檢定中具有優勢，且你對毒素傷害具有抗性。'
    ];
    ethnicityGnomeIntro1: string[] = [
        '地侏的成熟速度和人類相同，且大部分會被預計在40歲左右安定下來進入成年的生活。他們可以活到350歲到接近500歲。',
        '陣營. 地侏大部分都是善良的。那些賢者、工程師、研究者、學者、調查者、或發明家傾向於守序，而那些吟游詩人、騙徒、流浪漢、或是富幻想的珠寶匠則傾向於混亂。地侏的心地善良，甚至他們之中的那些騙徒也多是玩笑性質，而不是真正帶有惡意。',
        '體型. 地侏的身高範圍在3呎到4呎之間，且平均約40磅重。你的體型為小型。',
        '黑暗視覺. 習慣了地底的生活，你在黑暗與微光環境下仍能保持卓越視覺。你在看距離你60呎範圍內的事物時，微光的照明程度對你而言視作明亮，黑暗則視作微光。 你無法辨別黑暗中的顏色，而只能看到灰黑的輪廓。',
        '地侏狡黠. 你在所有對抗魔法的智力、睿知、和魅力豁免中具有優勢。',
        '語言. 你能夠說、讀、寫通用語和地侏語。地侏語是一種使用矮人文字的語言，並以其技術論文和對自然世界的知識分類而聞名。',
        '巧匠學識. 每當你進行與魔法物品、煉金物體、或科技裝置有關的智力（歷史）檢定時，你可以加入你兩倍的熟練加值以取代任何你原有的熟練加值。',
        '修補匠. 你熟練於工匠工具(修補匠工具)。藉由使用這些工具，你可以花費1小時的時間以及價值10金幣的材料以創造出一個微型的發條裝置（AC 5，1點生命值）。這個裝置將在24小時之後停止運轉（除非你花費1小時修理它以維持裝置的功能），或直到你使用你的動作將它拆卸；在這個時候，你可以取回你用於創造它的材料。你同時可以有最多三個正在運作的這類裝置。',
        '當你創造一個裝置時，選擇下列其中一個選項：',
        '發條玩具. 這個玩具是一個發條動物、怪物、或小人，像是青蛙、老鼠、小鳥、龍、或是士兵。當被擺放在地上，這個玩具將會在你的每個回合內沿著地面向隨機方向移動5呎。它會發出與其生物外型相符的聲音。',
        '打火機. 這個裝置會產生出微小的火焰，你可以用以點燃蠟燭、火炬、或是篝火。使用這個裝置需要一個動作。',
        '音樂盒. 當打開時，這個音樂盒將會以適中的音量演奏一首歌曲。這個音樂箱會在歌曲結束或被關上時停止演奏。'
    ];
    ethnicityDwarfIntro1: string[] = [
        '矮人的成熟速度和人類相同，但他們直到50歲之前都會被視作未成年。他們平均可以活大約350年。',
        '陣營. 大部分的矮人是守序的，堅信著井然有序的社會所帶來的好處。他們也傾向善良，有著強烈的公平競爭意識，並認為每個人都應該共享公正秩序的益處。',
        '體型. 矮人的身高介於4到5呎高，且平均大約150磅重。你的體型為中型。',
        '移動速度. 你的移動速度並不會因為穿著重甲而減少。',
        '黑暗視覺. 習慣了地底的生活，你在黑暗與微光環境下仍能保持卓越視覺。你在看距離你60呎範圍內的事物時，微光的照明程度對你而言視作明亮，黑暗則視作微光。 你無法辨別黑暗中的顏色，而只能看到灰黑的輪廓。',
        '矮人韌性. 你在對抗毒素的豁免檢定中具有優勢，且你對毒素傷害具有抗性。',
        '矮人戰鬥訓練. 你熟練於戰斧、手斧、輕錘、和戰錘。',
        '工具熟練. 你熟練於下列其中一個你所選擇的工匠工具：鐵匠工具、釀酒師設備、或石匠工具。',
        '岩石熟悉. 每當你進行關聯於石製品起源的智力（歷史）檢定時，你被視為熟練於歷史技能，並將你二倍的熟練加值代替你原本的熟練加值加入該檢定中。',
        '語言. 你能夠說、讀、寫通用語和矮人語。矮人語充斥了堅硬的輔音和喉音，而這些特徵也將顯露在任何矮人可能會說的其他語言中。',
        '矮人耐力. 你的生命值最大值增加1點，且在每次你提升等級時再增加1點。'
    ];
}