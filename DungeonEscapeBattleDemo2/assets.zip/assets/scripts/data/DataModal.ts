import { Character } from "../dungeon/Character";
import { StoryData } from "./StoryData";
import { WordPuzzleData } from "./WordPuzzleData";

export class DataModal {
    private static instance: DataModal;

    public static getInstance(): DataModal {
        return DataModal.instance || (DataModal.instance = new DataModal());
    }

    private wordPuzzleData: any;
    
    storyData: StoryData;
    playerCharacter: Character;

    private constructor() {
        this.storyData = new StoryData();
    }

}


