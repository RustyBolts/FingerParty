export class WordPuzzleData {
    constructor() {

    }

    
    // public createWordPuzzleData(name: string, word: string, puzzle: string[]): void {
    //     if (this.wordPuzzleData[name]) {
    //         console.warn(`Word puzzle data with name ${name} already exists. Overwriting...`);
    //         return;
    //     }
    //     this.wordPuzzleData[name] = new WordPuzzleData(name, word, puzzle);
    // }
}


